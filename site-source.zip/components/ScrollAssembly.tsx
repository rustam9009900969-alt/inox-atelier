"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { ArrowDown, ArrowUpRight, Hand, RotateCcw } from "lucide-react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useLocale, SceneLoading } from "./LocaleProvider";
import { assemblyStage, assemblyProgress } from "@/lib/assembly-scroll";
import type { Finish, ModelId } from "@/lib/config";
const Scene = dynamic(() => import("./Scene"), {
  ssr: false,
  loading: SceneLoading,
});
const stages = [
  "Основание",
  "Анкеры",
  "Стойки",
  "Держатели",
  "Поручень",
  "Заполнение",
];
const details = [
  "Всё начинается с точного основания.",
  "Надёжное соединение с основанием.",
  "Вертикали задают геометрию конструкции.",
  "Каждое соединение занимает своё место.",
  "Непрерывная линия объединяет конструкцию.",
  "Последний штрих. Ваша линия собрана.",
];
export default function ScrollAssembly({
  model,
  finish,
  reduce,
}: {
  model: ModelId;
  finish: Finish;
  reduce: boolean;
}) {
  const { t, locale } = useLocale();
  const host = useRef<HTMLElement>(null);
  const trigger = useRef<ScrollTrigger | null>(null);
  const progress = useRef<HTMLDivElement>(null);
  const [stage, setStage] = useState(0);
  const [inspect, setInspect] = useState(false);
  const [reset, setReset] = useState(0);
  useEffect(() => {
    if (reduce || !host.current) return;
    gsap.registerPlugin(ScrollTrigger);
    const st = ScrollTrigger.create({
      trigger: host.current,
      start: "top top",
      end: "bottom bottom",
      invalidateOnRefresh: true,
      onUpdate: (self) => {
        setStage(assemblyStage(self.progress));
        if (progress.current)
          progress.current.style.transform = `scaleX(${self.progress})`;
      },
    });
    trigger.current = st;
    setStage(assemblyStage(st.progress));
    let alive = true;
    document.fonts.ready.then(() => {
      if (alive) st.refresh();
    });
    return () => {
      alive = false;
      st.kill();
      trigger.current = null;
    };
  }, [reduce, locale]);
  const select = useCallback(
    (index: number) => {
      setStage(index);
      setInspect(false);
      const st = trigger.current;
      if (st && !reduce)
        window.scrollTo({
          top: st.start + (st.end - st.start) * assemblyProgress(index),
          behavior: "instant",
        });
    },
    [reduce],
  );
  return (
    <section
      id="assembly"
      ref={host}
      className={`scroll-assembly ${reduce ? "assembly-manual" : ""}`}
      aria-label={t("Сборка прокруткой")}
    >
      <div className="assembly-sticky">
        <div className="assembly-kicker">
          <span className="eyebrow">{t("ПРОЦЕСС / ЖИВАЯ СБОРКА")}</span>
          <a href="#safety">
            {t("Далее")} <ArrowUpRight size={14} />
          </a>
        </div>
        <div className="assembly-layout">
          <div className="assembly-copy">
            <h2>
              {t("Точность.")}
              <br />
              <em>{t("Шаг за шагом.")}</em>
            </h2>
            <p className="assembly-instruction">
              <ArrowDown size={15} />
              {reduce
                ? t("Выберите этап сборки")
                : t("Листайте — конструкция собирается.")}
            </p>
            <div className="assembly-current" aria-live="polite">
              <span>{String(stage).padStart(2, "0")} / 05</span>
              <h3>{t(stages[stage])}</h3>
              <p>{t(details[stage])}</p>
            </div>
            <nav className="assembly-nav" aria-label={t("Этапы сборки")}>
              {stages.map((name, i) => (
                <button
                  key={name}
                  aria-label={t("Этап {number}: {name}", {
                    number: i,
                    name: t(name),
                  })}
                  aria-current={stage === i ? "step" : undefined}
                  onClick={() => select(i)}
                  className={stage >= i ? "complete" : ""}
                >
                  <span>{String(i).padStart(2, "0")}</span>
                  <span>{t(name)}</span>
                </button>
              ))}
            </nav>
          </div>
          <div className="assembly-view">
            <div className="assembly-grid" aria-hidden="true" />
            <div
              className={`assembly-canvas ${inspect ? "is-interactive" : ""}`}
              data-lenis-prevent={inspect || undefined}
            >
              <Scene
                kind="config"
                model={model}
                finish={finish}
                stage={stage}
                reduce={reduce}
                reset={reset}
                scrollMode={!inspect}
              />
            </div>
            <div className="assembly-view-tools">
              <button
                aria-pressed={inspect}
                onClick={() => setInspect((v) => !v)}
              >
                <Hand size={15} />
                {inspect ? t("Продолжить прокрутку") : t("Вращать модель")}
              </button>
              <button
                onClick={() => setReset((v) => v + 1)}
                aria-label={t("Сбросить ракурс")}
              >
                <RotateCcw size={15} />
              </button>
            </div>
            <span className="assembly-model">
              {model === "glass"
                ? "PURE GLASS"
                : model === "rigel"
                  ? "LINEAR STEEL"
                  : "ATELIER CLASSIC"}{" "}
              / {String(stage).padStart(2, "0")}
            </span>
          </div>
        </div>
        <div className="assembly-progress" aria-hidden="true">
          <div ref={progress} />
        </div>
      </div>
    </section>
  );
}
