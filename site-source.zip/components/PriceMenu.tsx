"use client";
import { assetPath } from "@/lib/asset-path";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type PointerEvent,
} from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowUpRight, ChevronLeft, ChevronRight, X } from "lucide-react";
import { useLocale } from "@/components/LocaleProvider";
import {
  menuItems,
  menuCategories,
  menuCopy,
  telegramUsername,
  localizeItem,
  formatMenuPrice,
  type Category,
  type MenuItem,
  type MenuLocale,
} from "@/lib/menuItems";
import styles from "./PriceMenu.module.css";

export function PriceMenuLink({
  hero = false,
  onClick,
}: {
  hero?: boolean;
  onClick?: () => void;
}) {
  const { locale } = useLocale();
  return (
    <a
      href="#price-menu"
      className={hero ? styles.heroLink : undefined}
      onClick={onClick}
    >
      {menuCopy[locale].link}
      {hero && <ArrowUpRight size={17} aria-hidden="true" />}
    </a>
  );
}

function ProductCard({
  item,
  index,
  locale,
  onOpen,
}: {
  item: MenuItem;
  index: number;
  locale: MenuLocale;
  onOpen: (item: MenuItem) => void;
}) {
  const reduced = useReducedMotion();
  const card = useRef<HTMLButtonElement>(null);
  const frame = useRef(0);
  const finePointer = useRef(false);
  const localized = localizeItem(item, locale);
  useEffect(() => {
    const media = matchMedia("(hover: hover) and (pointer: fine)");
    const update = () => {
      finePointer.current = media.matches;
    };
    update();
    media.addEventListener("change", update);
    return () => {
      media.removeEventListener("change", update);
      cancelAnimationFrame(frame.current);
    };
  }, []);
  const reset = () => {
    cancelAnimationFrame(frame.current);
    if (card.current) {
      card.current.style.setProperty("--rx", "0deg");
      card.current.style.setProperty("--ry", "0deg");
    }
  };
  const move = (event: PointerEvent<HTMLButtonElement>) => {
    if (reduced || !finePointer.current || event.pointerType !== "mouse")
      return;
    const node = event.currentTarget;
    const box = node.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (event.clientX - box.left) / box.width));
    const y = Math.max(0, Math.min(1, (event.clientY - box.top) / box.height));
    cancelAnimationFrame(frame.current);
    frame.current = requestAnimationFrame(() => {
      node.style.setProperty("--rx", `${(0.5 - y) * 4}deg`);
      node.style.setProperty("--ry", `${(x - 0.5) * 4}deg`);
      node.style.setProperty("--light-x", `${x * 100}%`);
      node.style.setProperty("--light-y", `${y * 100}%`);
    });
  };
  return (
    <motion.li
      className={styles.cardWrap}
      initial={reduced ? false : { opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.08 }}
      transition={{
        duration: reduced ? 0 : 0.55,
        delay: reduced ? 0 : Math.min(index, 6) * 0.075,
        ease: [0.16, 1, 0.3, 1],
      }}
    >
      <button
        ref={card}
        type="button"
        className={styles.card}
        onClick={() => onOpen(item)}
        onPointerMove={move}
        onPointerLeave={reset}
        onPointerCancel={reset}
        onBlur={reset}
        aria-haspopup="dialog"
        aria-label={`${localized.name}, ${formatMenuPrice(item, locale)}`}
      >
        {item.photos.length > 0 && (
          <div className={styles.cardImage}>
            {/* Обычный img поддерживает локальные файлы, SVG-заглушки и внешние URL. */}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={assetPath(item.photos[0])}
              alt={localized.name}
              loading="lazy"
              decoding="async"
              width={900}
              height={550}
            />
            {item.demo && (
              <span className={styles.imageTag}>
                {menuCopy[locale].example}
              </span>
            )}
          </div>
        )}
        <div className={styles.cardBody}>
          <div className={styles.cardHeading}>
            <h3>{localized.name}</h3>
            <ArrowUpRight size={20} aria-hidden="true" />
          </div>
          <p>{localized.description}</p>
          <span className={styles.price}>{formatMenuPrice(item, locale)}</span>
        </div>
      </button>
    </motion.li>
  );
}

function ProductDialog({
  item,
  locale,
  onClose,
}: {
  item: MenuItem;
  locale: MenuLocale;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const gallery = useRef<HTMLDivElement>(null);
  const [photo, setPhoto] = useState(0);
  const reduced = useReducedMotion();
  const text = menuCopy[locale];
  const localized = localizeItem(item, locale);
  const username = telegramUsername.replace(/^@/, "");
  const validUsername = /^[a-zA-Z][a-zA-Z0-9_]{3,31}$/.test(username);
  // Telegram открывает черновик у конкретного получателя; сообщение не отправляется автоматически.
  const orderUrl = `https://t.me/${username}?text=${encodeURIComponent(`Здравствуйте, интересует ${localized.name}`)}`;
  useEffect(() => {
    const node = dialog.current;
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.documentElement.style.overflow;
    node?.showModal();
    document.documentElement.style.overflow = "hidden";
    return () => {
      node?.close();
      document.documentElement.style.overflow = previousOverflow;
      if (previousFocus?.isConnected)
        previousFocus.focus({ preventScroll: true });
    };
  }, []);
  const changePhoto = (next: number) => {
    const node = gallery.current;
    if (!node) return;
    node.scrollTo({
      left:
        Math.max(0, Math.min(item.photos.length - 1, next)) * node.clientWidth,
      behavior: reduced ? "instant" : "smooth",
    });
  };
  return (
    <dialog
      ref={dialog}
      className={styles.dialog}
      aria-labelledby="menu-product-title"
      onCancel={onClose}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className={styles.dialogContent} data-lenis-prevent>
        <button
          type="button"
          className={styles.close}
          aria-label={text.close}
          onClick={onClose}
          autoFocus
        >
          <X size={22} />
        </button>
        {item.photos.length > 0 && (
          <section className={styles.gallerySection} aria-label={text.gallery}>
            <div
              ref={gallery}
              className={styles.gallery}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                  e.preventDefault();
                  changePhoto(photo + (e.key === "ArrowRight" ? 1 : -1));
                }
              }}
              onScroll={(e) => {
                const node = e.currentTarget;
                if (node.clientWidth)
                  setPhoto(Math.round(node.scrollLeft / node.clientWidth));
              }}
            >
              {item.photos.map((src, index) => (
                <div className={styles.slide} key={`${src}-${index}`}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={assetPath(src)}
                    alt={`${localized.name} — ${text.photo} ${index + 1}`}
                    width={900}
                    height={550}
                    decoding="async"
                    loading={index === 0 ? "eager" : "lazy"}
                  />
                </div>
              ))}
            </div>
            {item.photos.length > 1 && (
              <div className={styles.galleryControls}>
                <button
                  type="button"
                  onClick={() => changePhoto(photo - 1)}
                  disabled={photo === 0}
                  aria-label={text.previous}
                >
                  <ChevronLeft size={18} />
                </button>
                <span aria-live="polite" aria-atomic="true">
                  {photo + 1} / {item.photos.length}
                </span>
                <button
                  type="button"
                  onClick={() => changePhoto(photo + 1)}
                  disabled={photo >= item.photos.length - 1}
                  aria-label={text.next}
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            )}
          </section>
        )}
        <div className={styles.details}>
          <p className={styles.eyebrow}>
            {
              menuCategories.find((category) => category.id === item.category)
                ?.label[locale]
            }
          </p>
          <h2 id="menu-product-title">{localized.name}</h2>
          <p className={styles.description}>{localized.description}</p>
          {item.video && (
            <video
              className={styles.video}
              src={assetPath(item.video)}
              controls
              playsInline
              preload="none"
              aria-label={text.video}
            />
          )}
          {item.demo && <p className={styles.demoNote}>{text.demo}</p>}
          <div className={styles.orderRow}>
            <strong className={styles.modalPrice}>
              {formatMenuPrice(item, locale)}
            </strong>
            {validUsername ? (
              <a
                className={styles.orderButton}
                href={orderUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                {text.order}
                <ArrowUpRight size={18} aria-hidden="true" />
              </a>
            ) : (
              <p className={styles.demoNote}>{text.configure}</p>
            )}
          </div>
        </div>
      </div>
    </dialog>
  );
}

export default function PriceMenu() {
  const { locale } = useLocale();
  const text = menuCopy[locale];
  const [category, setCategory] = useState<Category>("stairs");
  const [selected, setSelected] = useState<MenuItem | null>(null);
  const section = useRef<HTMLElement>(null);
  const close = useCallback(() => setSelected(null), []);
  const items = menuItems.filter((item) => item.category === category);
  useEffect(() => {
    // Обновляем геометрию существующих scroll-анимаций при изменении высоты меню.
    let frame = 0;
    const observer = new ResizeObserver(() => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => ScrollTrigger.refresh());
    });
    if (section.current) observer.observe(section.current);
    return () => {
      observer.disconnect();
      cancelAnimationFrame(frame);
    };
  }, []);
  return (
    <section
      id="price-menu"
      ref={section}
      className={styles.section}
      aria-labelledby="price-menu-heading"
    >
      <div className={styles.heading}>
        <div>
          <p className={styles.eyebrow}>{text.eyebrow}</p>
          <h2 id="price-menu-heading">
            {text.title}
            <br />
            <em>{text.accent}</em>
          </h2>
        </div>
        <div className={styles.intro}>
          <p>{text.intro}</p>
          {menuItems.some((item) => item.demo) && (
            <p className={styles.demoNote}>{text.demo}</p>
          )}
        </div>
      </div>
      <div className={styles.categories} role="group" aria-label={text.eyebrow}>
        {menuCategories.map((entry) => (
          <button
            key={entry.id}
            type="button"
            aria-pressed={category === entry.id}
            onClick={() => setCategory(entry.id)}
          >
            {entry.label[locale]}
          </button>
        ))}
      </div>
      <ul
        key={category}
        className={styles.grid}
        aria-label={
          menuCategories.find((entry) => entry.id === category)?.label[locale]
        }
      >
        {items.map((item, index) => (
          <ProductCard
            key={item.id}
            item={item}
            index={index}
            locale={locale}
            onOpen={setSelected}
          />
        ))}
      </ul>
      {items.length === 0 && (
        <p className={styles.empty} role="status">
          {text.empty}
        </p>
      )}
      {selected && (
        <ProductDialog
          key={selected.id}
          item={selected}
          locale={locale}
          onClose={close}
        />
      )}
    </section>
  );
}
