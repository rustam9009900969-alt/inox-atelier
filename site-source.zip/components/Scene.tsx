"use client";
import { assetPath } from "@/lib/asset-path";
import {
  Suspense,
  useEffect,
  useRef,
  useState,
  Component,
  type ReactNode,
  type RefObject,
} from "react";
import { useLocale } from "./LocaleProvider";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import {
  Environment,
  Lightformer,
  OrbitControls,
  PerformanceMonitor,
  ContactShadows,
} from "@react-three/drei";
import { BackSide, MathUtils, Vector3 } from "three";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Railing } from "./Railing";
import type { Finish, ModelId } from "@/lib/config";
import { SafetyWorld } from "./SafetyWorld";
import { Cinema } from "./Cinema";
import type { SafetyTimeline } from "@/lib/safety-motion";

import ShowroomCamera from "./ShowroomCamera";
import type { ShowroomView } from "@/lib/showroom-camera";
type SceneProps = {
  view?: ShowroomView;
  shot?: number;
  onExport?: (ok: boolean) => void;
  onReady?: (ready: boolean) => void;
  kind?: "hero" | "config" | "safety";
  model?: ModelId;
  finish?: Finish;
  stage?: number;
  explode?: number;
  xray?: boolean;
  reset?: number;
  gyro?: boolean;
  safe?: boolean;
  safetyTimeline?: RefObject<SafetyTimeline>;
  reduce?: boolean;
  zoom?: number;
  scrollMode?: boolean;
};
class Boundary extends Component<
  { children: ReactNode; fallback: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}
function Zoom({ value, fitWidth }: { value: number; fitWidth: boolean }) {
  const { camera, invalidate, size } = useThree();
  useEffect(() => {
    camera.zoom =
      value *
      (fitWidth ? Math.min(1, size.width / Math.max(1, size.height)) : 1);
    camera.updateProjectionMatrix();
    invalidate();
  }, [value, camera, invalidate, fitWidth, size.width, size.height]);
  return null;
}
function Studio({
  safety = false,
  low = false,
  neutral = false,
}: {
  safety?: boolean;
  low?: boolean;
  neutral?: boolean;
}) {
  return (
    <>
      <ambientLight intensity={safety ? 0.3 : 0.45} />
      <directionalLight
        position={[5, 8, 5]}
        intensity={safety ? 2.3 : 2}
        color={safety ? "#fff0d9" : "#ffffff"}
        castShadow={!low}
        shadow-mapSize={[low ? 512 : 1024, low ? 512 : 1024]}
        shadow-camera-left={-4}
        shadow-camera-right={4}
        shadow-camera-top={4}
        shadow-camera-bottom={-4}
        shadow-camera-near={0.5}
        shadow-camera-far={20}
        shadow-normalBias={0.035}
        shadow-bias={-0.0002}
      />
      {safety && (
        <>
          <hemisphereLight args={["#d8e4e7", "#4f4738", 0.65]} />
          <directionalLight
            position={[-4, 3, -3]}
            color="#bbd9e4"
            intensity={1.4}
          />
        </>
      )}
      <Environment resolution={low ? 128 : 256} frames={1}>
        {neutral && (
          <mesh>
            <sphereGeometry args={[30, 24, 16]} />
            <meshBasicMaterial color="#6b6965" side={BackSide} />
          </mesh>
        )}
        <Lightformer
          color="#ffffff"
          intensity={3}
          position={[0, 5, -2]}
          rotation={[Math.PI / 2, 0, 0]}
          scale={[12, 2, 1]}
        />
        <Lightformer
          color="#e5ebff"
          intensity={2.5}
          position={[-5, 1, 3]}
          rotation={[0, Math.PI / 3, 0]}
          scale={[3, 6, 1]}
        />
        <Lightformer
          intensity={3}
          position={[4, 3, 4]}
          rotation={[0, -Math.PI / 4, 0]}
          scale={[2, 5, 1]}
        />
        <Lightformer
          intensity={1}
          position={[0, 1, -5]}
          rotation={[0, Math.PI, 0]}
          scale={[8, 3, 1]}
        />
      </Environment>
    </>
  );
}
function ContextGuard({ onLost }: { onLost: () => void }) {
  const gl = useThree((s) => s.gl);
  useEffect(() => {
    const el = gl.domElement;
    const lost = (e: Event) => {
      e.preventDefault();
      onLost();
    };
    el.addEventListener("webglcontextlost", lost);
    return () => el.removeEventListener("webglcontextlost", lost);
  }, [gl, onLost]);
  return null;
}
function CameraRig({
  hero,
  reduce,
  gyro,
  host,
}: {
  hero: boolean;
  reduce: boolean;
  gyro: boolean;
  host: RefObject<HTMLDivElement | null>;
}) {
  const { camera, invalidate, size } = useThree();
  const progress = useRef({ value: 0 });
  const tilt = useRef({ x: 0, y: 0 });
  const target = useRef(new Vector3());
  useEffect(() => {
    if (!hero) return;
    gsap.registerPlugin(ScrollTrigger);
    const trigger = ScrollTrigger.create({
      trigger: host.current?.closest(".hero"),
      start: "top top",
      end: "bottom top",
      onUpdate: (s) => {
        progress.current.value = s.progress;
        invalidate();
      },
    });
    const move = (e: PointerEvent) => {
      if (
        e.pointerType !== "mouse" ||
        reduce ||
        !matchMedia("(min-width: 761px) and (hover:hover) and (pointer:fine)")
          .matches
      )
        return;
      tilt.current.x = (e.clientX / window.innerWidth - 0.5) * 0.4;
      tilt.current.y = (e.clientY / window.innerHeight - 0.5) * 0.15;
      invalidate();
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      trigger.kill();
      window.removeEventListener("pointermove", move);
    };
  }, [hero, reduce, host, invalidate]);
  useEffect(() => {
    if (!gyro || reduce) return;
    const handle = (e: DeviceOrientationEvent) => {
      tilt.current.x = MathUtils.clamp((e.gamma ?? 0) / 90, -0.4, 0.4);
      tilt.current.y = MathUtils.clamp(((e.beta ?? 45) - 45) / 180, -0.2, 0.2);
      invalidate();
    };
    window.addEventListener("deviceorientation", handle);
    return () => window.removeEventListener("deviceorientation", handle);
  }, [gyro, reduce, invalidate]);
  useFrame((_, dt) => {
    if (!hero) return;
    const p = reduce ? 0 : progress.current.value;
    target.current.set(
      5.8 - p * 4 + tilt.current.x,
      3.6 + p * 1.8 + tilt.current.y,
      7.3 - p * 1.3,
    );
    if (size.width < 600) target.current.multiplyScalar(1.13);
    const delta = camera.position.distanceTo(target.current);
    camera.position.lerp(
      target.current,
      reduce ? 1 : 1 - Math.exp(-4 * Math.min(dt, 0.05)),
    );
    camera.lookAt(0, 0.6, 0);
    if (delta > 0.001) invalidate();
  });
  return null;
}
export default function Scene({
  kind = "hero",
  model = "glass",
  finish = "satin",
  stage = 5,
  explode = 0,
  xray = false,
  reset = 0,
  gyro = false,
  safe = true,
  safetyTimeline,
  reduce = false,
  zoom = 1.2,
  scrollMode = false,
  view = "overall",
  shot = 0,
  onExport,
  onReady,
}: SceneProps) {
  const { t } = useLocale();
  const host = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [activated, setActivated] = useState(false);
  const [lost, setLost] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [low, setLow] = useState(false);
  const [dpr, setDpr] = useState(1.25);
  const viewerMargin = kind === "config" && !scrollMode && !low ? 1200 : 0;
  useEffect(() => {
    const mobile = matchMedia("(max-width:760px), (pointer:coarse)");
    const updateQuality = () => {
      setLow(mobile.matches);
      setDpr(Math.min(devicePixelRatio, mobile.matches ? 1 : 1.6));
    };
    updateQuality();
    mobile.addEventListener("change", updateQuality);
    const check = () => {
      if (document.hidden) setVisible(false);
      else if (host.current) {
        const r = host.current.getBoundingClientRect();
        setVisible(
          r.width > 0 &&
            r.height > 0 &&
            r.bottom > -viewerMargin &&
            r.top < innerHeight + viewerMargin,
        );
      }
    };
    const observer = new IntersectionObserver(
      ([e]) => setVisible(e.isIntersecting && !document.hidden),
      { rootMargin: `${viewerMargin}px` },
    );
    if (host.current) observer.observe(host.current);
    const resizeObserver = new ResizeObserver(check);
    if (host.current) resizeObserver.observe(host.current);
    window.addEventListener("resize", check, { passive: true });
    check();
    document.addEventListener("visibilitychange", check);
    return () => {
      observer.disconnect();
      resizeObserver.disconnect();
      window.removeEventListener("resize", check);
      mobile.removeEventListener("change", updateQuality);
      document.removeEventListener("visibilitychange", check);
    };
  }, [viewerMargin]);
  useEffect(() => {
    if (visible) setActivated(true);
  }, [visible]);
  const fallback = (
    <div className="scene-fallback">
      <img
        src={assetPath(
          model === "rigel"
            ? "/projects/project-20.jpg"
            : model === "classic"
              ? "/projects/project-15.jpg"
              : "/projects/project-19.jpg",
        )}
        alt={t("Пример ограждения из портфолио")}
      />
      <span>{t("Фотография проекта · 3D недоступно на этом устройстве")}</span>
      <button
        type="button"
        className="scene-retry"
        onClick={() => {
          setLost(false);
          setAttempt((v) => v + 1);
        }}
      >
        {t("Повторить загрузку 3D")}
      </button>
    </div>
  );
  return (
    <div
      ref={host}
      className={`scene-root scene-${kind}`}
      aria-label={
        kind === "safety"
          ? t("Схематическая 3D-сцена безопасности")
          : t("Интерактивная 3D-модель ограждения")
      }
    >
      {lost ? (
        fallback
      ) : activated || visible ? (
        <Boundary key={attempt} fallback={fallback}>
          <Suspense
            fallback={
              <div className="scene-loading">
                {t("Подготавливаем пространство…")}
              </div>
            }
          >
            <Canvas
              key={`${kind}-${reset}-${attempt}`}
              frameloop={visible ? "demand" : "never"}
              dpr={dpr}
              shadows={!low}
              camera={{
                position:
                  kind === "safety"
                    ? [5.5, 4.5, 7]
                    : kind === "config"
                      ? [5, 3.4, 7.5]
                      : [5.8, 3.6, 7.3],
                fov: kind === "config" ? 32 : 36,
                near: 0.1,
                far: 60,
              }}
              gl={{
                antialias: !low,
                alpha: true,
                powerPreference: "high-performance",
                stencil: false,
              }}
              fallback={fallback}
              onCreated={({ gl }) => {
                gl.setClearColor("#080808", 0);
              }}
            >
              <ContextGuard onLost={() => setLost(true)} />
              <PerformanceMonitor
                bounds={() => [45, 58]}
                flipflops={3}
                onDecline={() => {
                  setDpr((d) => Math.max(0.75, d - 0.25));
                  setLow(true);
                }}
                onFallback={() => {
                  setDpr(0.75);
                  setLow(true);
                }}
              />
              <Studio
                safety={kind === "safety"}
                low={low}
                neutral={kind === "config" && !scrollMode}
              />
              <Zoom value={zoom} fitWidth={scrollMode || kind === "safety"} />
              {kind === "config" && !scrollMode && (
                <ShowroomCamera
                  view={view}
                  reduce={reduce}
                  shot={shot}
                  onExport={onExport}
                  onReady={onReady}
                />
              )}
              {kind === "hero" && !low && !reduce && dpr >= 1.5 && <Cinema />}
              {kind === "safety" ? (
                <SafetyWorld safe={safe} timeline={safetyTimeline} low={low} />
              ) : (
                <group
                  scale={kind === "hero" ? 0.75 : 1}
                  position={[0, kind === "hero" ? -0.5 : -0.75, 0]}
                >
                  <Railing
                    model={model}
                    finish={finish}
                    stage={stage}
                    explode={explode}
                    xray={xray}
                    slope={kind === "hero" ? 0.28 : 0}
                    low={low}
                    reduce={reduce}
                  />
                  {kind === "hero" ? (
                    Array.from({ length: 8 }, (_, i) => (
                      <mesh
                        key={i}
                        position={[-1.97 + i * 0.56, i * 0.157 - 0.14, -0.58]}
                      >
                        <boxGeometry args={[0.57, 0.24, 1.7]} />
                        <meshStandardMaterial
                          color="#181b20"
                          roughness={0.52}
                          metalness={0.2}
                        />
                      </mesh>
                    ))
                  ) : (
                    <mesh receiveShadow position={[0, -0.12, -0.1]}>
                      <boxGeometry args={[4.8, 0.22, 1.35]} />
                      <meshStandardMaterial
                        transparent={xray}
                        opacity={xray ? 0.18 : 1}
                        depthWrite={!xray}
                        color="#c9c2b7"
                        metalness={0}
                        roughness={0.8}
                      />
                    </mesh>
                  )}
                </group>
              )}
              {kind === "config" && !scrollMode && (
                <>
                  <mesh
                    rotation={[-Math.PI / 2, 0, 0]}
                    position={[0, -0.99, 0]}
                    receiveShadow
                  >
                    <planeGeometry args={[200, 200]} />
                    <meshStandardMaterial color="#f1eee8" roughness={0.9} />
                  </mesh>
                  {!low && (
                    <ContactShadows
                      position={[0, -0.982, 0]}
                      opacity={0.32}
                      scale={12}
                      blur={2.7}
                      far={3}
                      resolution={low ? 128 : 256}
                      frames={1}
                    />
                  )}
                </>
              )}
              <CameraRig
                hero={kind === "hero"}
                gyro={gyro}
                reduce={reduce}
                host={host}
              />
              {kind !== "hero" && (
                <OrbitControls
                  enabled={!scrollMode}
                  makeDefault
                  enableDamping={!reduce}
                  dampingFactor={0.12}
                  minDistance={view === "joint" && !scrollMode ? 0.9 : 3}
                  maxDistance={24}
                  maxPolarAngle={Math.PI * 0.49}
                  target={kind === "safety" ? [0, 0, 0] : [0, 0.2, 0]}
                  enableZoom={true}
                  enablePan={false}
                />
              )}
            </Canvas>
          </Suspense>
        </Boundary>
      ) : (
        <div className="scene-loading">
          {kind === "hero" ? t("Сталь. Стекло. Совершенство.") : ""}
        </div>
      )}
    </div>
  );
}
