"use client";
import { useEffect, useMemo, useRef, type ReactNode } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  Group,
  MeshStandardMaterial,
  MeshPhysicalMaterial,
  Vector3,
  Quaternion,
  CylinderGeometry,
  DataTexture,
  RGBAFormat,
  RepeatWrapping,
  Vector2,
  Color,
} from "three";
import { RoundedBox, Edges } from "@react-three/drei";
import type { Finish, ModelId } from "@/lib/config";

// Unit tubes share buffers; scale preserves the existing section dimensions.
const tubeGeometry = new CylinderGeometry(1, 1, 1, 48);
const mobileTubeGeometry = new CylinderGeometry(1, 1, 1, 24);
function brushedNormal() {
  const size = 128,
    data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      data[i] =
        128 + Math.round(12 * Math.sin(x * 2.1) + 6 * Math.sin(x * 0.73));
      data[i + 1] = 128;
      data[i + 2] = 255;
      data[i + 3] = 255;
    }
  const texture = new DataTexture(data, size, size, RGBAFormat);
  texture.wrapS = texture.wrapT = RepeatWrapping;
  texture.repeat.set(3, 1);
  texture.needsUpdate = true;
  return texture;
}
type V3 = [number, number, number];
export function Beam({
  from,
  to,
  radius = 0.028,
  material,
  segments = 16,
}: {
  from: V3;
  to: V3;
  radius?: number;
  material: MeshStandardMaterial;
  segments?: number;
}) {
  const { position, quaternion, length } = useMemo(() => {
    const a = new Vector3(...from),
      b = new Vector3(...to),
      d = b.clone().sub(a);
    return {
      position: a.add(b).multiplyScalar(0.5),
      quaternion: new Quaternion().setFromUnitVectors(
        new Vector3(0, 1, 0),
        d.clone().normalize(),
      ),
      length: d.length(),
    };
  }, [...from, ...to]);
  return (
    <mesh
      castShadow
      receiveShadow
      position={position}
      quaternion={quaternion}
      material={material}
      geometry={segments <= 24 ? mobileTubeGeometry : tubeGeometry}
      dispose={null}
      scale={[radius, length, radius]}
    />
  );
}
function Part({
  stage,
  step,
  explode,
  offset,
  reduce,
  children,
}: {
  stage: number;
  step: number;
  explode: number;
  offset: V3;
  reduce: boolean;
  children: ReactNode;
}) {
  const ref = useRef<Group>(null);
  const invalidate = useThree((s) => s.invalidate);
  const target = stage >= step ? explode : 1.6;
  const initialPosition = useRef<V3>([
    offset[0] * target,
    offset[1] * target,
    offset[2] * target,
  ]);
  useEffect(() => {
    invalidate();
  }, [target, invalidate]);
  useFrame((_, delta) => {
    if (!ref.current) return;
    const g = ref.current;
    let moving = false;
    for (let i = 0; i < 3; i++) {
      const key = ["x", "y", "z"][i] as "x" | "y" | "z";
      const goal = offset[i] * target;
      g.position[key] = reduce
        ? goal
        : g.position[key] +
          (goal - g.position[key]) * (1 - Math.exp(-7 * Math.min(delta, 0.05)));
      if (Math.abs(g.position[key] - goal) > 0.001) moving = true;
    }
    g.visible = stage >= step || moving;
    if (moving) invalidate();
  });
  return (
    <group ref={ref} position={initialPosition.current} visible={stage >= step}>
      {children}
    </group>
  );
}
export function Railing({
  model = "glass",
  finish = "satin",
  stage = 5,
  explode = 0,
  xray = false,
  slope = 0,
  low = false,
  reduce = false,
}: {
  model?: ModelId;
  finish?: Finish;
  stage?: number;
  explode?: number;
  xray?: boolean;
  slope?: number;
  low?: boolean;
  reduce?: boolean;
}) {
  const grain = useMemo(brushedNormal, []);
  useEffect(() => () => grain.dispose(), [grain]);
  const materials = useMemo(
    () => ({
      steel: new MeshStandardMaterial({
        color: "#e4e3df",
        metalness: 1,
        roughness: 0.32,
      }),
      flat: new MeshStandardMaterial({
        color: "#e4e3df",
        metalness: 1,
        roughness: 0.32,
      }),
      glass: new MeshPhysicalMaterial({
        color: "#e1edf0",
        metalness: 0,
        roughness: 0.065,
        transmission: low || xray ? 0 : 0.96,
        thickness: 0.024,
        ior: 1.5,
        transparent: low || xray,
        opacity: xray ? 0.09 : low ? 0.22 : 1,
        depthWrite: !low && !xray,
        clearcoat: 0.7,
        attenuationColor: new Color("#dbe9e9"),
        attenuationDistance: 2,
      }),
      gold: new MeshStandardMaterial({
        color: "#c5a265",
        metalness: 1,
        roughness: 0.28,
      }),
      core: new MeshStandardMaterial({ color: "#a69d8f", roughness: 0.55 }),
    }),
    [low, xray],
  );
  const targetColor = useMemo(
    () => new Color(finish === "gold" ? "#c4a873" : "#e4e3df"),
    [finish],
  );
  const invalidate = useThree((s) => s.invalidate);
  useEffect(() => {
    invalidate();
  }, [finish, xray, invalidate]);
  useFrame((_, dt) => {
    let moving = false;
    for (const [key, material] of [
      ["tube", materials.steel],
      ["flat", materials.flat],
    ] as const) {
      const roughness =
        finish === "polished" ? 0.16 : finish === "gold" ? 0.28 : 0.36;
      const k = reduce ? 1 : 1 - Math.exp(-8 * Math.min(dt, 0.05));
      material.color.lerp(targetColor, k);
      material.roughness += (roughness - material.roughness) * k;
      material.normalMap =
        key === "tube" && finish === "satin" && !low ? grain : null;
      material.normalScale.set(0.11, 0.11);
      if (material.userData.grain !== !!material.normalMap) {
        material.needsUpdate = true;
        material.userData.grain = !!material.normalMap;
      }
      material.transparent = xray;
      material.opacity = xray ? 0.22 : 1;
      material.depthWrite = !xray;
      if (
        Math.abs(material.roughness - roughness) > 0.001 ||
        Math.abs(material.color.r - targetColor.r) +
          Math.abs(material.color.g - targetColor.g) +
          Math.abs(material.color.b - targetColor.b) >
          0.001
      )
        moving = true;
    }
    if (moving) invalidate();
  });
  useEffect(
    () => () => Object.values(materials).forEach((m) => m.dispose()),
    [materials],
  );
  const n = low ? 24 : 48;
  const xs = [-2.1, -0.7, 0.7, 2.1];
  const y = (x: number) => slope * (x + 2.1);
  const props = { stage, explode, reduce };
  return (
    <group>
      <Part {...props} step={1} offset={[0, -0.8, 0]}>
        {xs.map((x) => (
          <group key={x} position={[x, y(x), 0]}>
            <mesh material={materials.steel}>
              <cylinderGeometry args={[0.115, 0.125, 0.045, n]} />
            </mesh>
            {[-0.058, 0.058].flatMap((a) =>
              [-0.058, 0.058].map((b) => (
                <mesh
                  key={`${a}-${b}`}
                  position={[a, 0.032, b]}
                  material={materials.steel}
                >
                  <cylinderGeometry args={[0.013, 0.013, 0.023, 6]} />
                </mesh>
              )),
            )}
            <mesh
              position={[0, -0.15, 0]}
              material={xray ? materials.core : materials.steel}
            >
              <cylinderGeometry args={[0.022, 0.022, 0.3, n]} />
            </mesh>
          </group>
        ))}
      </Part>
      <Part {...props} step={2} offset={[0, 0.75, 0.7]}>
        {xs.map((x) => (
          <group key={x}>
            <Beam
              from={[x, y(x) + 0.02, 0]}
              to={[x, y(x) + 1.35, 0]}
              radius={0.04}
              material={materials.steel}
              segments={n}
            />
            {xray && (
              <Beam
                from={[x, y(x) - 0.16, 0]}
                to={[x, y(x) + 0.5, 0]}
                radius={0.018}
                material={materials.core}
                segments={n}
              />
            )}
          </group>
        ))}
      </Part>
      <Part {...props} step={3} offset={[0, 0.9, -0.6]}>
        {xs.map((x) => (
          <group key={x}>
            <Beam
              from={[x, y(x) + 1.32, 0]}
              to={[x, y(x) + 1.48, 0]}
              radius={0.018}
              material={materials.steel}
              segments={n}
            />
            {[0.28, 1.13].map((h) => (
              <RoundedBox
                key={h}
                args={[0.15, 0.085, 0.07]}
                radius={0.004}
                smoothness={low ? 1 : 3}
                position={[x, y(x) + h, 0.042]}
                material={materials.flat}
                castShadow
                receiveShadow
              />
            ))}
          </group>
        ))}
      </Part>
      <Part {...props} step={4} offset={[0, 1.4, 0]}>
        <Beam
          from={[-2.24, y(-2.24) + 1.49, 0]}
          to={[2.24, y(2.24) + 1.49, 0]}
          radius={0.056}
          material={materials.steel}
          segments={n}
        />
      </Part>
      <Part {...props} step={5} offset={[0, 0.25, 1.2]}>
        {model === "glass" ? (
          [-1.4, 0, 1.4].map((x) => (
            <mesh
              key={x}
              position={[x, y(x) + 0.74, 0.03]}
              rotation={[0, 0, Math.atan(slope)]}
              material={materials.glass}
            >
              <boxGeometry args={[1.27, 1.16, 0.024]} />
              <Edges threshold={20} color="#b2c7cc" lineWidth={1} />
            </mesh>
          ))
        ) : model === "rigel" ? (
          [0.3, 0.6, 0.9, 1.2].map((h) => (
            <Beam
              key={h}
              from={[-2.16, y(-2.16) + h, 0.04]}
              to={[2.16, y(2.16) + h, 0.04]}
              radius={0.016}
              material={materials.steel}
              segments={n}
            />
          ))
        ) : (
          <>
            <Beam
              from={[-2.1, y(-2.1) + 0.15, 0]}
              to={[2.1, y(2.1) + 0.15, 0]}
              radius={0.027}
              material={materials.steel}
              segments={n}
            />
            {Array.from({ length: 17 }, (_, i) => -1.96 + i * 0.245).map(
              (x) => (
                <group key={x}>
                  <Beam
                    from={[x, y(x) + 0.17, 0]}
                    to={[x, y(x) + 1.35, 0]}
                    radius={0.015}
                    material={materials.steel}
                    segments={n}
                  />
                  {[0.53, 0.84].map((h) => (
                    <mesh
                      key={h}
                      position={[x, y(x) + h, 0]}
                      scale={[1, 2.6, 1]}
                      material={
                        finish === "gold" ? materials.gold : materials.steel
                      }
                    >
                      <sphereGeometry args={[0.041, n, 8]} />
                    </mesh>
                  ))}
                </group>
              ),
            )}
          </>
        )}
      </Part>
    </group>
  );
}
