"use client";
import { useEffect, useMemo, useRef, type ReactNode } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  Group,
  MeshStandardMaterial,
  MeshPhysicalMaterial,
  Vector3,
  Quaternion,
} from "three";
import type { Finish, ModelId } from "@/lib/config";

type V3 = [number, number, number];
export function Beam({
  from,
  to,
  radius = 0.028,
  material,
  segments = 16,
}: {
  from: V3;
  to: V3;
  radius?: number;
  material: MeshStandardMaterial;
  segments?: number;
}) {
  const { position, quaternion, length } = useMemo(() => {
    const a = new Vector3(...from),
      b = new Vector3(...to),
      d = b.clone().sub(a);
    return {
      position: a.add(b).multiplyScalar(0.5),
      quaternion: new Quaternion().setFromUnitVectors(
        new Vector3(0, 1, 0),
        d.clone().normalize(),
      ),
      length: d.length(),
    };
  }, [...from, ...to]);
  return (
    <mesh position={position} quaternion={quaternion} material={material}>
      <cylinderGeometry args={[radius, radius, length, segments]} />
    </mesh>
  );
}
function Part({
  stage,
  step,
  explode,
  offset,
  reduce,
  children,
}: {
  stage: number;
  step: number;
  explode: number;
  offset: V3;
  reduce: boolean;
  children: ReactNode;
}) {
  const ref = useRef<Group>(null);
  const invalidate = useThree((s) => s.invalidate);
  const target = stage >= step ? explode : 1.6;
  const initialPosition = useRef<V3>([
    offset[0] * target,
    offset[1] * target,
    offset[2] * target,
  ]);
  useEffect(() => {
    invalidate();
  }, [target, invalidate]);
  useFrame((_, delta) => {
    if (!ref.current) return;
    const g = ref.current;
    let moving = false;
    for (let i = 0; i < 3; i++) {
      const key = ["x", "y", "z"][i] as "x" | "y" | "z";
      const goal = offset[i] * target;
      g.position[key] = reduce
        ? goal
        : g.position[key] +
          (goal - g.position[key]) * (1 - Math.exp(-7 * Math.min(delta, 0.05)));
      if (Math.abs(g.position[key] - goal) > 0.001) moving = true;
    }
    g.visible = stage >= step || moving;
    if (moving) invalidate();
  });
  return (
    <group ref={ref} position={initialPosition.current} visible={stage >= step}>
      {children}
    </group>
  );
}
export function Railing({
  model = "glass",
  finish = "satin",
  stage = 5,
  explode = 0,
  xray = false,
  slope = 0,
  low = false,
  reduce = false,
}: {
  model?: ModelId;
  finish?: Finish;
  stage?: number;
  explode?: number;
  xray?: boolean;
  slope?: number;
  low?: boolean;
  reduce?: boolean;
}) {
  const materials = useMemo(
    () => ({
      steel: new MeshStandardMaterial({
        color: finish === "gold" ? "#c4a873" : "#d9dfe9",
        metalness: 1,
        roughness: finish === "polished" ? 0.12 : 0.27,
        transparent: xray,
        opacity: xray ? 0.22 : 1,
        depthWrite: !xray,
      }),
      glass: new MeshPhysicalMaterial({
        color: "#a6b8cf",
        metalness: 0.08,
        roughness: 0.08,
        transparent: true,
        opacity: xray ? 0.09 : 0.23,
        side: 2,
        depthWrite: false,
        clearcoat: 1,
      }),
      gold: new MeshStandardMaterial({
        color: "#c5a265",
        metalness: 1,
        roughness: 0.25,
      }),
      core: new MeshStandardMaterial({
        color: "#ccdfff",
        emissive: "#6183c2",
        emissiveIntensity: 0.8,
        roughness: 0.4,
      }),
    }),
    [finish, xray],
  );
  useEffect(
    () => () => Object.values(materials).forEach((m) => m.dispose()),
    [materials],
  );
  const n = low ? 10 : 24;
  const xs = [-2.1, -0.7, 0.7, 2.1];
  const y = (x: number) => slope * (x + 2.1);
  const props = { stage, explode, reduce };
  return (
    <group>
      <Part {...props} step={1} offset={[0, -0.8, 0]}>
        {xs.map((x) => (
          <group key={x} position={[x, y(x), 0]}>
            <mesh material={materials.steel}>
              <cylinderGeometry args={[0.115, 0.125, 0.045, n]} />
            </mesh>
            {[-0.058, 0.058].flatMap((a) =>
              [-0.058, 0.058].map((b) => (
                <mesh
                  key={`${a}-${b}`}
                  position={[a, 0.032, b]}
                  material={materials.steel}
                >
                  <cylinderGeometry args={[0.013, 0.013, 0.023, 6]} />
                </mesh>
              )),
            )}
            <mesh
              position={[0, -0.15, 0]}
              material={xray ? materials.core : materials.steel}
            >
              <cylinderGeometry args={[0.022, 0.022, 0.3, n]} />
            </mesh>
          </group>
        ))}
      </Part>
      <Part {...props} step={2} offset={[0, 0.75, 0.7]}>
        {xs.map((x) => (
          <group key={x}>
            <Beam
              from={[x, y(x) + 0.02, 0]}
              to={[x, y(x) + 1.35, 0]}
              radius={0.04}
              material={materials.steel}
              segments={n}
            />
            {xray && (
              <Beam
                from={[x, y(x) - 0.16, 0]}
                to={[x, y(x) + 0.5, 0]}
                radius={0.018}
                material={materials.core}
                segments={n}
              />
            )}
          </group>
        ))}
      </Part>
      <Part {...props} step={3} offset={[0, 0.9, -0.6]}>
        {xs.map((x) => (
          <group key={x}>
            <Beam
              from={[x, y(x) + 1.32, 0]}
              to={[x, y(x) + 1.48, 0]}
              radius={0.018}
              material={materials.steel}
              segments={n}
            />
            {[0.28, 1.13].map((h) => (
              <mesh
                key={h}
                position={[x, y(x) + h, 0.042]}
                material={materials.steel}
              >
                <boxGeometry args={[0.15, 0.085, 0.07]} />
              </mesh>
            ))}
          </group>
        ))}
      </Part>
      <Part {...props} step={4} offset={[0, 1.4, 0]}>
        <Beam
          from={[-2.24, y(-2.24) + 1.49, 0]}
          to={[2.24, y(2.24) + 1.49, 0]}
          radius={0.056}
          material={materials.steel}
          segments={n}
        />
      </Part>
      <Part {...props} step={5} offset={[0, 0.25, 1.2]}>
        {model === "glass" ? (
          [-1.4, 0, 1.4].map((x) => (
            <mesh
              key={x}
              position={[x, y(x) + 0.74, 0.03]}
              rotation={[0, 0, Math.atan(slope)]}
              material={materials.glass}
            >
              <boxGeometry args={[1.27, 1.16, 0.024]} />
            </mesh>
          ))
        ) : model === "rigel" ? (
          [0.3, 0.6, 0.9, 1.2].map((h) => (
            <Beam
              key={h}
              from={[-2.16, y(-2.16) + h, 0.04]}
              to={[2.16, y(2.16) + h, 0.04]}
              radius={0.016}
              material={materials.steel}
              segments={n}
            />
          ))
        ) : (
          <>
            <Beam
              from={[-2.1, y(-2.1) + 0.15, 0]}
              to={[2.1, y(2.1) + 0.15, 0]}
              radius={0.027}
              material={materials.steel}
              segments={n}
            />
            {Array.from({ length: 17 }, (_, i) => -1.96 + i * 0.245).map(
              (x) => (
                <group key={x}>
                  <Beam
                    from={[x, y(x) + 0.17, 0]}
                    to={[x, y(x) + 1.35, 0]}
                    radius={0.015}
                    material={materials.steel}
                    segments={n}
                  />
                  {[0.53, 0.84].map((h) => (
                    <mesh
                      key={h}
                      position={[x, y(x) + h, 0]}
                      scale={[1, 2.6, 1]}
                      material={
                        finish === "gold" ? materials.gold : materials.steel
                      }
                    >
                      <sphereGeometry args={[0.041, n, 8]} />
                    </mesh>
                  ))}
                </group>
              ),
            )}
          </>
        )}
      </Part>
    </group>
  );
}
