"use client";
import { useEffect, useRef } from "react";

const desktopMotion =
  "(min-width: 761px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)";
const revealTargets =
  ".hero-copy > *, .architecture-copy > *, .architecture-caption, .section-top, .section-heading > *, .material-strip > div, .model-image, .model-title, .model-card > p, .config-visual, .config-options, .assembly-bar, .safety-copy > *, .safety-visual, .project-image, .project > span, .project > p, .estimate > div:first-child > *, .calculator, .contact > :not(.contact-monogram), footer, .studio-details-heading > *, .material-tabs, .material-study, .studio-faq > *";

/** SSR stays visible; touch gets short, compositor-only reveals. No scroll hijacking. */
export default function ScrollReveal({
  reduce,
  revision,
}: {
  reduce: boolean;
  revision: string;
}) {
  const seen = useRef(new WeakSet<Element>());
  useEffect(() => {
    const media = matchMedia("(prefers-reduced-motion: no-preference)");
    const desktop = matchMedia(desktopMotion);
    let cleanup = () => {};
    const setup = () => {
      cleanup();
      if (reduce || !media.matches || !Element.prototype.animate) return;
      const rich = desktop.matches;
      const animations = new Map<Element, Animation>();
      const groups = new Map<Element, number>();
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            observer.unobserve(entry.target);
            seen.current.add(entry.target);
            const animation = animations.get(entry.target);
            animation?.play();
          });
        },
        { threshold: 0, rootMargin: "0px 0px -24px 0px" },
      );
      document
        .querySelectorAll<HTMLElement>(revealTargets)
        .forEach((element) => {
          if (seen.current.has(element)) return;
          const box = element.getBoundingClientRect();
          if (!box.width || !box.height || box.bottom < 0) return;
          const image = element.matches(".model-image,.project-image");
          const heading = element.matches("h1,h2,h3");
          const group =
            element.closest(
              ".model-card,.project,.section-heading,.safety-copy,.hero-copy,.contact,.material-strip",
            ) || element.parentElement!;
          const order = groups.get(group) || 0;
          groups.set(group, order + 1);
          const card = element.closest(".model-card,.project");
          const cardOrder = card
            ? Array.from(card.parentElement!.children).indexOf(card)
            : 0;
          const delay = Math.min(
            240,
            order * (rich ? 65 : 40) + (cardOrder % (rich ? 3 : 1)) * 80,
          );
          const animation = element.animate(
            image && rich
              ? [
                  {
                    opacity: 0.2,
                    clipPath: "inset(0 0 12% 0 round 2px)",
                    translate: "0 24px",
                  },
                  {
                    opacity: 1,
                    clipPath: "inset(0 0 0% 0 round 2px)",
                    translate: "0 0",
                  },
                ]
              : [
                  {
                    opacity: 0,
                    translate: `0 ${rich ? (heading ? 32 : 22) : 16}px`,
                  },
                  { opacity: 1, translate: "0 0" },
                ],
            {
              duration: rich ? (image ? 800 : heading ? 700 : 560) : 580,
              delay,
              easing: "cubic-bezier(.16,1,.3,1)",
              fill: "both",
            },
          );
          animation.pause();
          animation.onfinish = () => {
            animation.cancel();
            animations.delete(element);
          };
          animations.set(element, animation);
          observer.observe(element);
        });
      const focus = (event: FocusEvent) => {
        if (!(event.target instanceof Element)) return;
        animations.forEach((animation, element) => {
          if (element.contains(event.target as Node)) {
            seen.current.add(element);
            observer.unobserve(element);
            animation.cancel();
            animations.delete(element);
          }
        });
      };
      const visibility = () => {
        if (document.hidden)
          animations.forEach((animation) => {
            if (animation.playState === "running") animation.finish();
          });
      };
      document.addEventListener("focusin", focus);
      document.addEventListener("visibilitychange", visibility);
      cleanup = () => {
        observer.disconnect();
        animations.forEach((a) => {
          a.cancel();
        });
        animations.clear();
        document.removeEventListener("focusin", focus);
        document.removeEventListener("visibilitychange", visibility);
      };
    };
    setup();
    media.addEventListener("change", setup);
    desktop.addEventListener("change", setup);
    return () => {
      cleanup();
      media.removeEventListener("change", setup);
      desktop.removeEventListener("change", setup);
    };
  }, [reduce, revision]);
  useEffect(() => {
    const media = matchMedia(desktopMotion);
    const active = new Map<Element, Animation>();
    const observer = new MutationObserver((records) => {
      if (reduce || !media.matches) return;
      const targets = new Set<Element>();
      records.forEach((record) => {
        const node =
          record.target instanceof Element
            ? record.target
            : record.target.parentElement;
        const target = node?.closest(
          ".viewer-label > span:first-child,.cost strong,.safety-message",
        );
        if (target) targets.add(target);
      });
      targets.forEach((target) => {
        const rect = target.getBoundingClientRect();
        if (rect.bottom < 0 || rect.top > innerHeight) return;
        active.get(target)?.cancel();
        const a = target.animate(
          [
            { opacity: 0.45, translate: "0 5px" },
            { opacity: 1, translate: "0 0" },
          ],
          { duration: 260, easing: "ease-out" },
        );
        active.set(target, a);
        a.onfinish = () => active.delete(target);
      });
    });
    const stop = () => {
      if (!media.matches) {
        active.forEach((a) => a.cancel());
        active.clear();
      }
    };
    if (typeof Element.prototype.animate === "function")
      observer.observe(document.querySelector("main")!, {
        subtree: true,
        characterData: true,
        childList: true,
      });
    media.addEventListener("change", stop);
    return () => {
      observer.disconnect();
      active.forEach((a) => a.cancel());
      media.removeEventListener("change", stop);
    };
  }, [reduce]);
  return null;
}
