"use client";
import { assetPath } from "@/lib/asset-path";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
export default function HeroArtwork({
  reduce,
  gyro = false,
}: {
  reduce: boolean;
  gyro?: boolean;
}) {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (reduce || !host.current) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add(
      "(min-width:761px) and (hover:hover) and (pointer:fine) and (prefers-reduced-motion:no-preference)",
      () => {
        gsap.fromTo(
          host.current!.querySelector("img"),
          { scale: 1.06, yPercent: 0 },
          {
            scale: 1.14,
            yPercent: 3,
            ease: "none",
            scrollTrigger: {
              trigger: host.current!.closest(".hero"),
              start: "top top",
              end: "bottom top",
              scrub: true,
            },
          },
        );
      },
    );
    return () => media.revert();
  }, [reduce]);
  useEffect(() => {
    if (!gyro || reduce || !host.current) return;
    let move: (event: DeviceOrientationEvent) => void;
    const ctx = gsap.context(() => {
      const image = host.current!.querySelector(".hero-photograph");
      const x = gsap.quickTo(image, "x", { duration: 0.5, ease: "power2.out" });
      const y = gsap.quickTo(image, "y", { duration: 0.5, ease: "power2.out" });
      move = (event) => {
        x(gsap.utils.clamp(-8, 8, (event.gamma ?? 0) / 4));
        y(gsap.utils.clamp(-6, 6, ((event.beta ?? 45) - 45) / 6));
      };
      window.addEventListener("deviceorientation", move, { passive: true });
    }, host);
    return () => {
      window.removeEventListener("deviceorientation", move);
      ctx.revert();
    };
  }, [gyro, reduce]);
  return (
    <div ref={host} className="hero-artwork" aria-hidden="true">
      <div className="hero-photograph">
        <img
          src={assetPath("/media/atelier-hero.webp")}
          width="1672"
          height="941"
          fetchPriority="high"
          alt=""
        />
      </div>
    </div>
  );
}
