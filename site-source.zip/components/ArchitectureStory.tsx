"use client";
import { assetPath } from "@/lib/asset-path";
import { ArrowUpRight } from "lucide-react";
import { useLocale } from "./LocaleProvider";

export default function ArchitectureStory() {
  const { t } = useLocale();
  return (
    <>
      <div className="signature-ribbon" aria-hidden="true">
        <div className="signature-ribbon-track">
          {[0, 1, 2].map((n) => (
            <span key={n}>
              INOX ATELIER <i>✦</i> {t("СТАЛЬ · СТЕКЛО · СВЕТ")} <i>✦</i>
            </span>
          ))}
        </div>
      </div>
      <section className="architecture-story" aria-label={t("В АРХИТЕКТУРЕ.")}>
        <img
          className="architecture-photo"
          src={assetPath("/media/ink-space.webp")}
          width="1086"
          height="1448"
          loading="lazy"
          alt={t("Архитектурная визуализация")}
        />
        <div className="architecture-shade" aria-hidden="true" />
        <span className="architecture-index">INOX / ARCHITECTURE</span>
        <div className="architecture-copy">
          <span className="eyebrow">{t("ФОРМА / МАТЕРИАЛ / ТОЧНОСТЬ")}</span>
          <h2>{t("Сталь. Вне времени.")}</h2>
          <a className="button outline" href="#configurator">
            {t("СОЗДАТЬ СВОЙ ПРОЕКТ")}
            <ArrowUpRight size={20} />
          </a>
        </div>
        <div className="architecture-caption">
          <span>{t("Архитектурная визуализация")}</span>
          <span>{t("Точная обработка стали")}</span>
        </div>
      </section>
    </>
  );
}
