"use client";
import { useEffect } from "react";
import Lenis from "lenis";
import "lenis/dist/lenis.css";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
export default function SmoothScroll({ reduce }: { reduce: boolean }) {
  useEffect(() => {
    if (reduce) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = matchMedia(
      "(min-width: 761px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)",
    );
    let dispose = () => {};
    const setup = () => {
      dispose();
      if (!media.matches) return;
      const lenis = new Lenis({
        duration: 1.1,
        smoothWheel: true,
        syncTouch: false,
        anchors: true,
      });
      // Lenis needs frames while scrolling, not a permanent GSAP ticker listener.
      let frame = 0;
      let previousFrame = 0;
      let animationTime = 0;
      const tick = (time: number) => {
        frame = 0;
        if (document.hidden) return;
        // Keep Lenis' animation clock continuous across idle periods. Passing
        // wall time after a long pause would complete the next wheel gesture.
        animationTime += previousFrame ? time - previousFrame : 16.67;
        previousFrame = time;
        lenis.raf(animationTime);
        if (lenis.isScrolling) wake();
        else previousFrame = 0;
      };
      const wake = () => {
        if (!frame && !document.hidden) frame = requestAnimationFrame(tick);
      };
      const scroll = () => {
        ScrollTrigger.update();
        if (lenis.isScrolling) wake();
      };
      const key = (event: KeyboardEvent) => {
        if (
          [
            "ArrowDown",
            "ArrowUp",
            "PageDown",
            "PageUp",
            "Home",
            "End",
            " ",
          ].includes(event.key)
        )
          wake();
      };
      const anchor = (event: MouseEvent) => {
        if (
          event.target instanceof Element &&
          event.target.closest('a[href*="#"]')
        )
          wake();
      };
      const visibility = () => {
        cancelAnimationFrame(frame);
        frame = 0;
        previousFrame = 0;
        if (!document.hidden && lenis.isScrolling) wake();
      };
      lenis.on("scroll", scroll);
      window.addEventListener("wheel", wake, { passive: true });
      window.addEventListener("keydown", key);
      document.addEventListener("click", anchor);
      document.addEventListener("visibilitychange", visibility);
      dispose = () => {
        cancelAnimationFrame(frame);
        lenis.off("scroll", scroll);
        window.removeEventListener("wheel", wake);
        window.removeEventListener("keydown", key);
        document.removeEventListener("click", anchor);
        document.removeEventListener("visibilitychange", visibility);
        lenis.destroy();
      };
    };
    setup();
    media.addEventListener("change", setup);
    return () => {
      dispose();
      media.removeEventListener("change", setup);
    };
  }, [reduce]);
  return null;
}
