"use client";
import { useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

/** Native touch scroll gets light motion; desktop gets richer choreography. */
export default function SignatureMotion({
  reduce,
  revision,
}: {
  reduce: boolean;
  revision: string;
}) {
  useEffect(() => {
    if (reduce) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    // Progress and architectural image motion also work with native touch scrolling.
    media.add(
      "(hover:hover) and (pointer:fine) and (min-width:761px) and (prefers-reduced-motion:no-preference)",
      () => {
        gsap.fromTo(
          ".reading-progress",
          { scaleX: 0 },
          {
            scaleX: 1,
            ease: "none",
            scrollTrigger: {
              trigger: document.documentElement,
              start: "top top",
              end: "bottom bottom",
              scrub: true,
            },
          },
        );
        gsap.utils.toArray<HTMLElement>(".section-top").forEach((section) => {
          gsap.fromTo(
            section,
            { "--rule-progress": 0 },
            {
              "--rule-progress": 1,
              duration: 1.2,
              ease: "power3.out",
              scrollTrigger: { trigger: section, start: "top 90%", once: true },
            },
          );
        });
      },
    );
    media.add(
      "(min-width:761px) and (hover:hover) and (pointer:fine) and (prefers-reduced-motion:no-preference)",
      () => {
        const context = gsap.context(() => {
          gsap.fromTo(
            ".signature-ribbon-track",
            { xPercent: 4 },
            {
              xPercent: -18,
              ease: "none",
              scrollTrigger: {
                trigger: ".signature-ribbon",
                start: "top bottom",
                end: "bottom top",
                scrub: 1,
              },
            },
          );
          gsap.fromTo(
            ".architecture-photo",
            { yPercent: -6, scale: 1.16 },
            {
              yPercent: 6,
              scale: 1.16,
              ease: "none",
              scrollTrigger: {
                trigger: ".architecture-story",
                start: "top bottom",
                end: "bottom top",
                scrub: 1,
              },
            },
          );
          gsap.fromTo(
            ".architecture-copy",
            { y: 50 },
            {
              y: -30,
              ease: "none",
              scrollTrigger: {
                trigger: ".architecture-story",
                start: "top bottom",
                end: "bottom top",
                scrub: 1,
              },
            },
          );
          gsap.utils
            .toArray<HTMLElement>(
              ".section-heading h2 > span,.safety-copy h2 > span",
            )
            .forEach((accent) => {
              gsap.fromTo(
                accent,
                { x: 18 },
                {
                  x: -10,
                  ease: "none",
                  scrollTrigger: {
                    trigger: accent.closest("section"),
                    start: "top bottom",
                    end: "center top",
                    scrub: 1,
                  },
                },
              );
            });
          gsap.fromTo(
            ".contact-monogram",
            { xPercent: -4 },
            {
              xPercent: 4,
              ease: "none",
              scrollTrigger: {
                trigger: ".contact",
                start: "top bottom",
                end: "bottom top",
                scrub: 1,
              },
            },
          );
          gsap.utils
            .toArray<HTMLElement>(".model-image,.project-image")
            .forEach((frame) => {
              const photo = frame.querySelector("img");
              if (photo)
                gsap.fromTo(
                  photo,
                  { translate: "0 -3%" },
                  {
                    translate: "0 3%",
                    ease: "none",
                    scrollTrigger: {
                      trigger: frame,
                      start: "top bottom",
                      end: "bottom top",
                      scrub: 0.8,
                    },
                  },
                );
            });
        });
        const observer = new IntersectionObserver((entries) =>
          entries.forEach((entry) => {
            (entry.target as HTMLElement).dataset.illuminated = String(
              entry.isIntersecting && !document.hidden,
            );
          }),
        );
        const lights = document.querySelectorAll<HTMLElement>(
          ".hero-stage,.configurator",
        );
        lights.forEach((el) => observer.observe(el));
        const visibility = () => {
          lights.forEach((el) => {
            const r = el.getBoundingClientRect();
            el.dataset.illuminated = String(
              !document.hidden && r.bottom > 0 && r.top < innerHeight,
            );
          });
        };
        document.addEventListener("visibilitychange", visibility);
        return () => {
          context.revert();
          observer.disconnect();
          lights.forEach((el) => delete el.dataset.illuminated);
          document.removeEventListener("visibilitychange", visibility);
        };
      },
    );
    let alive = true;
    let frame = 0;
    const refresh = () => {
      if (!alive || frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        if (alive) ScrollTrigger.refresh();
      });
    };
    document.fonts.ready.then(refresh);
    const images = Array.from(
      document.querySelectorAll<HTMLImageElement>("main img"),
    ).filter((img) => !img.complete);
    images.forEach((img) =>
      img.addEventListener("load", refresh, { once: true }),
    );
    return () => {
      alive = false;
      cancelAnimationFrame(frame);
      images.forEach((img) => img.removeEventListener("load", refresh));
      media.revert();
    };
  }, [reduce, revision]);
  return <div className="reading-progress" aria-hidden="true" />;
}
