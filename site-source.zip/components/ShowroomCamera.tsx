"use client";
import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Vector3 } from "three";
type Controls = {
  target: Vector3;
  update: () => void;
  addEventListener: (type: "start", fn: () => void) => void;
  removeEventListener: (type: "start", fn: () => void) => void;
};
import { showroomPose, type ShowroomView } from "@/lib/showroom-camera";
export default function ShowroomCamera({
  view,
  reduce,
  shot,
  onExport,
  onReady,
}: {
  view: ShowroomView;
  reduce: boolean;
  shot: number;
  onExport?: (ok: boolean) => void;
  onReady?: (ready: boolean) => void;
}) {
  const { camera, controls, size, invalidate, gl, scene } = useThree();
  const destination = useRef(new Vector3()),
    target = useRef(new Vector3());
  const active = useRef(false),
    previousShot = useRef(shot);
  useEffect(() => {
    onReady?.(true);
    return () => onReady?.(false);
  }, [onReady]);
  useEffect(() => {
    const pose = showroomPose(view, size.width / Math.max(1, size.height));
    destination.current.fromArray(pose.position);
    target.current.fromArray(pose.target);
    active.current = true;
    invalidate();
  }, [view, size.width, size.height, camera, invalidate]);
  useEffect(() => {
    const orbit = controls as unknown as Controls | undefined;
    if (!orbit) return;
    const stop = () => {
      active.current = false;
    };
    orbit.addEventListener("start", stop);
    return () => orbit.removeEventListener("start", stop);
  }, [controls]);
  useEffect(() => {
    if (shot === previousShot.current) return;
    previousShot.current = shot;
    // Render immediately before copying; no permanent preserveDrawingBuffer allocation.
    try {
      gl.render(scene, camera);
      const output = document.createElement("canvas");
      output.width = gl.domElement.width;
      output.height = gl.domElement.height;
      const ctx = output.getContext("2d");
      if (!ctx) {
        onExport?.(false);
        return;
      }
      ctx.fillStyle = "#f1eee8";
      ctx.fillRect(0, 0, output.width, output.height);
      ctx.drawImage(gl.domElement, 0, 0);
      output.toBlob((blob) => {
        if (!blob) {
          onExport?.(false);
          return;
        }
        const url = URL.createObjectURL(blob),
          link = document.createElement("a");
        link.href = url;
        link.download = "inox-atelier-configuration.png";
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        onExport?.(true);
      }, "image/png");
    } catch {
      onExport?.(false);
    }
  }, [shot, gl, scene, camera, onExport]);
  useFrame((_, dt) => {
    if (!active.current) return;
    const orbit = controls as unknown as Controls | undefined;
    if (!orbit) return;
    const k = reduce ? 1 : 1 - Math.exp(-7 * Math.min(dt, 0.05));
    camera.position.lerp(destination.current, k);
    orbit.target.lerp(target.current, k);
    orbit.update();
    if (
      camera.position.distanceTo(destination.current) < 0.005 &&
      orbit.target.distanceTo(target.current) < 0.005
    ) {
      active.current = false;
    } else invalidate();
  });
  return null;
}
