"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { Pause, Play } from "lucide-react";
import { gsap } from "gsap";
import { useLocale, SceneLoading } from "./LocaleProvider";
import { SAFETY_DURATION, type SafetyTimeline } from "@/lib/safety-motion";

const Scene = dynamic(() => import("./Scene"), {
  ssr: false,
  loading: SceneLoading,
});

export default function SafetyPlayer({
  safe,
  reduce,
}: {
  safe: boolean;
  reduce: boolean;
}) {
  const { t } = useLocale();
  const host = useRef<HTMLDivElement>(null);
  const range = useRef<HTMLInputElement>(null);
  const clock = useRef<HTMLSpanElement>(null);
  const timeline = useRef<SafetyTimeline>({ progress: 0, requestFrame: null });
  const tween = useRef<gsap.core.Tween | null>(null);
  const [playing, setPlaying] = useState(false);

  const sync = useCallback(() => {
    const p = timeline.current.progress;
    if (range.current) range.current.value = String(p);
    if (clock.current)
      clock.current.textContent = `${(p * SAFETY_DURATION).toFixed(1)} / ${SAFETY_DURATION}`;
    timeline.current.requestFrame?.();
  }, []);
  const stop = useCallback(() => {
    tween.current?.kill();
    tween.current = null;
    setPlaying(false);
  }, []);
  useEffect(() => {
    stop();
    timeline.current.progress = 0;
    sync();
  }, [safe, reduce, stop, sync]);
  useEffect(() => {
    const visibility = () => {
      if (document.hidden) stop();
    };
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) stop();
    });
    if (host.current) observer.observe(host.current);
    document.addEventListener("visibilitychange", visibility);
    return () => {
      tween.current?.kill();
      observer.disconnect();
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [stop]);
  const play = () => {
    if (playing) {
      stop();
      return;
    }
    if (reduce) return;
    if (timeline.current.progress >= 0.999) timeline.current.progress = 0;
    setPlaying(true);
    sync();
    tween.current = gsap.to(timeline.current, {
      progress: 1,
      duration: SAFETY_DURATION * (1 - timeline.current.progress),
      ease: "none",
      onUpdate: sync,
      onComplete: () => {
        tween.current = null;
        setPlaying(false);
      },
    });
  };
  return (
    <div
      ref={host}
      className="safety-visual"
      data-safety={safe ? "protected" : "risk"}
    >
      <div className="safety-status">
        <span className={safe ? "" : "risk"} />
        {safe ? t("СЦЕНАРИЙ С ЗАЩИТОЙ") : t("СЦЕНАРИЙ БЕЗ ЗАЩИТЫ")}
      </div>
      <div className="safety-canvas" data-lenis-prevent>
        <Scene
          kind="safety"
          safe={safe}
          safetyTimeline={timeline}
          reduce={reduce}
        />
      </div>
      <div className="safety-controls">
        <button
          className="icon-button"
          aria-label={playing ? t("Остановить") : t("Воспроизвести сценарий")}
          disabled={reduce}
          onClick={play}
        >
          {playing ? <Pause size={18} /> : <Play size={18} />}
        </button>
        <label>
          {t("Ход сценария")}
          <input
            ref={range}
            type="range"
            min="0"
            max="1"
            step=".001"
            defaultValue="0"
            onPointerDown={stop}
            onKeyDown={stop}
            onChange={(e) => {
              stop();
              timeline.current.progress = Number(e.target.value);
              sync();
            }}
          />
        </label>
        <span className="safety-time" aria-hidden="true" ref={clock}>
          0.0 / 5
        </span>
      </div>
      {reduce && <span className="safety-manual">{t("Ручной режим")}</span>}
    </div>
  );
}
