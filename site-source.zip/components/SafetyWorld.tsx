"use client";
import { useEffect, useMemo, useRef, type RefObject } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  BoxGeometry,
  CapsuleGeometry,
  CylinderGeometry,
  EdgesGeometry,
  Group,
  Mesh,
  MeshBasicMaterial,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  LineBasicMaterial,
  SphereGeometry,
  Vector2,
} from "three";
import { Beam } from "./Railing";
import { safetyTextures } from "@/lib/safety-textures";
import { GLASS_Z, safetyPose, type SafetyTimeline } from "@/lib/safety-motion";

type Bundle = ReturnType<typeof createResources>;
function createResources(low: boolean) {
  const n = low ? 12 : 20;
  const maps = safetyTextures();
  const glassBox = new BoxGeometry(1.28, 1.13, 0.032);
  return {
    maps,
    geo: {
      sphere: new SphereGeometry(1, n, low ? 10 : 16),
      capsule: new CapsuleGeometry(0.1, 0.4, 4, n),
      glass: glassBox,
      edges: new EdgesGeometry(glassBox),
      foot: new CylinderGeometry(0.1, 0.115, 0.04, n),
    },
    mat: {
      steel: new MeshStandardMaterial({
        color: "#c3cdd0",
        metalness: 0.96,
        roughness: 0.31,
        envMapIntensity: 1.15,
      }),
      glass: new MeshPhysicalMaterial({
        color: "#c9dfe5",
        transmission: 0.94,
        opacity: 1,
        roughness: 0.055,
        metalness: 0,
        ior: 1.5,
        thickness: 0.032,
        attenuationColor: "#a8c4d0",
        attenuationDistance: 0.65,
        envMapIntensity: 0.9,
        clearcoat: 0.35,
        clearcoatRoughness: 0.08,
      }),
      edge: new LineBasicMaterial({
        color: "#d8edf1",
        transparent: true,
        opacity: 0.8,
      }),
      coat: new MeshStandardMaterial({ color: "#444f50", roughness: 0.85 }),
      trousers: new MeshStandardMaterial({ color: "#273332", roughness: 0.92 }),
      child: new MeshStandardMaterial({ color: "#d3ad76", roughness: 0.85 }),
      childPants: new MeshStandardMaterial({
        color: "#98876f",
        roughness: 0.9,
      }),
      skin: new MeshStandardMaterial({ color: "#cbb69a", roughness: 0.78 }),
      hair: new MeshStandardMaterial({ color: "#59483c", roughness: 0.92 }),
      shoes: new MeshStandardMaterial({ color: "#26312f", roughness: 0.85 }),
      phone: new MeshStandardMaterial({
        color: "#192626",
        metalness: 0.45,
        roughness: 0.3,
      }),
      screen: new MeshStandardMaterial({
        color: "#b8c9bb",
        emissive: "#b8c9bb",
        emissiveIntensity: 0.15,
        roughness: 0.3,
      }),
      stone: new MeshStandardMaterial({
        color: "#b8b2a3",
        map: maps.stone,
        normalMap: maps.stoneNormal,
        normalScale: new Vector2(0.24, 0.24),
        roughness: 0.82,
      }),
      slab: new MeshStandardMaterial({ color: "#777c73", roughness: 0.9 }),
      wall: new MeshStandardMaterial({ color: "#33423d", roughness: 0.95 }),
      ao: new MeshBasicMaterial({
        map: maps.contact,
        transparent: true,
        depthWrite: false,
        toneMapped: false,
        opacity: 0.9,
      }),
    },
  };
}
function Form({
  resources: r,
  material,
  position,
  scale,
}: {
  resources: Bundle;
  material: MeshStandardMaterial;
  position: [number, number, number];
  scale: [number, number, number];
}) {
  return (
    <mesh
      geometry={r.geo.sphere}
      material={material}
      position={position}
      scale={scale}
      castShadow
    />
  );
}
function Contact({
  r,
  position,
  scale = [0.5, 0.4],
}: {
  r: Bundle;
  position: [number, number, number];
  scale?: [number, number];
}) {
  return (
    <mesh
      position={position}
      rotation={[-Math.PI / 2, 0, 0]}
      material={r.mat.ao}
    >
      <planeGeometry args={scale} />
    </mesh>
  );
}
function Adult({ r }: { r: Bundle }) {
  return (
    <group>
      <mesh
        geometry={r.geo.capsule}
        material={r.mat.coat}
        position={[0, 1.05, 0]}
        scale={[2.2, 1.22, 1.6]}
        castShadow
      />
      <Form
        resources={r}
        material={r.mat.skin}
        position={[0, 1.58, 0.015]}
        scale={[0.157, 0.19, 0.15]}
      />
      <Form
        resources={r}
        material={r.mat.hair}
        position={[0, 1.65, -0.065]}
        scale={[0.166, 0.155, 0.12]}
      />
      <Form
        resources={r}
        material={r.mat.skin}
        position={[0, 1.39, 0]}
        scale={[0.078, 0.12, 0.075]}
      />
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh
            geometry={r.geo.capsule}
            material={r.mat.trousers}
            position={[s * 0.11, 0.38, 0]}
            scale={[0.9, 1.08, 0.95]}
            castShadow
          />
          <Form
            resources={r}
            material={r.mat.shoes}
            position={[s * 0.11, 0.058, 0.055]}
            scale={[0.1, 0.06, 0.16]}
          />
        </group>
      ))}
      <group position={[-0.22, 1.26, 0]} rotation={[0.06, 0, -0.12]}>
        <Form
          resources={r}
          material={r.mat.coat}
          position={[0, -0.22, 0]}
          scale={[0.083, 0.25, 0.087]}
        />
        <Form
          resources={r}
          material={r.mat.skin}
          position={[0, -0.49, 0.025]}
          scale={[0.065, 0.095, 0.065]}
        />
      </group>
      <group position={[0.23, 1.26, 0]} rotation={[-1.25, 0, 0.25]}>
        <Form
          resources={r}
          material={r.mat.coat}
          position={[0, -0.17, 0]}
          scale={[0.087, 0.21, 0.09]}
        />
        <group position={[0, -0.31, 0]} rotation={[-1.65, 0, 0]}>
          <Form
            resources={r}
            material={r.mat.skin}
            position={[0, -0.14, 0]}
            scale={[0.068, 0.18, 0.068]}
          />
          <mesh
            position={[0, -0.28, 0.02]}
            rotation={[0.1, 0, 0.05]}
            material={r.mat.phone}
            castShadow
          >
            <boxGeometry args={[0.095, 0.18, 0.024]} />
          </mesh>
          <mesh position={[0, -0.28, 0.034]} material={r.mat.screen}>
            <planeGeometry args={[0.076, 0.14]} />
          </mesh>
        </group>
      </group>
    </group>
  );
}
function Child({
  r,
  legs,
  arms,
}: {
  r: Bundle;
  legs: RefObject<(Group | null)[]>;
  arms: RefObject<(Group | null)[]>;
}) {
  return (
    <group>
      <Form
        resources={r}
        material={r.mat.child}
        position={[0, 0.6, 0]}
        scale={[0.2, 0.28, 0.155]}
      />
      <Form
        resources={r}
        material={r.mat.childPants}
        position={[0, 0.34, 0]}
        scale={[0.165, 0.12, 0.13]}
      />
      <Form
        resources={r}
        material={r.mat.skin}
        position={[0, 0.995, 0.025]}
        scale={[0.173, 0.185, 0.163]}
      />
      <Form
        resources={r}
        material={r.mat.hair}
        position={[0, 1.065, -0.038]}
        scale={[0.175, 0.127, 0.14]}
      />
      <Form
        resources={r}
        material={r.mat.skin}
        position={[0, 0.82, 0]}
        scale={[0.075, 0.085, 0.074]}
      />
      {[-1, 1].map((s, i) => (
        <group key={s}>
          <group
            ref={(el) => {
              legs.current[i] = el;
            }}
            position={[s * 0.09, 0.36, 0]}
          >
            <Form
              resources={r}
              material={r.mat.childPants}
              position={[0, -0.14, 0]}
              scale={[0.077, 0.165, 0.078]}
            />
            <Form
              resources={r}
              material={r.mat.shoes}
              position={[0, -0.31, 0.045]}
              scale={[0.078, 0.05, 0.12]}
            />
          </group>
          <group
            ref={(el) => {
              arms.current[i] = el;
            }}
            position={[s * 0.18, 0.74, 0]}
            rotation={[0, 0, s * 0.12]}
          >
            <Form
              resources={r}
              material={r.mat.child}
              position={[0, -0.1, 0]}
              scale={[0.069, 0.145, 0.072]}
            />
            <Form
              resources={r}
              material={r.mat.skin}
              position={[0, -0.25, 0]}
              scale={[0.059, 0.076, 0.058]}
            />
          </group>
        </group>
      ))}
    </group>
  );
}
function Guardrail({ r, low }: { r: Bundle; low: boolean }) {
  return (
    <group position={[0, 0, GLASS_Z]}>
      {[-2.1, -0.7, 0.7, 2.1].map((x) => (
        <group key={x} position={[x, 0, 0]}>
          <Contact r={r} position={[0, 0.012, 0]} scale={[0.42, 0.42]} />
          <mesh
            geometry={r.geo.foot}
            material={r.mat.steel}
            position={[0, 0.025, 0]}
            castShadow
          />
          <Beam
            from={[0, 0.04, 0]}
            to={[0, 1.34, 0]}
            radius={0.035}
            material={r.mat.steel}
            segments={low ? 12 : 20}
          />
          {[0.25, 1.12].map((y) => (
            <mesh
              key={y}
              position={[0, y, -0.023]}
              material={r.mat.steel}
              castShadow
            >
              <boxGeometry args={[0.13, 0.075, 0.065]} />
            </mesh>
          ))}
        </group>
      ))}
      <Beam
        from={[-2.23, 1.37, 0]}
        to={[2.23, 1.37, 0]}
        radius={0.046}
        material={r.mat.steel}
        segments={low ? 12 : 20}
      />
      {[-1.4, 0, 1.4].map((x) => (
        <group key={x} position={[x, 0.715, 0]}>
          <mesh geometry={r.geo.glass} material={r.mat.glass} />
          <lineSegments geometry={r.geo.edges} material={r.mat.edge} />
        </group>
      ))}
    </group>
  );
}

export function SafetyWorld({
  safe,
  timeline,
  low = false,
}: {
  safe: boolean;
  timeline?: RefObject<SafetyTimeline>;
  low?: boolean;
}) {
  const r = useMemo(() => createResources(low), [low]);
  const child = useRef<Group>(null);
  const mother = useRef<Group>(null);
  const shadow = useRef<Group>(null);
  const legs = useRef<(Group | null)[]>([]);
  const arms = useRef<(Group | null)[]>([]);
  const halo = useRef<Mesh>(null);
  const { invalidate, gl } = useThree();
  useEffect(() => {
    // One shared reduced-resolution transmission buffer, no post effects.
    const previous = gl.transmissionResolutionScale;
    gl.transmissionResolutionScale = low ? 0.5 : 0.75;
    if (timeline) timeline.current.requestFrame = invalidate;
    invalidate();
    return () => {
      if (timeline) timeline.current.requestFrame = null;
      gl.transmissionResolutionScale = previous;
    };
  }, [gl, low, timeline, invalidate]);
  useEffect(
    () => () => {
      Object.values(r.geo).forEach((g) => g.dispose());
      Object.values(r.mat).forEach((m) => m.dispose());
      Object.values(r.maps).forEach((t) => t.dispose());
    },
    [r],
  );
  useFrame(() => {
    const p = timeline?.current.progress ?? 0;
    const pose = safetyPose(p, safe);
    if (child.current) {
      child.current.position.set(pose.x, pose.y, pose.z);
      child.current.rotation.set(pose.lean, 0.07, 0);
    }
    legs.current.forEach((g, i) => {
      if (g) g.rotation.x = pose.stride * (i ? 0.48 : -0.48);
    });
    arms.current.forEach((g, i) => {
      if (g) g.rotation.x = -pose.reach * 1.2 + pose.stride * (i ? -0.3 : 0.3);
    });
    if (mother.current) mother.current.rotation.y = pose.motherTurn;
    if (shadow.current) {
      shadow.current.position.set(pose.x, 0.012, Math.min(pose.z, 1.61));
      shadow.current.scale.setScalar(pose.shadow);
    }
    if (halo.current)
      (halo.current.material as MeshBasicMaterial).opacity = safe
        ? 0.36
        : 0.42 + p * 0.18;
  });
  return (
    <group position={[0, -0.7, 0]}>
      <mesh position={[0, -0.145, 0]} material={r.mat.slab} receiveShadow>
        <boxGeometry args={[4.8, 0.29, 3.3]} />
      </mesh>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0.002, 0]}
        material={r.mat.stone}
        receiveShadow
      >
        <planeGeometry args={[4.8, 3.3]} />
      </mesh>
      <mesh position={[0, -0.85, -1.58]} material={r.mat.wall}>
        <boxGeometry args={[4.8, 1.45, 0.12]} />
      </mesh>
      <mesh position={[-2.38, 0.64, -0.2]} material={r.mat.wall} receiveShadow>
        <boxGeometry args={[0.1, 1.28, 2.9]} />
      </mesh>
      <Contact r={r} position={[-2.25, 0.01, -0.2]} scale={[0.6, 2.85]} />
      <Contact r={r} position={[-1.45, 0.011, -0.55]} scale={[0.9, 0.65]} />
      <group ref={mother} position={[-1.45, 0, -0.55]}>
        <Adult r={r} />
      </group>
      <group ref={shadow}>
        <Contact r={r} position={[0, 0, 0]} scale={[0.7, 0.53]} />
      </group>
      <group ref={child}>
        <Child r={r} legs={legs} arms={arms} />
      </group>
      {/* Keep shared meshes allocated across scenario switches. */}
      <group visible={safe}>
        <Guardrail r={r} low={low} />
      </group>
      <mesh
        ref={halo}
        position={[0, 0.008, 1.48]}
        rotation={[-Math.PI / 2, 0, 0]}
      >
        <planeGeometry args={[4.7, 0.7]} />
        <meshBasicMaterial
          map={r.maps.halo}
          color={safe ? "#b7c49c" : "#e49571"}
          transparent
          opacity={0.4}
          depthWrite={false}
          toneMapped={false}
        />
      </mesh>
      <mesh position={[0, 0.013, 1.61]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[4.65, 0.018]} />
        <meshBasicMaterial
          color={safe ? "#b9c6a4" : "#df977a"}
          toneMapped={false}
        />
      </mesh>
      <mesh
        position={[1.65, 0.14, -1.02]}
        material={r.mat.slab}
        castShadow
        receiveShadow
      >
        <boxGeometry args={[0.72, 0.28, 0.55]} />
      </mesh>
      <mesh
        position={[1.65, 0.29, -1.02]}
        rotation={[-Math.PI / 2, 0, 0]}
        material={r.mat.stone}
      >
        <planeGeometry args={[0.72, 0.55]} />
      </mesh>
      <Contact r={r} position={[1.65, 0.01, -1.02]} scale={[1.15, 0.85]} />
    </group>
  );
}
