"use client";

import { useEffect, useRef, useState } from "react";
import { useLocale } from "./LocaleProvider";
import { Volume2, VolumeX } from "lucide-react";

/** Progressive enhancement only: no custom cursor on touch or reduced motion. */
export default function LuxuryEffects({ reduce }: { reduce: boolean }) {
  const { t } = useLocale();
  const cursor = useRef<HTMLDivElement>(null);
  const audio = useRef<AudioContext | null>(null);
  const [sound, setSound] = useState(false);

  useEffect(() => {
    const media = matchMedia(
      "(min-width: 761px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference) and (forced-colors: none)",
    );
    let cleanup = () => {};
    const setup = () => {
      cleanup();
      if (!media.matches || reduce || !cursor.current) return;
      const dot = cursor.current;
      const root = document.documentElement;
      const hero = document.querySelector<HTMLElement>(".hero-stage");
      root.dataset.pointerMotion = "true";
      let frame = 0,
        previous = 0,
        x = -100,
        y = -100,
        targetX = -100,
        targetY = -100;
      let magnet: HTMLElement | null = null,
        card: HTMLElement | null = null;
      let magnetBox: DOMRect | null = null,
        cardBox: DOMRect | null = null,
        heroBox: DOMRect | null = null;
      let mx = 0,
        my = 0,
        tx = 0,
        ty = 0,
        hx = 0,
        hy = 0;
      let targetMX = 0,
        targetMY = 0,
        targetTX = 0,
        targetTY = 0,
        targetHX = 0,
        targetHY = 0;
      const clearTarget = () => {
        magnet?.style.removeProperty("--magnet-x");
        magnet?.style.removeProperty("--magnet-y");
        ["--tilt-x", "--tilt-y", "--image-x", "--image-y"].forEach((property) =>
          card?.style.removeProperty(property),
        );
        magnet = card = null;
        magnetBox = cardBox = null;
        mx = my = tx = ty = targetMX = targetMY = targetTX = targetTY = 0;
      };
      const draw = (time: number) => {
        const alpha =
          1 - Math.exp(-Math.min(50, previous ? time - previous : 16) / 55);
        previous = time;
        // Keep the actual hit point precise; only decorative surfaces ease.
        x = targetX;
        y = targetY;
        mx += (targetMX - mx) * alpha;
        my += (targetMY - my) * alpha;
        tx += (targetTX - tx) * alpha;
        ty += (targetTY - ty) * alpha;
        hx += (targetHX - hx) * alpha;
        hy += (targetHY - hy) * alpha;
        dot.style.transform = `translate3d(${x}px,${y}px,0)`;
        if (magnet) {
          magnet.style.setProperty("--magnet-x", `${mx}px`);
          magnet.style.setProperty("--magnet-y", `${my}px`);
        }
        if (card) {
          card.style.setProperty("--tilt-x", `${tx}deg`);
          card.style.setProperty("--tilt-y", `${ty}deg`);
          card.style.setProperty("--image-x", `${ty * 3}px`);
          card.style.setProperty("--image-y", `${-tx * 3}px`);
        }
        if (hero) {
          hero.style.setProperty("--hero-x", `${hx}px`);
          hero.style.setProperty("--hero-y", `${hy}px`);
        }
        const distance =
          Math.abs(targetX - x) +
          Math.abs(targetY - y) +
          Math.abs(targetMX - mx) +
          Math.abs(targetMY - my) +
          Math.abs(targetTX - tx) +
          Math.abs(targetTY - ty) +
          Math.abs(targetHX - hx) +
          Math.abs(targetHY - hy);
        if (distance > 0.03) frame = requestAnimationFrame(draw);
        else {
          frame = 0;
          previous = 0;
        }
      };
      const wake = () => {
        if (!frame) frame = requestAnimationFrame(draw);
      };
      const move = (event: PointerEvent) => {
        if (event.pointerType !== "mouse" || document.hidden) return;
        const element = event.target instanceof Element ? event.target : null;
        if (!element) return;
        const native = !!element.closest("canvas,input,textarea,select,dialog");
        root.classList.toggle("cursor-enhanced", !native);
        dot.dataset.visible = String(!native);
        dot.dataset.active = String(!!element.closest("a,button,label"));
        dot.dataset.card = String(!!element.closest(".model-card,.project"));
        targetX = event.clientX;
        targetY = event.clientY;
        if (x === -100) {
          x = targetX;
          y = targetY;
        }
        const nextMagnet = native
          ? null
          : element.closest<HTMLElement>(
              ".button,.text-button,.header nav a,.header-phone,footer > a:last-child",
            );
        const nextCard = native
          ? null
          : element.closest<HTMLElement>(".model-card,.project");
        if (nextMagnet !== magnet || nextCard !== card) {
          clearTarget();
          magnet = nextMagnet;
          card = nextCard;
          magnetBox = magnet?.getBoundingClientRect() ?? null;
          cardBox = card?.getBoundingClientRect() ?? null;
        }
        if (magnetBox) {
          targetMX = Math.max(
            -7,
            Math.min(
              7,
              (targetX - magnetBox.left - magnetBox.width / 2) * 0.065,
            ),
          );
          targetMY = Math.max(
            -5,
            Math.min(5, (targetY - magnetBox.top - magnetBox.height / 2) * 0.1),
          );
        }
        if (cardBox) {
          targetTX =
            (-(targetY - cardBox.top - cardBox.height / 2) / cardBox.height) *
            2.4;
          targetTY =
            ((targetX - cardBox.left - cardBox.width / 2) / cardBox.width) *
            2.4;
        }
        if (element.closest(".hero-stage") && hero) {
          heroBox ??= hero.getBoundingClientRect();
          targetHX =
            ((targetX - heroBox.left - heroBox.width / 2) / heroBox.width) * 12;
          targetHY =
            ((targetY - heroBox.top - heroBox.height / 2) / heroBox.height) * 8;
        } else {
          targetHX = targetHY = 0;
        }
        wake();
      };
      const hide = () => {
        cancelAnimationFrame(frame);
        frame = 0;
        previous = 0;
        dot.dataset.visible = "false";
        root.classList.remove("cursor-enhanced");
        clearTarget();
        hero?.style.removeProperty("--hero-x");
        hero?.style.removeProperty("--hero-y");
        heroBox = null;
        hx = hy = targetHX = targetHY = 0;
      };
      const scroll = () => {
        clearTarget();
        heroBox = null;
      };
      const key = (event: KeyboardEvent) => {
        if (event.key === "Tab" || event.key === "Escape") hide();
      };
      window.addEventListener("pointermove", move, { passive: true });
      window.addEventListener("scroll", scroll, { passive: true });
      window.addEventListener("resize", hide);
      window.addEventListener("blur", hide);
      window.addEventListener("keydown", key);
      document.addEventListener("pointerleave", hide);
      document.addEventListener("visibilitychange", hide);
      cleanup = () => {
        hide();
        delete root.dataset.pointerMotion;
        window.removeEventListener("pointermove", move);
        window.removeEventListener("scroll", scroll);
        window.removeEventListener("resize", hide);
        window.removeEventListener("blur", hide);
        window.removeEventListener("keydown", key);
        document.removeEventListener("pointerleave", hide);
        document.removeEventListener("visibilitychange", hide);
      };
    };
    setup();
    media.addEventListener("change", setup);
    return () => {
      cleanup();
      media.removeEventListener("change", setup);
    };
  }, [reduce]);

  useEffect(() => {
    if (!sound) return;
    const click = (e: PointerEvent) => {
      if (
        !(e.target instanceof Element) ||
        !e.target.closest("button,a") ||
        !audio.current
      )
        return;
      const ctx = audio.current;
      if (ctx.state !== "running") return;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.025, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.075);
      gain.connect(ctx.destination);
      const oscillator = ctx.createOscillator();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(650, ctx.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(
        90,
        ctx.currentTime + 0.075,
      );
      oscillator.connect(gain);
      oscillator.start();
      oscillator.stop(ctx.currentTime + 0.08);
      oscillator.onended = () => {
        oscillator.disconnect();
        gain.disconnect();
      };
    };
    document.addEventListener("pointerdown", click);
    return () => document.removeEventListener("pointerdown", click);
  }, [sound]);
  useEffect(
    () => () => {
      void audio.current?.close();
    },
    [],
  );

  async function toggleSound() {
    if (sound) {
      setSound(false);
      return;
    }
    try {
      audio.current ??= new AudioContext();
      await audio.current.resume();
      setSound(true);
    } catch {
      setSound(false);
    }
  }
  return (
    <>
      <div className="film-grain" aria-hidden="true" />
      <div ref={cursor} className="luxury-cursor" aria-hidden="true">
        <svg
          className="cursor-mark"
          viewBox="0 0 32 32"
          width="32"
          height="32"
          fill="none"
          aria-hidden="true"
        >
          <g className="cursor-cross">
            <path d="M16 5v8m0 6v8M5 16h8m6 0h8" />
            <path className="cursor-center" d="M15.5 15.5h1v1h-1z" />
          </g>
          <g className="cursor-arrow">
            <path d="M10 22 22 10M11 10h11v11" />
          </g>
          <g className="cursor-brackets">
            <path d="M3 10V3h7m12 0h7v7M3 22v7h7m12 0h7v-7" />
          </g>
        </svg>
      </div>
      <button
        className="sound-switch"
        onClick={toggleSound}
        aria-label={
          sound
            ? t("Выключить звуковые эффекты")
            : t("Включить звуковые эффекты")
        }
        aria-pressed={sound}
      >
        {sound ? <Volume2 size={14} /> : <VolumeX size={14} />}
        <span>
          {t("ЗВУК")} {sound ? t("ВКЛ") : t("ВЫКЛ")}
        </span>
      </button>
    </>
  );
}
