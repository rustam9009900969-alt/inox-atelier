"use client";
import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { BokehPass } from "three/addons/postprocessing/BokehPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";

/** The complete pass chain is removed on mobile or a quality downgrade. */
export function Cinema() {
  const { gl, scene, camera, size, viewport, invalidate } = useThree();
  const current = useRef<{ composer: EffectComposer; bokeh: BokehPass } | null>(
    null,
  );
  useEffect(() => {
    const composer = new EffectComposer(gl);
    const render = new RenderPass(scene, camera);
    const bokeh = new BokehPass(scene, camera, {
      focus: 9,
      aperture: 0.000018,
      maxblur: 0.004,
    });
    // Three's stock BokehShader forces alpha to 1, hiding the typography behind
    // the transparent Canvas. Keep the averaged sample alpha instead.
    bokeh.materialBokeh.fragmentShader =
      bokeh.materialBokeh.fragmentShader.replace("gl_FragColor.a = 1.0;", "");
    const output = new OutputPass();
    composer.addPass(render);
    composer.addPass(bokeh);
    composer.addPass(output);
    current.current = { composer, bokeh };
    invalidate();
    return () => {
      current.current = null;
      bokeh.dispose();
      output.dispose();
      composer.dispose();
    };
  }, [gl, scene, camera, invalidate]);
  useEffect(() => {
    current.current?.composer.setPixelRatio(Math.min(viewport.dpr, 1.25));
    current.current?.composer.setSize(size.width, size.height);
    invalidate();
  }, [gl, scene, camera, size.width, size.height, viewport.dpr, invalidate]);
  useFrame((_, delta) => {
    const bundle = current.current;
    if (!bundle) {
      gl.render(scene, camera);
      return;
    }
    (bundle.bokeh.uniforms as Record<string, { value: number }>).focus.value =
      camera.position.length();
    bundle.composer.render(delta);
  }, 1);
  return null;
}
