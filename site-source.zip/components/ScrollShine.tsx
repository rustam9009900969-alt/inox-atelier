"use client";
import { useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

/** Light follows reading progress; no timers, duplicated text or perpetual loops. */
export default function ScrollShine({
  reduce,
  revision,
}: {
  reduce: boolean;
  revision: string;
}) {
  useEffect(() => {
    if (reduce) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add(
      "(prefers-reduced-motion: no-preference) and (forced-colors: none)",
      () => {
        if (!CSS.supports("background-clip", "text")) return;
        const headings = gsap.utils.toArray<HTMLElement>(
          ".hero-word,.hero-subline,.hero-last,.assembly-copy h2 > em",
        );
        // Read all original colours before applying classes, preserving each accent.
        const inks = headings.map((el) => getComputedStyle(el).color);
        headings.forEach((el, index) => {
          const hero = el.closest(".hero");
          const assembly = el.closest(".scroll-assembly");
          el.classList.add("scroll-metal");
          gsap.set(el, { "--metal-ink": inks[index] });
          gsap.fromTo(
            el,
            { backgroundPosition: "100% 50%" },
            {
              backgroundPosition: "0% 50%",
              ease: "none",
              scrollTrigger: {
                trigger: hero || assembly || el.closest("h2") || el,
                start: hero ? "top top" : assembly ? "top top" : "top 92%",
                end: hero
                  ? "bottom 35%"
                  : assembly
                    ? "bottom bottom"
                    : "bottom 22%",
                scrub: 0.5,
              },
            },
          );
        });
        const images = gsap.utils.toArray<HTMLElement>(
          ".model-image,.project-image",
        );
        images.forEach((el) => {
          el.classList.add("scroll-polish");
          gsap.fromTo(
            el,
            { "--polish-x": "-130%" },
            {
              "--polish-x": "130%",
              ease: "none",
              scrollTrigger: {
                trigger: el,
                start: "top 85%",
                end: "bottom 30%",
                scrub: 0.65,
              },
            },
          );
        });
        return () => {
          headings.forEach((el) => el.classList.remove("scroll-metal"));
          images.forEach((el) => el.classList.remove("scroll-polish"));
        };
      },
    );
    return () => media.revert();
  }, [reduce, revision]);
  return null;
}
