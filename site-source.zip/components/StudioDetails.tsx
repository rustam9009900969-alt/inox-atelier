"use client";
import { assetPath } from "@/lib/asset-path";
import { useState } from "react";
import { ArrowUpRight, Plus } from "lucide-react";
import type { Finish } from "@/lib/config";
import { useLocale } from "./LocaleProvider";

const materials = [
  {
    name: "Сатин",
    image: assetPath("/media/ink-steel.webp"),
    title: "Свет на поверхности.",
    description:
      "Мягкое отражение подчёркивает геометрию стали. Сатиновая отделка подходит тем, кто предпочитает спокойный, сдержанный характер конструкции.",
  },
  {
    name: "Зеркало",
    image: assetPath("/media/ink-glass.webp"),
    title: "Отражение пространства.",
    description:
      "Полированная сталь отражает окружающую архитектуру. Свет меняется вместе с ракурсом и делает линию поручня выразительнее.",
  },
  {
    name: "Золото",
    image: assetPath("/projects/project-15.jpg"),
    title: "Тёплый характер.",
    description:
      "Золотистые детали добавляют тёплый акцент. Оттенок и сочетание элементов согласовываем под интерьер вашего пространства.",
  },
];
export function StudioDetails({
  onChooseFinish,
}: {
  onChooseFinish: (finish: Finish) => void;
}) {
  const { t } = useLocale();
  const [active, setActive] = useState(0);
  const current = materials[active];
  return (
    <section
      id="materials"
      className="studio-details"
      aria-labelledby="materials-heading"
    >
      <div className="studio-details-heading">
        <div>
          <span className="eyebrow">{t("МАТЕРИАЛ / ПОВЕРХНОСТЬ")}</span>
          <h2 id="materials-heading">
            {t("Ощущение стали.")}
            <br />
            <span>{t("Ваше прикосновение.")}</span>
          </h2>
        </div>
        <p>
          {t(
            "Одна конструкция — разное впечатление. Выберите поверхность стали для вашего пространства.",
          )}
        </p>
      </div>
      <div
        className="material-tabs"
        role="group"
        aria-label={t("Поверхность стали")}
      >
        {materials.map((item, index) => (
          <button
            key={item.name}
            type="button"
            aria-pressed={active === index}
            aria-controls="material-study"
            onClick={() => setActive(index)}
          >
            <i aria-hidden="true" />
            {t(item.name)}
          </button>
        ))}
      </div>
      <div className="material-study" id="material-study">
        <div className="material-study-image">
          <img
            key={current.image}
            src={current.image}
            width={960}
            height={720}
            loading="lazy"
            decoding="async"
            alt={
              active === 2
                ? t("Фотография нашей работы: {finish}", {
                    finish: t(current.name),
                  })
                : t("Архитектурная визуализация")
            }
          />
        </div>
        <div className="material-study-copy">
          <span className="eyebrow">
            {active === 2
              ? "INOX / " + t(current.name)
              : t("Архитектурная визуализация")}
          </span>
          <h3>{t(current.title)}</h3>
          <p>{t(current.description)}</p>
          <a
            className="button outline"
            href="#configurator"
            onClick={() =>
              onChooseFinish((["satin", "polished", "gold"] as const)[active])
            }
          >
            {t("Выбрать в конфигураторе")}
            <ArrowUpRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}
const questions = [
  [
    "С чего начать заказ?",
    "Выберите коллекцию и отделку в конфигураторе. Затем напишите нам или позвоните: обсудим пространство, замер и индивидуальный проект.",
  ],
  [
    "Как определяется стоимость?",
    "На стоимость влияют длина, заполнение, отделка, сложность креплений и монтаж. Расчёт на сайте предварительный; окончательную сумму согласуем после замера и выбора материалов.",
  ],
  [
    "Можно ли изменить конструкцию под мой интерьер?",
    "Да. Обсудим геометрию лестницы или балкона, тип заполнения и поверхность стали. Фотографии пространства помогут подготовиться к разговору.",
  ],
  [
    "Что показывает 3D-модель?",
    "Конфигуратор показывает внешний вид и основные этапы сборки. Размеры, крепления и параметры безопасности уточняются для конкретного объекта.",
  ],
];
export function StudioFAQ() {
  const { t } = useLocale();
  return (
    <section className="studio-faq" aria-labelledby="faq-heading">
      <div>
        <span className="eyebrow">{t("ПЕРЕД НАЧАЛОМ")}</span>
        <h2 id="faq-heading">
          {t("Важные детали.")}
          <br />
          <span>{t("Простые ответы.")}</span>
        </h2>
      </div>
      <div className="studio-faq-list">
        {questions.map(([question, answer]) => (
          <details key={question}>
            <summary>
              {t(question)}
              <Plus size={18} aria-hidden="true" />
            </summary>
            <p>{t(answer)}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
