"use client";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  isLocale,
  localeNames,
  locales,
  translate,
  type Locale,
} from "@/lib/i18n";

type Translate = (
  source: string,
  params?: Record<string, string | number>,
) => string;
const LocaleContext = createContext<{
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: Translate;
}>({ locale: "ru", setLocale: () => {}, t: (source) => source });
const storageKey = "inox-language";
export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, updateLocale] = useState<Locale>("ru");
  useEffect(() => {
    const restore = () => {
      const requested = new URL(location.href).searchParams.get("lang");
      let saved: string | null = null;
      try {
        saved = localStorage.getItem(storageKey);
      } catch {}
      updateLocale(
        isLocale(requested) ? requested : isLocale(saved) ? saved : "ru",
      );
    };
    restore();
    window.addEventListener("popstate", restore);
    return () => window.removeEventListener("popstate", restore);
  }, []);
  const setLocale = useCallback((next: Locale) => {
    if (!isLocale(next)) return;
    updateLocale(next);
    try {
      localStorage.setItem(storageKey, next);
    } catch {}
    const url = new URL(location.href);
    if (next === "ru") url.searchParams.delete("lang");
    else url.searchParams.set("lang", next);
    history.replaceState(history.state, "", url);
  }, []);
  const t = useCallback<Translate>(
    (source, params) => translate(locale, source, params),
    [locale],
  );
  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale, t]);
  const value = useMemo(
    () => ({ locale, setLocale, t }),
    [locale, setLocale, t],
  );
  return (
    <LocaleContext.Provider value={value}>
      <title>{`INOX ATELIER — ${t("Архитектура уверенности")}`}</title>
      <meta
        name="description"
        content={
          t(
            "Производство и монтаж перил из нержавеющей стали. Выберите дизайн, изучите конструкцию в 3D и рассчитайте ваш проект.",
          ) + " +998 93 122 01 01."
        }
      />
      {children}
    </LocaleContext.Provider>
  );
}
export const useLocale = () => useContext(LocaleContext);
export function LanguageSwitcher() {
  const { locale, setLocale, t } = useLocale();
  return (
    <div
      className="language-switcher"
      role="group"
      aria-label={t("Язык сайта")}
    >
      {locales.map((code) => (
        <button
          key={code}
          type="button"
          lang={code}
          aria-label={localeNames[code]}
          title={localeNames[code]}
          aria-pressed={locale === code}
          onClick={() => setLocale(code)}
        >
          {code.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
export function SceneLoading() {
  const { t } = useLocale();
  return (
    <div className="scene-loading">{t("Подготавливаем пространство…")}</div>
  );
}
