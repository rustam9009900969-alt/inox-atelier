import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
import { fileURLToPath } from "node:url";
const root = fileURLToPath(new URL("../out", import.meta.url));
const basePath = (process.env.INOX_PREVIEW_BASE_PATH || "").replace(/\/$/, "");
const port = Number(process.env.INOX_PREVIEW_PORT || 3000);
const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".png": "image/png",
  ".wasm": "application/wasm",
  ".glb": "model/gltf-binary",
  ".ktx2": "image/ktx2",
  ".txt": "text/plain; charset=utf-8",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
};
await stat(resolve(root, "index.html")).catch(() => {
  console.error("Сначала выполните pnpm build.");
  process.exit(1);
});
const server = createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(
      new URL(req.url, "http://localhost").pathname,
    );
    if (pathname === "/__inox_preview.json") {
      res
        .writeHead(200, {
          "Content-Type": "application/json",
          "Cache-Control": "no-store",
        })
        .end(
          JSON.stringify({
            service: "inox-atelier-preview",
            pid: process.pid,
            root,
          }),
        );
      return;
    }
    if (basePath && pathname === basePath) {
      res.writeHead(308, { Location: basePath + "/" }).end();
      return;
    }
    if (basePath && !pathname.startsWith(basePath + "/")) {
      res.writeHead(404).end("Not found");
      return;
    }
    const assetPath = basePath ? pathname.slice(basePath.length) : pathname;
    let file = resolve(root, "." + assetPath);
    if (file !== root && !file.startsWith(root + sep)) {
      res.writeHead(403).end();
      return;
    }
    if ((await stat(file).catch(() => null))?.isDirectory())
      file = resolve(file, "index.html");
    const data = await readFile(file);
    res.writeHead(200, {
      "Content-Type": types[extname(file)] || "application/octet-stream",
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "no-cache",
    });
    res.end(data);
  } catch {
    res
      .writeHead(404, { "Content-Type": "text/plain; charset=utf-8" })
      .end("Не найдено");
  }
});
server.on("error", (error) => {
  console.error(
    error.code === "EADDRINUSE"
      ? `Порт ${port} уже занят. Закройте другой сервер или используйте Запустить сайт.command.`
      : error.message,
  );
  process.exit(1);
});
server.listen(port, "127.0.0.1", () =>
  console.log(`Локальный сайт: http://127.0.0.1:${port}`),
);
