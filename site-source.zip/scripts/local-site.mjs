import { spawn } from "node:child_process";
import { closeSync, mkdirSync, openSync } from "node:fs";
import { access } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { setTimeout as delay } from "node:timers/promises";

const project = fileURLToPath(new URL("../", import.meta.url));
const root = fileURLToPath(new URL("../out", import.meta.url));
const port = Number(process.env.INOX_PREVIEW_PORT || 3000);
const address = `http://127.0.0.1:${port}`;
const action = process.argv[2] || "start";

async function status() {
  try {
    const response = await fetch(`${address}/__inox_preview.json`, {
      signal: AbortSignal.timeout(1000),
    });
    const data = await response.json().catch(() => null);
    if (
      data?.service === "inox-atelier-preview" &&
      data.root === root &&
      Number.isSafeInteger(data.pid) &&
      data.pid > 1
    )
      return data;
    throw new Error(
      `Порт ${port} занят другим сайтом. Остановите его перед запуском.`,
    );
  } catch (error) {
    if (error instanceof TypeError && error.cause?.code === "ECONNREFUSED")
      return null;
    throw error;
  }
}

try {
  if (!["start", "stop"].includes(action))
    throw new Error("Допустимые команды: start, stop.");
  const running = await status();
  if (action === "stop") {
    if (running) {
      process.kill(running.pid, "SIGTERM");
      for (let attempt = 0; attempt < 20; attempt++) {
        await delay(100);
        if (!(await status())) break;
        if (attempt === 19)
          throw new Error("Сервер пока не остановился. Попробуйте ещё раз.");
      }
    }
    console.log("Локальный сайт остановлен.");
  } else {
    if (!running) {
      await access(new URL("../out/index.html", import.meta.url)).catch(() => {
        throw new Error(
          "Готовая сборка не найдена. Сначала выполните pnpm build.",
        );
      });
      const logs = new URL("../.preview/", import.meta.url);
      mkdirSync(logs, { recursive: true });
      const log = openSync(new URL("preview.log", logs), "a");
      const child = spawn(
        process.execPath,
        [fileURLToPath(new URL("preview.mjs", import.meta.url))],
        {
          cwd: project,
          detached: true,
          stdio: ["ignore", log, log],
          env: process.env,
        },
      );
      closeSync(log);
      let launchError;
      child.on("error", (error) => {
        launchError = error;
      });
      child.unref();
      let ready = false;
      for (let attempt = 0; attempt < 32; attempt++) {
        await delay(250);
        if (launchError) throw launchError;
        if (await status()) {
          ready = true;
          break;
        }
      }
      if (!ready)
        throw new Error(
          "Не удалось запустить сайт. Подробности: .preview/preview.log",
        );
    }
    console.log(`Сайт работает: ${address}/?lang=ru`);
    console.log(
      "Это окно можно закрыть — сайт продолжит работать до перезагрузки компьютера.",
    );
    console.log("Для остановки откройте Остановить сайт.command.");
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
