#!/bin/zsh
set -e
cd -- "$(dirname -- "$0")"
if command -v node >/dev/null 2>&1; then
  inox_node="$(command -v node)"
elif [[ -x /Users/a666/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node ]]; then
  inox_node=/Users/a666/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node
else
  print 'Для запуска установите Node.js 22.13 или новее.'
  read 'inox_reply?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
if "$inox_node" scripts/local-site.mjs start; then
  open 'http://127.0.0.1:3000/?lang=ru'
else
  read 'inox_reply?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
