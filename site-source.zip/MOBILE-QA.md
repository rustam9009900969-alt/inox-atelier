# Mobile QA — 2026-10-04

Responsive browser viewport checks: 360 × 800 RU, 390 × 844 UZ, 430 × 932 EN. Menu opening, Escape/focus restore, navigation closing, sticky header, camera-control bounds and document horizontal overflow inspected. Production static build and existing 11 tests pass. Reduced-motion CSS explicitly bypasses entrances and press scaling; scroll-reveal code checks media preference before animation. Real iOS/Android touch gestures and hardware FPS are not certified by desktop viewport checks.
