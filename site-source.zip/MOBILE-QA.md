# Mobile QA — 2026-10-04

Responsive browser viewport checks: 360 × 800 RU, 390 × 844 UZ, 430 × 932 EN. Menu opening, Escape/focus restore, navigation closing, sticky header, camera-control bounds and document horizontal overflow inspected. Production static build and existing 11 tests pass. Reduced-motion CSS explicitly bypasses entrances and press scaling; scroll-reveal code checks media preference before animation. Real iOS/Android touch gestures and hardware FPS are not certified by desktop viewport checks.

## 2026-10-07 performance revision

Verified local descriptive alias, RU without lang query, UZ at 360px and EN at 430px with no document overflow. Config canvas 344×282 pixels for a 344×282 CSS viewport (DPR 1); no scroll-metal/polish targets on phone. Two canvases remain mounted after navigating configurator to assembly. Handrail connection camera, project dialog and clipboard-success status work; no captured console errors. No actual phone frame pacing or thermal tests available; hardware performance is not guaranteed by viewport verification. Mobile shadows are intentionally cheaper.
