# Showroom verification — 2026-10-04

Production build and TypeScript pass; 11 tests pass. Premium static audit strict mode: no findings.
Browser: desktop 1440px and responsive 360/390/430px. Page width equals viewport width in each narrow check. RU/UZ/EN hero labels and layouts inspected. Mobile viewer label and view controls no longer overlap.
All three existing models and all three finishes exercised; summary and demo quote track state. Quote extremes 1/100m inspected; length intentionally does not reshape the procedural section. Explode and X-ray toggles, camera presets and reset inspected. Project modal reflects selected configuration and links to Telegram; no message sent. PNG export visually inspected in an actual downloaded image. Export action remains available when scrolling to mobile settings.
Evidence in workspace outputs: unified-hero.jpg, unified-hero-mobile.jpg, showroom-overview.jpg, showroom-joint.jpg, showroom-mobile.jpg, showroom-interaction.gif. GIF records browser captures during view and finish changes, not AI animation.
No hardware-wide FPS or engineering load certification is claimed. No measured CAD files were provided. Reduced motion is implemented with immediate camera/material changes; physical touch hardware was not available for this desktop browser QA. WebGL retry fallback remains the existing verified architecture.
