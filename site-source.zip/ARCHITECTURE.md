# Архитектура и WebGL-пайплайн

## 1. Сначала контент и интерфейс

Next.js App Router экспортирует страницу в статический HTML. Семантические разделы, телефон, галерея и калькулятор сохраняют смысл независимо от 3D. `Scene` загружается динамически с `ssr: false`; ошибки WebGL заменяют сцену фотографией. Критические действия не зависят от Canvas.

Стек: Next.js 16, React 19.2, TypeScript, Tailwind CSS 4 с авторскими CSS-токенами, Framer Motion, Three.js, R3F, Drei, GSAP и Lenis. Используется поддерживаемое имя пакета `lenis` вместо старого `@studio-freight/lenis`.

## 2. Параметры как единый источник состояния

`model`, `finish`, `stage`, `explode`, `xray` управляют сценой. `length` и `installation` задают коммерческую оценку. Длина относится к заказу в целом: 3D показывает образец секции, а не растягивается до 100 метров. Кнопки, калькулятор, окно контактов и WebMCP пользуются одной конфигурацией.

`estimate` отвергает нечисловую длину, выход за диапазон 1–100 м и неизвестные модели/отделки. Формула: ставка модели × метраж × коэффициент отделки + ставка монтажа × метраж. Все ставки демонстрационные, округление до 1 000 сум.

## 3. Геометрия и сборка

`Railing` собирает независимые группы анкеров, стоек, держателей, поручня и заполнения. `Beam` вычисляет длину и quaternion цилиндра один раз при изменении координат. Детали получают общие материалы внутри экземпляра секции; обработка `useFrame` изменяет позиции напрямую, без React setState на каждом кадре.

`Part` сближает текущую позицию с целевой через экспоненциальное затухание, привязанное к delta-time. После достижения цели `invalidate()` больше не вызывается. При reduced-motion переход мгновенный. Разборка использует те же объекты, а не дубликат всей геометрии.

Рентген уменьшает непрозрачность внешней стали и подставки, отключает запись их глубины, оставляет светящийся сердечник и анкеры. Это визуальная схема узла, не документирование фактического крепежа из фотографий.

## 4. Скролл и камера

Lenis получает время из GSAP ticker; отдельного бесконечного RAF для smooth-scroll не добавлено. `lenis.on('scroll', ScrollTrigger.update)` синхронизирует положение. Сенсорный скролл остаётся нативным (`syncTouch: false`).

На первом экране ScrollTrigger переводит прогресс в положение камеры. Указатель/гироскоп добавляет ограниченное отклонение. Камера интерполируется в `useFrame`, снова инвалидируя кадр только до остановки. Большой кадр удерживается CSS sticky на десктопе; мобильная версия сокращает этот пролёт.

OrbitControls применяется только к конфигуратору и безопасности, поэтому не спорит с камерой hero. Тач-поверхность Canvas отделена от прокрутки документа. За пределами сцены обычный скролл сохраняется.

## 5. Свет и материалы

Drei Environment с четырьмя Lightformer один раз создаёт карту окружения 128 px. Это не внешняя HDR-загрузка; сайт не зависит от стороннего CDN. Сталь использует metalness=1 и roughness, меняющийся с отделкой. Стекло — облегчённый MeshPhysicalMaterial с прозрачностью.

Для подходящего настольного профиля подключается цепочка RenderPass → BokehPass → OutputPass. Разрешение постобработки ограничено 1.25 DPR. На мобильном профиле, при снижении производительности и reduced-motion цепочка полностью удаляется. GPU-ресурсы освобождаются при размонтировании, в том числе при повторных effect-циклах React StrictMode.

## 6. Мобильная оптимизация

- Начальный DPR: до 1.25 на мобильном профиле, до 1.6 на настольном; не выше реального DPR дисплея.
- PerformanceMonitor снижает DPR ступенями до 0.75 и включает упрощённую геометрию. Для надёжности снижение в текущем сеансе необратимо; это исключает постоянное переключение качества.
- Круглые детали: 10 сегментов в низком качестве, 24 в обычном. Это адаптация геометрии по качеству устройства; отдельные дистанционные GLB-LOD сейчас не используются.
- `frameloop='demand'`: в покое кадры не производятся непрерывно. Во время сборки, движения камеры и OrbitControls кадры запрашиваются по необходимости.
- IntersectionObserver размонтирует невидимые Canvas. В скрытой вкладке рендеринг прекращается. Поэтому одновременно не работают три тяжёлых независимых сцены.
- Нет динамических теней, большого HDR, SSAO, SSR и внешних шрифтов.
- Фотографии галереи имеют заданные размеры и lazy loading. Все 20 изображений занимают примерно 4 МБ в исходном наборе, не загружаются как текстуры GPU.
- Слушатели датчиков, ScrollTrigger, Lenis и GSAP анимации очищаются при выходе из компонента.

Бюджет кадра 16.67 мс — цель для 60 Гц, а не безусловное обещание. Для 120 Гц бюджет другой. Ограничения частоты дисплея, энергосбережение, перегрев и фоновые процессы нельзя отменить кодом сайта.

## 7. Подключение реальных GLB, Draco и KTX2

`createModelPipeline(renderer)` в `lib/model-loader.ts` создаёт GLTFLoader, DRACOLoader и KTX2Loader. Декодеры лежат в `public/decoders`, число worker ограничено двумя. Перед загрузкой KTX2 вызывается `detectSupport(renderer)`.

Рабочий процесс подготовки активов:

1. Снять замеры и отдельные ракурсы одного объекта, включая крепления, торцы и материал. Хром плохо подходит для обычной фотограмметрии; предпочтительно моделирование по размерам.
2. В Blender/CAD разделить модель на `anchors`, `posts`, `holders`, `handrail`, `infill`. Применить трансформации, проверить pivot, единицы и направления нормалей.
3. Подготовить высокий и низкий LOD с одинаковыми pivots. Начальные целевые бюджеты: 25–40 тыс. треугольников для настольной секции и 8–15 тыс. для мобильной. Проверить вид на реальном расстоянии, а не только полигональный счётчик.
4. Выполнить bake мелких фасок/обработки в normal/roughness; сохранять отдельные фаски геометрией только при видимом влиянии на силуэт.
5. Сжать геометрию Draco, текстуры KTX2/Basis; normal/roughness хранить с корректным линейным color space, base color — sRGB. Выбрать 1K для мобильного и 2K для настольного профиля только при необходимости.
6. Экспортировать в `public/models/model-low.glb` и `model-high.glb`, загрузить через `pipeline.load('/models/model-low.glb')`. На уничтожении вызвать `pipeline.dispose()`; также освободить геометрию, материалы и текстуры выгруженной сцены.
7. Заменить параметрический `Railing` группами из GLB, сохранив текущий API сборки. Сверить узлы с фактической конструкцией.

Эти шаги описывают подготовку новых измеренных активов; в текущем наборе GLB нет. Декодеры поставлены из Three.js и сохраняют авторские notices; лицензия Three.js — MIT.

## 8. Сцена безопасности

Схематические персонажи собраны из небольших примитивов. Мама поворачивается с телефоном; ребёнок движется к краю. При наличии стекла движение останавливается перед ограждением. Без ограждения персонаж условно опускается за край; столкновение, травмы и последствия не изображаются.

`SafetyPlayer` хранит одну шкалу `progress` в ref. GSAP обновляет её, нативное значение ползунка и индикатор времени, затем вызывает `invalidate()`. `SafetyWorld` применяет чистую функцию `safetyPose` в `useFrame`. React не перерисовывает всю страницу каждый кадр. Пауза сохраняет прогресс; ручная перемотка останавливает проигрывание; смена сценария сбрасывает его. При скрытии вкладки или уходе секции за экран воспроизведение прекращается. Reduced-motion оставляет ручное управление.

Стекло использует `MeshPhysicalMaterial`: transmission 0.94, roughness 0.055, IOR 1.5, толщина 0.032, opacity 1; контур — EdgesGeometry. Все три панели используют общий материал и буфер transmission с масштабом 0.75 / 0.5 для обычного / облегчённого режима. Стойки — MeshStandardMaterial, metalness 0.96, roughness 0.31; отражения даёт существующее студийное окружение. Одна карта теней 1024 / 512 px и маленькие контактные текстуры создают глубину без полноэкранного SSAO.

Пол получает процедурные карты цвета и normal 128×128; контактные карты и свечение — 64×64. Геометрия персонажей переиспользуется, число сегментов сферы — 20 / 12. Ресурсы освобождаются при смене качества и размонтировании. Ограждение переключает видимость без пересоздания геометрии. ResizeObserver дополнительно проверяет видимость Canvas при изменении размеров.

## 9. Проверка перед эксплуатацией

Автоматически: TypeScript, сборка Next.js, unit-тесты расчёта/отклонения неверных значений. В браузере: выбор модели/отделки, сборка, разборка, рентген, калькулятор, диалог, галерея и ширины 390/1440 px. WebMCP проверяется валидной конфигурацией и ошибочным метражом с чтением состояния интерфейса.

На реальных устройствах отдельно измерить: холодный старт; скролл 30 секунд; вращение 20 секунд; 3 повтора сборки; сворачивание вкладки; low-power mode; 10 минут нагрева. Записывать median/p95 времени кадра, dropped frames, JS/GPU память и длительность загрузки. Проверить iOS Safari, Android Chrome, Firefox и настольные Chromium/Safari, а также отказ WebGL и reduced-motion. Программная эмуляция ширины не подтверждает FPS телефонов.

## Первичные источники

- [R3F: Scaling performance](https://r3f.docs.pmnd.rs/advanced/scaling-performance)
- [R3F: Performance pitfalls](https://r3f.docs.pmnd.rs/advanced/pitfalls)
- [Lenis и интеграция с GSAP](https://github.com/darkroomengineering/lenis)
- [Next.js: Static exports](https://nextjs.org/docs/app/guides/static-exports)


## 10. Локализация и слой движения

`LocaleProvider` хранит один типизированный `Locale`: `ru`, `uz`, `en`. При запуске валидированный `?lang` имеет приоритет над `localStorage`. Переключение меняет URL через replaceState, сохраняет язык и обновляет `html.lang`; React выводит единственный локализованный `title` и `meta description`. Ошибка доступа к localStorage не блокирует интерфейс. Состояние конфигуратора находится ниже провайдера и не пересоздаётся при смене языка. Серверный HTML статического экспорта русский; локализованные маршруты/hreflang не реализованы.

`ScrollReveal` использует один IntersectionObserver и Web Animations API. В исходном HTML всё видно; только подходящий профиль устройства получает появление. Объекты анимаций освобождаются после завершения, наблюдение очищается при смене языка/галереи/профиля. Короткая анимация стоимости и названия модели отслеживает только текстовые изменения DOM.

`LuxuryEffects` хранит положение мыши вне React, обновляет transform через один затухающий requestAnimationFrame и прекращает цикл в покое. Геометрия интерактивного элемента кэшируется, сбрасывается при прокрутке и изменении окна. Lenis включается только на настольном профиле с мышью; на сенсорных экранах и reduced-motion используется нативная прокрутка.

Исправлена прозрачность BokehPass: штатная строка принудительного alpha=1 удаляется из его шейдера, чтобы постобработка не перекрывала первый экран чёрным прямоугольником. При обновлении Three.js необходимо проверить эту адаптацию и прозрачный фон визуально.


## 11. Редакционный редизайн

`HeroArtwork` добавляет фотографию поверх hero Canvas. GSAP matchMedia создаёт переход только для экрана от 761 px, точного указателя и no-preference; `revert()` очищает timeline, ScrollTrigger и временные стили. На узком/сенсорном экране и reduced-motion hero Canvas скрыт и не попадает в IntersectionObserver, фотография остаётся статичной. Конфигуратор ниже продолжает поддерживать сенсорное управление. Файл `luxury.css` переписан целиком, чтобы не добавлять ещё один конфликтующий слой оформления. Локальные Playfair Display normal/italic подключены через next/font/local.


## SignatureMotion lifecycle

A single GSAP matchMedia scope limits new effects to widths of at least 761px, fine pointers and no reduced-motion preference. A GSAP context reverts inline styles on cleanup. Language/gallery changes recreate scroll triggers; a guarded document.fonts.ready callback refreshes positions. IntersectionObserver and visibilitychange pause ambient CSS cycles offscreen and in background tabs. Photo scroll translation uses the individual translate property so hover scale remains independent.


Typography update 2026-09-25: Manrope replaces Inter in next/font/local (200–800). app/typography.css is imported after the interaction layer and contains only visual/type rules; it does not change GSAP, R3F, translations or configuration state. Manrope-OFL.txt is distributed with its font.


## Current scroll assembly - 2026-09-28

ScrollAssembly uses CSS sticky within a 410svh desktop / 370svh mobile track. ScrollTrigger maps progress to six intervals: base plus five installation stages. Part interpolates offsets and supports reverse scrolling. React state changes only between integer stages; the progress line updates through transform. No wheel/touch hijacking or automatic page snap is used.

Canvas pointer interaction and OrbitControls are disabled until the rotate button is enabled. Reduced-motion removes the long track and provides manual step controls. Stage buttons seek to the corresponding scroll interval. Model/finish share configurator state; all new strings have RU/UZ/EN translations.

Visibility combines IntersectionObserver, ResizeObserver and one coalesced scroll-frame check for sticky layout changes. Camera zoom fits narrow configurator canvases. HeroArtwork is now photography, without a hero Canvas; optional gyro gently shifts the photo after user permission.
