# Customer journey contract

- Model selection is shared by the configurator, scroll assembly, estimate and project specification.
- Surface study selection applies the matching finish when following its configurator link.
- Assembly responds reversibly to page progress. Buttons also select an exact stage. Reduced motion leaves every stage accessible without animated movement.
- RU, UZ and EN share the same configuration state. The locale updates document language and the URL; structural layout remains responsive.
- Price menu examples are labelled. They never imply that example rates correspond to the 13 supplied videos. Item data lives in lib/menuItems.ts. Empty photos/video omit their media sections.
- Product and project dialogs trap focus natively, close with Escape and restore previous focus and overflow. Background scrolling is blocked.
- Telegram links address @udhdrg and prepare text. No automatic message submission or server enquiry is claimed.
- Quotes are demonstrations; exact commercial terms are agreed after measurement. The phone is +998 93 122 01 01.
- No jumping strength demonstration. Safety scene remains a schematic explanation, not structural validation.
- Pointer ornaments are disabled on touch. Reduced motion and forced colours preserve visible readable content.
- WebGL failure shows a portfolio photograph and an explicit retry. Core browsing, pricing and contact remain available.

- Showroom camera presets never change product dimensions. Manual OrbitControls interaction cancels the active preset transition; reset restores the overall view.
- Length is an enquiry/estimate parameter, not a CAD dimension. The fixed section is explicitly described as a parametric illustration.
- Screenshot export copies the rendered viewport to a PNG with a neutral background. Its action stays disabled until the viewer is ready, and failure has retry copy.

Mobile navigation is a non-modal disclosure: Escape returns focus to its trigger; link selection, outside pointer press and transition to desktop close it. The page remains scrollable. Camera presets have separate 44px touch targets; pinch zoom is not disabled.
