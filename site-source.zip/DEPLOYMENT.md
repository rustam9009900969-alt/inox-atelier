# Публикация INOX Atelier

Статус: 4 октября 2026 года опубликованы улучшенный 3D-шоурум и первый экран в общей сине-серебряной палитре. Build и deploy успешны. Коммит e5df272affff088ac66cb1688349fb5646a15b71.

- Сайт: https://rustam9009900969-alt.github.io/inox-atelier/
- Репозиторий: https://github.com/rustam9009900969-alt/inox-atelier
- Успешная публикация: https://github.com/rustam9009900969-alt/inox-atelier/actions/runs/37212829568

## GitHub Pages

В Settings → Pages выбран Source: GitHub Actions. Исходники первоначально загружены как `site-source.zip`; workflow распаковывает их только для сборки, без записи в репозиторий. Чтобы обновить сайт, замените архив актуальными исходниками без node_modules, .next, out и секретов либо загрузите обычные исходные папки. Если package.json присутствует в корне, архив больше не используется.

Workflow `.github/workflows/pages.yml` устанавливает зависимости по lockfile, проверяет типы и тесты, собирает статический сайт и публикует его. Изменения main обновляют сайт автоматически. Секреты хостинга не нужны: используется краткоживущий токен GitHub Actions.

Сайт обслуживается GitHub Pages независимо от компьютера владельца. Локальный сервер и временные туннели для публикации не используются. Доступность зависит от сервиса хостинга; абсолютная гарантия 100% uptime не предоставляется.

## Локальная проверка подпапки

```sh
NEXT_PUBLIC_BASE_PATH=/inox-atelier pnpm build
INOX_PREVIEW_PORT=3001 INOX_PREVIEW_BASE_PATH=/inox-atelier pnpm start
```

Открыть http://127.0.0.1:3001/inox-atelier/?lang=ru. Проверить языки RU/UZ/EN, фотографии, 3D, прайс-лист и Telegram. Вернуть обычную локальную сборку командой `pnpm build`.

`lib/asset-path.ts` добавляет префикс ко всем публичным изображениям, видео и загрузчикам 3D; Next.js автоматически задаёт пути своих скриптов, стилей и локальных шрифтов. При размещении в корне домена переменную NEXT_PUBLIC_BASE_PATH не задавать.

## Другой хостинг

Папку `out/`, полученную обычным `pnpm build`, можно разместить на статическом HTTPS-хостинге. Для Netlify добавлен `netlify.toml`: сборка pnpm build, публикация out. Не загружать node_modules, .next, .env, локальные резервные копии или служебные папки.

## Источники

- https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- https://nextjs.org/docs/app/guides/static-exports
