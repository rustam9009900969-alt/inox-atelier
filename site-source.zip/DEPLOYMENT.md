# Публикация INOX Atelier

Статус: подготовлено локально; удалённый репозиторий и публичный адрес ещё не созданы.

## GitHub Pages

1. Создать репозиторий `inox-atelier` в своём аккаунте GitHub. Для бесплатного GitHub Pages нужен открытый репозиторий.
2. Отправить ветку `main` в этот репозиторий.
3. В Settings → Pages → Build and deployment выбрать Source: GitHub Actions.
4. В Actions запустить Publish INOX Atelier или отправить новый коммит в main.
5. Дождаться зелёного задания deploy. Проверить адрес, показанный в окружении github-pages.

Workflow `.github/workflows/pages.yml` устанавливает зависимости по lockfile, проверяет типы и тесты, собирает статический сайт и публикует его. Изменения main обновляют сайт автоматически. Секреты хостинга не нужны: используется краткоживущий токен GitHub Actions.

Сайт обслуживается GitHub Pages независимо от компьютера владельца. Локальный сервер и временные туннели для публикации не используются. Доступность зависит от сервиса хостинга; абсолютная гарантия 100% uptime не предоставляется.

## Локальная проверка подпапки

```sh
NEXT_PUBLIC_BASE_PATH=/inox-atelier pnpm build
INOX_PREVIEW_PORT=3001 INOX_PREVIEW_BASE_PATH=/inox-atelier pnpm start
```

Открыть http://127.0.0.1:3001/inox-atelier/?lang=ru. Проверить языки RU/UZ/EN, фотографии, 3D, прайс-лист и Telegram. Вернуть обычную локальную сборку командой `pnpm build`.

`lib/asset-path.ts` добавляет префикс ко всем публичным изображениям, видео и загрузчикам 3D; Next.js автоматически задаёт пути своих скриптов, стилей и локальных шрифтов. При размещении в корне домена переменную NEXT_PUBLIC_BASE_PATH не задавать.

## Другой хостинг

Папку `out/`, полученную обычным `pnpm build`, можно разместить на статическом HTTPS-хостинге. Для Netlify добавлен `netlify.toml`: сборка pnpm build, публикация out. Не загружать node_modules, .next, .env, локальные резервные копии или служебные папки.

## Источники

- https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
- https://nextjs.org/docs/app/guides/static-exports
