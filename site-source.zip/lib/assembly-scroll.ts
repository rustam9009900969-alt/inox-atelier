/** Six equal scroll intervals: base, anchors, posts, brackets, handrail, infill. */
export function assemblyStage(progress: number) {
  const p = Number.isFinite(progress) ? Math.max(0, Math.min(1, progress)) : 0;
  return Math.min(5, Math.floor(p * 6));
}
export function assemblyProgress(stage: number) {
  return (Math.max(0, Math.min(5, Math.round(stage))) + 0.35) / 6;
}
