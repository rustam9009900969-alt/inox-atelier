import { assetPath } from "@/lib/asset-path";
import type { WebGLRenderer } from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/addons/loaders/DRACOLoader.js";
import { KTX2Loader } from "three/addons/loaders/KTX2Loader.js";
/** Optional pipeline for measured production GLBs. The default scene is procedural. */
export function createModelPipeline(renderer: WebGLRenderer) {
  const draco = new DRACOLoader()
    .setDecoderPath(assetPath("/decoders/draco/"))
    .setWorkerLimit(2);
  const textures = new KTX2Loader()
    .setTranscoderPath(assetPath("/decoders/basis/"))
    .setWorkerLimit(2)
    .detectSupport(renderer);
  const loader = new GLTFLoader().setDRACOLoader(draco).setKTX2Loader(textures);
  return {
    load: (path: string) => {
      if (!path.startsWith("/models/") || !path.endsWith(".glb"))
        throw new Error("Ожидается локальная модель /models/*.glb");
      return loader.loadAsync(assetPath(path));
    },
    dispose: () => {
      draco.dispose();
      textures.dispose();
    },
  };
}
