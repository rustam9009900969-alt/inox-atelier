export type MenuLocale = "ru" | "uz" | "en";
export type Localized = Record<MenuLocale, string>;
export type Category =
  "stairs" | "balcony" | "glass" | "handrails" | "accessories";
export type MenuItem = {
  id: string;
  category: Category;
  name: string;
  description: string;
  price: number;
  currency: "USD" | "UZS";
  unit: "metre" | "piece";
  photos: string[];
  video: string | null;
  demo?: boolean;
  translations?: Partial<
    Record<"uz" | "en", { name: string; description: string }>
  >;
};

export const telegramUsername = "udhdrg";
export const menuCategories: { id: Category; label: Localized }[] = [
  {
    id: "stairs",
    label: {
      ru: "Перила для лестниц",
      uz: "Zinapoya panjaralari",
      en: "Stair railings",
    },
  },
  {
    id: "balcony",
    label: {
      ru: "Балконные ограждения",
      uz: "Balkon panjaralari",
      en: "Balcony railings",
    },
  },
  {
    id: "glass",
    label: {
      ru: "Стеклянные ограждения",
      uz: "Shisha panjaralar",
      en: "Glass railings",
    },
  },
  {
    id: "handrails",
    label: { ru: "Поручни", uz: "Tutqichlar", en: "Handrails" },
  },
  {
    id: "accessories",
    label: { ru: "Аксессуары", uz: "Aksessuarlar", en: "Accessories" },
  },
];

// Все цены ниже демонстрационные. Ваши 13 видео и их цены сюда не подмешаны.
// Для реального товара: укажите данные и файлы, удалите demo: true.
// Для отсутствующих медиа используйте photos: [] и video: null.
export const menuItems: MenuItem[] = [
  {
    id: "st-01",
    category: "stairs",
    name: "Линия / Satin",
    description: "Прямой силуэт, сатиновая сталь и вертикальное заполнение.",
    price: 135,
    currency: "USD",
    unit: "metre",
    photos: ["/projects/project-04.jpg", "/projects/project-13.jpg"],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Line / Satin",
        description: "A clean silhouette with satin steel and vertical infill.",
      },
      uz: {
        name: "Chiziq / Satin",
        description:
          "Satin po‘lat va vertikal elementlardan iborat sodda siluet.",
      },
    },
  },
  {
    id: "st-02",
    category: "stairs",
    name: "Ритм / Inox",
    description: "Выразительная геометрия для современного лестничного марша.",
    price: 160,
    currency: "USD",
    unit: "metre",
    photos: ["/projects/project-15.jpg"],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Rhythm / Inox",
        description: "Precise geometry for a contemporary staircase.",
      },
      uz: {
        name: "Ritm / Inox",
        description: "Zamonaviy zinapoya uchun aniq geometriya.",
      },
    },
  },
  {
    id: "ba-01",
    category: "balcony",
    name: "Горизонт",
    description: "Тонкий стальной контур, сохраняющий открытый вид.",
    price: 120,
    currency: "USD",
    unit: "metre",
    photos: ["/projects/project-11.jpg", "/projects/project-10.jpg"],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Horizon",
        description: "A slim steel outline that preserves the view.",
      },
      uz: {
        name: "Ufq",
        description: "Manzarani to‘sib qo‘ymaydigan nozik po‘lat kontur.",
      },
    },
  },
  {
    id: "ba-02",
    category: "balcony",
    name: "Терраса",
    description: "Спокойный архитектурный ритм для открытых пространств.",
    price: 100,
    currency: "USD",
    unit: "metre",
    photos: ["/projects/project-07.jpg"],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Terrace",
        description: "A quiet architectural rhythm for open spaces.",
      },
      uz: {
        name: "Terrasa",
        description: "Ochiq maydonlar uchun sokin me’moriy ritm.",
      },
    },
  },
  {
    id: "gl-01",
    category: "glass",
    name: "Воздух / Clear",
    description: "Прозрачные панели и лаконичные металлические стойки.",
    price: 180,
    currency: "USD",
    unit: "metre",
    photos: ["/projects/project-06.jpg", "/projects/project-19.jpg"],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Air / Clear",
        description: "Clear panels framed by minimal steel posts.",
      },
      uz: {
        name: "Havo / Clear",
        description: "Shaffof panellar va ixcham metall ustunlar.",
      },
    },
  },
  {
    id: "gl-02",
    category: "glass",
    name: "Контур / Smoke",
    description: "Тонированное стекло в холодном стальном обрамлении.",
    price: 160,
    currency: "USD",
    unit: "metre",
    photos: ["/projects/project-19.jpg"],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Outline / Smoke",
        description: "Tinted glass within a cool steel frame.",
      },
      uz: {
        name: "Kontur / Smoke",
        description: "Sovuq po‘lat ramkadagi tuslangan shisha.",
      },
    },
  },
  {
    id: "ha-01",
    category: "handrails",
    name: "Касание / Round",
    description: "Круглый пристенный поручень с аккуратными держателями.",
    price: 47,
    currency: "USD",
    unit: "metre",
    photos: [],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Touch / Round",
        description: "A round wall handrail with discreet brackets.",
      },
      uz: {
        name: "Tegish / Round",
        description: "Ixcham tutqichli devor uchun yumaloq qo‘l tutqichi.",
      },
    },
  },
  {
    id: "ha-02",
    category: "handrails",
    name: "Штрих / Satin",
    description: "Матовая поверхность и непрерывная линия вдоль стены.",
    price: 42,
    currency: "USD",
    unit: "metre",
    photos: [],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Stroke / Satin",
        description: "A satin finish and a continuous line along the wall.",
      },
      uz: {
        name: "Shtrix / Satin",
        description: "Devor bo‘ylab uzluksiz chiziq va xira sirt.",
      },
    },
  },
  {
    id: "ac-01",
    category: "accessories",
    name: "Основание / Inox",
    description: "Декоративная накладка основания стойки в цвет конструкции.",
    price: 250000,
    currency: "UZS",
    unit: "piece",
    photos: [],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Base / Inox",
        description: "A decorative post base cover matched to the railing.",
      },
      uz: {
        name: "Asos / Inox",
        description: "Panjara rangiga mos ustun asosi uchun bezak qoplamasi.",
      },
    },
  },
  {
    id: "ac-02",
    category: "accessories",
    name: "Узел / Glass",
    description:
      "Комплект держателей для аккуратного соединения стекла и стали.",
    price: 1250000,
    currency: "UZS",
    unit: "piece",
    photos: [],
    video: null,
    demo: true,
    translations: {
      en: {
        name: "Joint / Glass",
        description: "A bracket set for a precise glass-to-steel connection.",
      },
      uz: {
        name: "Tugun / Glass",
        description:
          "Shisha va po‘latni birlashtirish uchun mahkamlagichlar to‘plami.",
      },
    },
  },
];

export const menuCopy = {
  ru: {
    link: "Прайс-лист",
    title: "Форма.",
    accent: "В деталях.",
    eyebrow: "МЕНЮ / ПРАЙС-ЛИСТ",
    intro: "Выберите категорию и откройте изделие, чтобы рассмотреть детали.",
    demo: "Примеры изделий и цен. Фотографии из портфолио иллюстрируют стиль; точную комплектацию согласуем при заказе.",
    example: "ПРИМЕР",
    order: "Заказать",
    close: "Закрыть",
    previous: "Предыдущее фото",
    next: "Следующее фото",
    gallery: "Фотографии изделия",
    video: "Видео изделия",
    metre: "пог. м",
    piece: "шт.",
    empty: "В этой категории пока нет изделий.",
    configure: "Укажите Telegram-аккаунт в настройках раздела.",
    photo: "Фото",
  },
  uz: {
    link: "Narxlar",
    title: "Shakl.",
    accent: "Tafsilotlarda.",
    eyebrow: "MENYU / NARXLAR",
    intro: "Tafsilotlarni ko‘rish uchun kategoriya va mahsulotni tanlang.",
    demo: "Mahsulotlar va narxlar namuna sifatida berilgan. Portfel suratlari uslubni ko‘rsatadi; tarkib buyurtmada kelishiladi.",
    example: "NAMUNA",
    order: "Buyurtma berish",
    close: "Yopish",
    previous: "Oldingi surat",
    next: "Keyingi surat",
    gallery: "Mahsulot suratlari",
    video: "Mahsulot videosi",
    metre: "pogon metr",
    piece: "dona",
    empty: "Bu kategoriyada hali mahsulot yo‘q.",
    configure: "Bo‘lim sozlamalarida Telegram hisobini kiriting.",
    photo: "Surat",
  },
  en: {
    link: "Price list",
    title: "Form.",
    accent: "In the details.",
    eyebrow: "MENU / PRICE LIST",
    intro: "Choose a category and open a piece to explore its details.",
    demo: "Sample products and prices. Portfolio photos illustrate the style; the exact specification is agreed when ordering.",
    example: "SAMPLE",
    order: "Order",
    close: "Close",
    previous: "Previous photo",
    next: "Next photo",
    gallery: "Product photos",
    video: "Product video",
    metre: "linear m",
    piece: "piece",
    empty: "There are no items in this category yet.",
    configure: "Set a Telegram account in the section settings.",
    photo: "Photo",
  },
};

export function localizeItem(item: MenuItem, locale: MenuLocale) {
  return locale === "ru" ? item : { ...item, ...item.translations?.[locale] };
}
export function formatMenuPrice(item: MenuItem, locale: MenuLocale) {
  const amount = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 })
    .format(item.price)
    .replace(/[\u00a0\u202f]/g, " ");
  const currency =
    item.currency === "USD"
      ? "USD"
      : { ru: "сум", uz: "so‘m", en: "UZS" }[locale];
  return `${amount} ${currency} / ${menuCopy[locale][item.unit]}`;
}
