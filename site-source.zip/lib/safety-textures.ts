import {
  DataTexture,
  RGBAFormat,
  RepeatWrapping,
  SRGBColorSpace,
  LinearFilter,
  LinearMipmapLinearFilter,
} from "three";

/** Small deterministic material maps: no downloads or full-screen AO pass. */
export function safetyTextures() {
  const size = 128;
  const colour = new Uint8Array(size * size * 4);
  const normal = new Uint8Array(size * size * 4);
  const ao = new Uint8Array(64 * 64 * 4);
  const glow = new Uint8Array(64 * 64 * 4);
  const noise = (x: number, y: number) => {
    const v = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
    return v - Math.floor(v);
  };
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const seam = x < 2 || y < 2;
      const grain = noise(x, y) * 9;
      const base = seam ? 105 : 173 + grain + Math.sin(x * 0.08 + y * 0.12) * 2;
      colour.set([base + 8, base + 5, base, 255], i);
      normal.set(
        [
          128 + (noise(x + 1, y) - noise(x - 1, y)) * 26,
          128 + (noise(x, y + 1) - noise(x, y - 1)) * 26,
          254,
          255,
        ],
        i,
      );
    }
  for (let y = 0; y < 64; y++)
    for (let x = 0; x < 64; x++) {
      const i = (y * 64 + x) * 4;
      const r = Math.hypot((x - 31.5) / 31.5, (y - 31.5) / 31.5);
      const alpha = Math.pow(Math.max(0, 1 - r), 2) * 210;
      ao.set([15, 22, 20, alpha], i);
      glow.set([255, 255, 255, Math.pow(Math.max(0, 1 - r), 1.8) * 150], i);
    }
  const stone = new DataTexture(colour, size, size, RGBAFormat);
  stone.colorSpace = SRGBColorSpace;
  const stoneNormal = new DataTexture(normal, size, size, RGBAFormat);
  const contact = new DataTexture(ao, 64, 64, RGBAFormat);
  contact.colorSpace = SRGBColorSpace;
  const halo = new DataTexture(glow, 64, 64, RGBAFormat);
  for (const tex of [stone, stoneNormal]) {
    tex.wrapS = tex.wrapT = RepeatWrapping;
    tex.repeat.set(4, 3);
    tex.generateMipmaps = true;
    tex.minFilter = LinearMipmapLinearFilter;
    tex.magFilter = LinearFilter;
    tex.anisotropy = 4;
  }
  for (const tex of [contact, halo])
    tex.minFilter = tex.magFilter = LinearFilter;
  for (const tex of [stone, stoneNormal, contact, halo]) tex.needsUpdate = true;
  return { stone, stoneNormal, contact, halo };
}
