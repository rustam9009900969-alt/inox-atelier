/** Public files need an explicit prefix when deployed under a repository path. */
export function assetPath(
  path: string,
  basePath = process.env.NEXT_PUBLIC_BASE_PATH || "",
) {
  const prefix = basePath.replace(/\/$/, "");
  if (
    !prefix ||
    !path.startsWith("/") ||
    path.startsWith("//") ||
    path === prefix ||
    path.startsWith(prefix + "/")
  )
    return path;
  return prefix + path;
}
