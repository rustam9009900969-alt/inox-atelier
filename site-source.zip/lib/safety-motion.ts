export type SafetyTimeline = {
  progress: number;
  requestFrame: (() => void) | null;
};

export const SAFETY_DURATION = 5;
export const GLASS_Z = 1.55;
export const CHILD_STOP_Z = 1.2;
const clamp = (n: number) => Math.min(1, Math.max(0, n));
const smooth = (n: number) => {
  const t = clamp(n);
  return t * t * (3 - 2 * t);
};

/** One deterministic pose for playback, scrubbing and reduced-motion mode. */
export function safetyPose(progress: number, safe: boolean) {
  const p = clamp(Number.isFinite(progress) ? progress : 0);
  const t = clamp((p - 0.12) / 0.62);
  const travel = smooth(t);
  const stride =
    t === 0 || t === 1 ? 0 : Math.sin(p * Math.PI * 18) * 4 * t * (1 - t);
  const fall = safe ? 0 : clamp((p - 0.79) / 0.21);
  return {
    // Finish in the middle of a pane, clear of the upright in the default view.
    x: 0.25 - travel * 0.3,
    y: fall ? -2.6 * fall * fall : Math.abs(stride) * 0.018,
    z: -0.72 + travel * ((safe ? CHILD_STOP_Z : 1.92) + 0.72),
    lean: fall * 0.85,
    stride,
    reach: safe ? smooth((p - 0.55) / 0.19) : 0,
    motherTurn: smooth((p - 0.04) / 0.23) * -0.45,
    shadow: 1 - fall,
  };
}
