export type ShowroomView = "overall" | "front" | "side" | "joint";
export function showroomPose(view: ShowroomView, aspect: number) {
  // Existing procedural section: 4.8 wide, 1.7 high. No fabricated dimension options.
  const targets = {
    overall: [0, 0, 0],
    front: [0, 0, 0],
    side: [0, 0, 0],
    joint: [2.1, 0.69, 0],
  } as const;
  const direction =
    view === "front"
      ? [0, 0.12, 1]
      : view === "side"
        ? [1, 0.16, 0.2]
        : view === "joint"
          ? [1, 0.5, 1.8]
          : [1, 0.48, 1.65];
  const norm = Math.hypot(...direction);
  const tangent = Math.tan((32 * Math.PI) / 360);
  const width = view === "side" ? 1.8 : view === "joint" ? 0.75 : 4.8;
  const height = view === "joint" ? 0.75 : 2.2;
  const distance =
    Math.max(
      height / (2 * tangent),
      width / (2 * tangent * Math.max(0.3, aspect)),
    ) * 1.2;
  const target = targets[view];
  return {
    target: [...target],
    position: direction.map((n, i) => target[i] + (n / norm) * distance),
  };
}
