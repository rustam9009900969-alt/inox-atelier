export const locales = ["ru", "uz", "en"] as const;
export type Locale = (typeof locales)[number];
export const localeNames = { ru: "Русский", uz: "O‘zbekcha", en: "English" };
export function isLocale(value: unknown): value is Locale {
  return locales.includes(value as Locale);
}
export const messages: Record<string, Record<"en" | "uz", string>> = {
  "Ракурс изделия": { en: "Product view", uz: "Mahsulot rakursi" },
  "Общий вид": { en: "Overview", uz: "Umumiy ko‘rinish" },
  Спереди: { en: "Front", uz: "Old tomondan" },
  Сбоку: { en: "Side", uz: "Yon tomondan" },
  "Узел поручня": { en: "Handrail connection", uz: "Tutqich birikmasi" },
  "Соберите свой вариант перил": {
    en: "Configure your railing",
    uz: "Panjarangizni tanlang",
  },
  "Ваш вариант": { en: "Your configuration", uz: "Sizning variantingiz" },
  "Получить расчёт": { en: "Request a quote", uz: "Hisob-kitob so‘rash" },
  "Сохранить изображение": { en: "Save image", uz: "Tasvirni saqlash" },
  "Изображение сохранено": { en: "Image saved", uz: "Tasvir saqlandi" },
  "Не удалось сохранить изображение. Попробуйте ещё раз.": {
    en: "Could not save the image. Please try again.",
    uz: "Tasvirni saqlab bo‘lmadi. Qayta urinib ko‘ring.",
  },

  "Прайс-лист": { en: "Price list", uz: "Narxlar" },
  "Разделы сайта": { en: "Site sections", uz: "Sayt bo‘limlari" },
  "ВЫБРАННАЯ КОМПЛЕКТАЦИЯ": {
    en: "YOUR SPECIFICATION",
    uz: "TANLANGAN KOMPLEKTATSIYA",
  },
  "РЕАЛЬНЫЕ ПРОЕКТЫ": {
    en: "COMPLETED PROJECTS",
    uz: "AMALGA OSHIRILGAN LOYIHALAR",
  },
  "Проектирование. Производство. Монтаж.": {
    en: "Design. Manufacture. Installation.",
    uz: "Loyihalash. Ishlab chiqarish. O‘rnatish.",
  },
  "Архитектура стали.": {
    en: "Architecture in steel.",
    uz: "Po‘lat me’morchiligi.",
  },
  Архитектура: { en: "Architecture", uz: "Po‘lat" },
  "стали.": { en: "in steel.", uz: "me’morchiligi." },
  "Архитектурная визуализация": {
    en: "Architectural visualization",
    uz: "Me’moriy vizualizatsiya",
  },
  КОЛЛЕКЦИЯ: {
    en: "COLLECTION",
    uz: "KOLLEKSIYA",
  },
  "ВАША КОНСТРУКЦИЯ": {
    en: "YOUR DESIGN",
    uz: "SIZNING KONSTRUKSIYANGIZ",
  },
  "САМОЕ ВАЖНОЕ": {
    en: "WHAT MATTERS",
    uz: "ENG MUHIMI",
  },
  "НАЧНЁМ С ВАШЕЙ ИДЕИ": {
    en: "START WITH YOUR IDEA",
    uz: "G‘OYANGIZDAN BOSHLAYMIZ",
  },

  "МАТЕРИАЛ / ПОВЕРХНОСТЬ": { en: "MATERIAL / FINISH", uz: "MATERIAL / SIRT" },
  "Одна конструкция — разное впечатление. Выберите поверхность стали для вашего пространства.":
    {
      en: "One structure. Different expressions. Choose the steel finish for your space.",
      uz: "Bitta konstruksiya — turli taassurotlar. Makoningiz uchun po‘lat sirtini tanlang.",
    },
  "Ощущение стали.": { en: "The feel of steel.", uz: "Po‘lat hissi." },
  "Ваше прикосновение.": {
    en: "Your personal touch.",
    uz: "Sizning tanlovingiz.",
  },
  "Одна конструкция — разное впечатление. Рассмотрите поверхность на фотографиях наших работ и выберите её в конфигураторе.":
    {
      en: "One design, a different character. Explore finishes in photographs of our work, then choose yours in the configurator.",
      uz: "Bitta konstruksiya — turli taassurot. Ishlarimiz suratlarida sirtlarni ko‘rib chiqing va konfigurator orqali tanlang.",
    },
  "Поверхность стали": { en: "Steel finish", uz: "Po‘lat sirti" },
  "Фотография нашей работы: {finish}": {
    en: "A photograph of our work: {finish}",
    uz: "Ishimiz surati: {finish}",
  },
  "Свет на поверхности.": {
    en: "Light on the surface.",
    uz: "Sirtdagi yorug‘lik.",
  },
  "Мягкое отражение подчёркивает геометрию стали. Сатиновая отделка подходит тем, кто предпочитает спокойный, сдержанный характер конструкции.":
    {
      en: "Soft reflections reveal the geometry of steel. A satin finish gives the railing a quiet, understated character.",
      uz: "Yumshoq aks po‘lat geometriyasini ta’kidlaydi. Satin sirt sokin va vazmin ko‘rinishni yoqtiradiganlar uchun mos.",
    },
  "Отражение пространства.": {
    en: "Reflecting the space.",
    uz: "Makoningiz aksi.",
  },
  "Полированная сталь отражает окружающую архитектуру. Свет меняется вместе с ракурсом и делает линию поручня выразительнее.":
    {
      en: "Polished steel reflects the surrounding architecture. Light changes with the angle, defining the handrail’s silhouette.",
      uz: "Sayqallangan po‘lat atrofdagi me’morchilikni aks ettiradi. Yorug‘lik rakurs bilan o‘zgarib, tutqich chizig‘ini ifodaliroq qiladi.",
    },
  "Тёплый характер.": { en: "A warmer character.", uz: "Iliq xarakter." },
  "Золотистые детали добавляют тёплый акцент. Оттенок и сочетание элементов согласовываем под интерьер вашего пространства.":
    {
      en: "Gold-toned details introduce a warm accent. We agree the shade and combination of elements to suit your interior.",
      uz: "Oltin tusli detallar iliq aksent beradi. Tus va elementlar uyg‘unligini interyeringizga moslab kelishamiz.",
    },
  "Выбрать в конфигураторе": {
    en: "Choose in configurator",
    uz: "Konfiguratorda tanlash",
  },
  "ПЕРЕД НАЧАЛОМ": { en: "BEFORE WE BEGIN", uz: "BOSHLASHDAN OLDIN" },
  "Важные детали.": { en: "The important details.", uz: "Muhim tafsilotlar." },
  "Простые ответы.": { en: "Straightforward answers.", uz: "Oddiy javoblar." },
  "С чего начать заказ?": {
    en: "How do I start an order?",
    uz: "Buyurtmani qanday boshlash mumkin?",
  },
  "Выберите коллекцию и отделку в конфигураторе. Затем напишите нам или позвоните: обсудим пространство, замер и индивидуальный проект.":
    {
      en: "Choose a collection and finish in the configurator. Then message or call us to discuss your space, measurements and individual design.",
      uz: "Konfiguratorda kolleksiya va sirtni tanlang. So‘ng yozing yoki qo‘ng‘iroq qiling: makon, o‘lchov va individual loyihani muhokama qilamiz.",
    },
  "Как определяется стоимость?": {
    en: "What determines the price?",
    uz: "Narx qanday belgilanadi?",
  },
  "На стоимость влияют длина, заполнение, отделка, сложность креплений и монтаж. Расчёт на сайте предварительный; окончательную сумму согласуем после замера и выбора материалов.":
    {
      en: "Price depends on length, infill, finish, fixing complexity and installation. The website estimate is preliminary; we agree the final amount after measurements and material selection.",
      uz: "Narxga uzunlik, to‘ldirish, sirt, mahkamlash murakkabligi va montaj ta’sir qiladi. Saytdagi hisob dastlabki; yakuniy narx o‘lchov va material tanlovidan keyin kelishiladi.",
    },
  "Можно ли изменить конструкцию под мой интерьер?": {
    en: "Can the design be adapted to my interior?",
    uz: "Konstruksiyani interyerimga moslash mumkinmi?",
  },
  "Да. Обсудим геометрию лестницы или балкона, тип заполнения и поверхность стали. Фотографии пространства помогут подготовиться к разговору.":
    {
      en: "Yes. We discuss your staircase or balcony geometry, infill and steel finish. Photographs of the space help us prepare for the conversation.",
      uz: "Ha. Zinapoya yoki balkon geometriyasi, to‘ldirish turi va po‘lat sirtini muhokama qilamiz. Makon suratlari suhbatga tayyorlanishga yordam beradi.",
    },
  "Что показывает 3D-модель?": {
    en: "What does the 3D model show?",
    uz: "3D model nimani ko‘rsatadi?",
  },
  "Конфигуратор показывает внешний вид и основные этапы сборки. Размеры, крепления и параметры безопасности уточняются для конкретного объекта.":
    {
      en: "The configurator shows the appearance and main assembly stages. Dimensions, fixings and safety specifications are determined for each site.",
      uz: "Konfigurator tashqi ko‘rinish va asosiy yig‘ish bosqichlarini ko‘rsatadi. O‘lchamlar, mahkamlash va xavfsizlik parametrlari har bir obyekt uchun aniqlanadi.",
    },
  "Написать в Telegram": {
    en: "Message on Telegram",
    uz: "Telegram orqali yozish",
  },

  Сила: { en: "Strength", uz: "Kuch" },
  "в каждой": { en: "in every", uz: "har bir" },
  "линии.": { en: "line.", uz: "chiziqda." },
  "Сила в каждой линии.": {
    en: "Strength in every line.",
    uz: "Har bir chiziqda kuch.",
  },
  "Архитектурные ограждения": {
    en: "Architectural railings",
    uz: "Me’moriy to‘siqlar",
  },
  "для пространств со вкусом.": {
    en: "for spaces with character.",
    uz: "did bilan yaratilgan makonlar uchun.",
  },
  "Посмотреть модели": { en: "Explore models", uz: "Modellarni ko‘rish" },
  "НЕРЖАВЕЮЩАЯ СТАЛЬ / ТАШКЕНТ": {
    en: "STAINLESS STEEL / TASHKENT",
    uz: "ZANGLAMAS PO‘LAT / TOSHKENT",
  },
  Процесс: { en: "Process", uz: "Jarayon" },
  "Смотреть сборку на скролле": {
    en: "Scroll through assembly",
    uz: "Yig‘ilishni aylantirib ko‘rish",
  },
  "Сборка прокруткой": { en: "Scroll assembly", uz: "Aylantirib yig‘ish" },
  "ПРОЦЕСС / ЖИВАЯ СБОРКА": {
    en: "PROCESS / LIVE ASSEMBLY",
    uz: "JARAYON / JONLI YIG‘ISH",
  },
  Далее: { en: "Continue", uz: "Davom etish" },
  "Точность.": { en: "Precision.", uz: "Aniqlik." },
  "Шаг за шагом.": { en: "Step by step.", uz: "Bosqichma-bosqich." },
  "Выберите этап сборки": {
    en: "Select an assembly stage",
    uz: "Yig‘ish bosqichini tanlang",
  },
  "Листайте — конструкция собирается.": {
    en: "Scroll to assemble the structure.",
    uz: "Aylantiring — konstruksiya yig‘iladi.",
  },
  "Этапы сборки": { en: "Assembly stages", uz: "Yig‘ish bosqichlari" },
  "Вращать модель": { en: "Rotate model", uz: "Modelni aylantirish" },
  "Продолжить прокрутку": {
    en: "Continue scrolling",
    uz: "Sahifani aylantirishni davom ettirish",
  },
  "Всё начинается с точного основания.": {
    en: "It starts with a precise foundation.",
    uz: "Barchasi aniq asosdan boshlanadi.",
  },
  "Надёжное соединение с основанием.": {
    en: "A secure connection to the foundation.",
    uz: "Asosga mustahkam birikma.",
  },
  "Вертикали задают геометрию конструкции.": {
    en: "Uprights define the geometry.",
    uz: "Ustunlar konstruksiya geometriyasini belgilaydi.",
  },
  "Каждое соединение занимает своё место.": {
    en: "Every connection finds its place.",
    uz: "Har bir birikma o‘z joyiga tushadi.",
  },
  "Непрерывная линия объединяет конструкцию.": {
    en: "A continuous line unites the structure.",
    uz: "Uzluksiz chiziq konstruksiyani birlashtiradi.",
  },
  "Последний штрих. Ваша линия собрана.": {
    en: "The final touch. Your railing is assembled.",
    uz: "Yakuniy qadam. To‘sig‘ingiz yig‘ildi.",
  },
  "Подготавливаем пространство…": {
    en: "Preparing your space…",
    uz: "Makon tayyorlanmoqda…",
  },
  Основание: {
    en: "Foundation",
    uz: "Poydevor",
  },
  Анкеры: {
    en: "Anchors",
    uz: "Ankerlar",
  },
  Стойки: {
    en: "Posts",
    uz: "Ustunlar",
  },
  Держатели: {
    en: "Brackets",
    uz: "Tutqichlar",
  },
  Поручень: {
    en: "Handrail",
    uz: "Qo‘l tutqich",
  },
  Заполнение: {
    en: "Infill",
    uz: "To‘ldirma",
  },
  Сатин: {
    en: "Satin",
    uz: "Satin",
  },
  Зеркало: {
    en: "Mirror",
    uz: "Ko‘zgu",
  },
  Золото: {
    en: "Gold",
    uz: "Oltin",
  },
  "Изменить конфигурацию ограждения и получить демонстрационную оценку. Не отправляет заявку.":
    {
      en: "Configure a railing and get a sample estimate. Does not submit an enquiry.",
      uz: "To‘siqni sozlash va namunaviy narxni hisoblash. Ariza yuborilmaydi.",
    },
  "Некорректная конфигурация": {
    en: "Invalid configuration",
    uz: "Noto‘g‘ri konfiguratsiya",
  },
  "Доступ к датчику не предоставлен. Можно вращать модель пальцем.": {
    en: "Sensor access was not granted. Rotate the model with your finger.",
    uz: "Sensorga ruxsat berilmadi. Modelni barmog‘ingiz bilan aylantiring.",
  },
  "Датчик не поддерживается этим устройством.": {
    en: "This device does not support the sensor.",
    uz: "Bu qurilmada sensor qo‘llab-quvvatlanmaydi.",
  },
  "Наклон устройства управляет ракурсом на первом экране.": {
    en: "Tilt your device to move the view on the first screen.",
    uz: "Birinchi ekrandagi ko‘rinishni qurilmani qiyalatib boshqaring.",
  },
  "Датчик недоступен. Используйте касание.": {
    en: "Sensor unavailable. Use touch controls.",
    uz: "Sensor ishlamayapti. Sensorli boshqaruvdan foydalaning.",
  },
  включён: {
    en: "included",
    uz: "kiritilgan",
  },
  "без монтажа": {
    en: "without installation",
    uz: "montajsiz",
  },
  "Перейти к конфигуратору": {
    en: "Skip to configurator",
    uz: "Konfiguratorga o‘tish",
  },
  "INOX ATELIER — в начало": {
    en: "INOX ATELIER — home",
    uz: "INOX ATELIER — bosh sahifa",
  },
  "Основная навигация": {
    en: "Main navigation",
    uz: "Asosiy navigatsiya",
  },
  Коллекция: {
    en: "Collection",
    uz: "Kolleksiya",
  },
  Конфигуратор: {
    en: "Configurator",
    uz: "Konfigurator",
  },
  Безопасность: {
    en: "Safety",
    uz: "Xavfsizlik",
  },
  "Закрыть меню": {
    en: "Close menu",
    uz: "Menyuni yopish",
  },
  "Открыть меню": {
    en: "Open menu",
    uz: "Menyuni ochish",
  },
  "Мобильная навигация": {
    en: "Mobile navigation",
    uz: "Mobil navigatsiya",
  },
  Контакты: {
    en: "Contact",
    uz: "Aloqa",
  },
  "ФОРМА / МАТЕРИАЛ / ТОЧНОСТЬ": {
    en: "FORM / MATERIAL / PRECISION",
    uz: "SHAKL / MATERIAL / ANIQLIK",
  },
  "ПЕРИЛА И ОГРАЖДЕНИЯ / НА ЗАКАЗ": {
    en: "RAILINGS / MADE TO MEASURE",
    uz: "PANJARA VA TO‘SIQLAR / BUYURTMA ASOSIDA",
  },
  "Сталь. Вне времени.": {
    en: "Steel. Timeless.",
    uz: "Po‘lat. Vaqtdan ustun.",
  },
  СТАЛЬ: {
    en: "STEEL",
    uz: "PO‘LAT",
  },
  "ВНЕ ВРЕМЕНИ.": {
    en: "TIMELESS.",
    uz: "VAQTDAN USTUN.",
  },
  "Выразительная форма. Безупречная сталь.": {
    en: "Expressive form. Impeccable steel.",
    uz: "Ifodali shakl. Mukammal po‘lat.",
  },
  "Ограждения для архитектуры с характером.": {
    en: "Railings for architecture with character.",
    uz: "O‘ziga xos arxitektura uchun to‘siqlar.",
  },
  "СОЗДАТЬ СВОЙ ПРОЕКТ": {
    en: "CREATE YOUR PROJECT",
    uz: "LOYIHANGIZNI YARATING",
  },
  "СТАЛЬ · СТЕКЛО · СВЕТ": {
    en: "STEEL · GLASS · LIGHT",
    uz: "PO‘LAT · SHISHA · YORUG‘LIK",
  },
  "Листайте, чтобы почувствовать детали": {
    en: "Scroll to discover the details",
    uz: "Tafsilotlarni ko‘rish uchun pastga suring",
  },
  "ПРОИЗВОДСТВО И МОНТАЖ": {
    en: "FABRICATION & INSTALLATION",
    uz: "ISHLAB CHIQARISH VA MONTAJ",
  },
  "Наш подход": {
    en: "Our approach",
    uz: "Yondashuvimiz",
  },
  "Выразительный дизайн": {
    en: "Expressive design",
    uz: "Ifodali dizayn",
  },
  "Точная обработка стали": {
    en: "Precision steelwork",
    uz: "Po‘latga aniq ishlov",
  },
  "Монтаж под ваш проект": {
    en: "Installation tailored to you",
    uz: "Loyihangizga mos montaj",
  },
  "01 — КОЛЛЕКЦИЯ": {
    en: "01 — COLLECTION",
    uz: "01 — KOLLEKSIYA",
  },
  "Три характера. Ваша архитектура.": {
    en: "Three characters. Your architecture.",
    uz: "Uch xil uslub. Sizning arxitekturangiz.",
  },
  "ФОРМА.": {
    en: "FORM.",
    uz: "SHAKL.",
  },
  "БЕЗ ЛИШНЕГО.": {
    en: "NOTHING EXTRA.",
    uz: "ORTIQCHALIKSIZ.",
  },
  "От невесомого стекла до выразительной классики.": {
    en: "From weightless glass to expressive classics.",
    uz: "Yengil shishadan ifodali klassikagacha.",
  },
  "Выберите основу для своего пространства.": {
    en: "Choose the foundation for your space.",
    uz: "Makoningiz uchun asosni tanlang.",
  },
  "КОЛЛЕКЦИЯ / 0": {
    en: "COLLECTION / 0",
    uz: "KOLLEKSIYA / 0",
  },
  "02 — ВАША КОНСТРУКЦИЯ": {
    en: "02 — YOUR DESIGN",
    uz: "02 — SIZNING KONSTRUKSIYANGIZ",
  },
  "Исследуйте каждое соединение": {
    en: "Explore every connection",
    uz: "Har bir birikmani o‘rganing",
  },
  "ТОЧНОСТЬ.": {
    en: "PRECISION.",
    uz: "ANIQLIK.",
  },
  "В КАЖДОЙ ДЕТАЛИ.": {
    en: "IN EVERY DETAIL.",
    uz: "HAR BIR DETALDA.",
  },
  "Поверните. Разберите. Посмотрите внутрь.": {
    en: "Rotate. Disassemble. Look inside.",
    uz: "Aylantiring. Ajrating. Ichini ko‘ring.",
  },
  "Продуманная конструкция — со всех сторон.": {
    en: "Thoughtful design, from every angle.",
    uz: "Har tomondan puxta o‘ylangan konstruksiya.",
  },
  Разобрать: {
    en: "Explode",
    uz: "Ajratish",
  },
  Рентген: {
    en: "X-ray",
    uz: "Rentgen",
  },
  "Сбросить ракурс": {
    en: "Reset view",
    uz: "Ko‘rinishni tiklash",
  },
  "Приблизить модель": {
    en: "Zoom in",
    uz: "Yaqinlashtirish",
  },
  "Отдалить модель": {
    en: "Zoom out",
    uz: "Uzoqlashtirish",
  },
  "Вращайте мышью или пальцем · два пальца для масштаба": {
    en: "Drag to rotate · pinch with two fingers to zoom",
    uz: "Aylantirish uchun suring · ikki barmoq bilan masshtablang",
  },
  "ИНДИВИДУАЛЬНЫЙ ПРОЕКТ": {
    en: "BESPOKE PROJECT",
    uz: "INDIVIDUAL LOYIHA",
  },
  "Ваша линия.": {
    en: "Your line.",
    uz: "Sizning chizig‘ingiz.",
  },
  "Ваш характер.": {
    en: "Your character.",
    uz: "Sizning uslubingiz.",
  },
  "01 / Модель": {
    en: "01 / Model",
    uz: "01 / Model",
  },
  "02 / Поверхность стали": {
    en: "02 / Steel finish",
    uz: "02 / Po‘lat yuzasi",
  },
  "Параметрическая визуализация по мотивам наших работ. Пропорции уточняются после замера.":
    {
      en: "Parametric visualisation inspired by our work. Proportions are refined after measurement.",
      uz: "Ishlarimiz asosidagi parametrik tasvir. O‘lchovdan so‘ng nisbatlar aniqlashtiriladi.",
    },
  "Отключить наклон": {
    en: "Disable tilt",
    uz: "Qiyalikni o‘chirish",
  },
  "Управление наклоном": {
    en: "Tilt control",
    uz: "Qiyalik bilan boshqarish",
  },
  "ЖИВАЯ СБОРКА": {
    en: "LIVE ASSEMBLY",
    uz: "JONLI YIG‘ISH",
  },
  "Конструкция собрана": {
    en: "Assembly complete",
    uz: "Konstruksiya yig‘ildi",
  },
  Остановить: {
    en: "Stop",
    uz: "To‘xtatish",
  },
  "Собрать заново": {
    en: "Assemble again",
    uz: "Qayta yig‘ish",
  },
  "03 — САМОЕ ВАЖНОЕ": {
    en: "03 — WHAT MATTERS",
    uz: "03 — ENG MUHIMI",
  },
  "СПОКОЙСТВИЕ.": {
    en: "PEACE OF MIND.",
    uz: "XOTIRJAMLIK.",
  },
  "В КАЖДОЙ ЛИНИИ.": {
    en: "IN EVERY LINE.",
    uz: "HAR BIR CHIZIQDA.",
  },
  "Один звонок. Одно мгновение.": {
    en: "One call. One moment.",
    uz: "Bir qo‘ng‘iroq. Bir lahza.",
  },
  "Ограждение становится границей": {
    en: "A railing forms a boundary",
    uz: "To‘siq chegara bo‘lib xizmat qiladi",
  },
  "между обычным днём и опасностью.": {
    en: "between an ordinary day and danger.",
    uz: "oddiy kun va xavf o‘rtasida.",
  },
  "Сценарий безопасности": {
    en: "Safety scenario",
    uz: "Xavfsizlik ssenariysi",
  },
  "Без ограждения": {
    en: "Without railing",
    uz: "To‘siqsiz",
  },
  "С ограждением": {
    en: "With railing",
    uz: "To‘siq bilan",
  },
  "Преграда на пути к краю.": {
    en: "A barrier before the edge.",
    uz: "Chetga borish yo‘lida to‘siq.",
  },
  "Открытый край — риск падения.": {
    en: "An open edge risks a fall.",
    uz: "Ochiq chet — yiqilish xavfi.",
  },
  "Ребёнок останавливается перед стеклом.": {
    en: "The child stops at the glass.",
    uz: "Bola shisha oldida to‘xtaydi.",
  },
  "Условная сцена показывает последствия отсутствия защиты.": {
    en: "An illustrative scene shows the consequences of missing protection.",
    uz: "Shartli sahna himoya yo‘qligining oqibatlarini ko‘rsatadi.",
  },
  "Схематическая иллюстрация, не испытание конструкции. Безопасность зависит от проекта, стекла, крепежа и монтажа. Ограждение не заменяет присмотр за ребёнком.":
    {
      en: "An illustration, not a structural test. Safety depends on design, glass, fixings and installation. Railings do not replace adult supervision.",
      uz: "Bu sxematik tasvir, konstruksiya sinovi emas. Xavfsizlik loyiha, shisha, mahkamlash va montajga bog‘liq. To‘siq bola nazoratining o‘rnini bosmaydi.",
    },
  "СЦЕНАРИЙ С ЗАЩИТОЙ": {
    en: "PROTECTED SCENARIO",
    uz: "HIMOYALI SSENARIY",
  },
  "СЦЕНАРИЙ БЕЗ ЗАЩИТЫ": {
    en: "UNPROTECTED SCENARIO",
    uz: "HIMOYASIZ SSENARIY",
  },
  "Воспроизвести сценарий": {
    en: "Play scenario",
    uz: "Ssenariyni ijro etish",
  },
  "Ход сценария": {
    en: "Scenario progress",
    uz: "Ssenariy jarayoni",
  },
  "Ручной режим": {
    en: "Manual mode",
    uz: "Qo‘lda boshqarish",
  },
  "5 СЕК": {
    en: "5 SEC",
    uz: "5 SONIYA",
  },
  "04 — РЕАЛЬНЫЕ ПРОЕКТЫ": {
    en: "04 — COMPLETED PROJECTS",
    uz: "04 — AMALGA OSHIRILGAN LOYIHALAR",
  },
  "Детали, которые уже стали частью дома": {
    en: "Details already part of a home",
    uz: "Uylarning bir qismiga aylangan detallar",
  },
  "В АРХИТЕКТУРЕ.": {
    en: "IN ARCHITECTURE.",
    uz: "ARXITEKTURADA.",
  },
  "В РЕАЛЬНОСТИ.": {
    en: "IN REAL LIFE.",
    uz: "HAQIQATDA.",
  },
  "Свернуть галерею": {
    en: "Collapse gallery",
    uz: "Galereyani yig‘ish",
  },
  "Все 20 проектов": {
    en: "All 20 projects",
    uz: "Barcha 20 loyiha",
  },
  "ПРОЕКТ /": {
    en: "PROJECT /",
    uz: "LOYIHA /",
  },
  "Прозрачность в деталях": {
    en: "Clarity in the details",
    uz: "Detallardagi shaffoflik",
  },
  "Геометрия пространства": {
    en: "Geometry of space",
    uz: "Makon geometriyasi",
  },
  "Плавность линий": {
    en: "Flowing lines",
    uz: "Ravon chiziqlar",
  },
  "Характер стали": {
    en: "The character of steel",
    uz: "Po‘latning o‘ziga xosligi",
  },
  "05 — НАЧНЁМ С ВАШЕЙ ИДЕИ": {
    en: "05 — START WITH YOUR IDEA",
    uz: "05 — G‘OYANGIZDAN BOSHLAYMIZ",
  },
  "ВАША ИДЕЯ.": {
    en: "YOUR IDEA.",
    uz: "SIZNING G‘OYANGIZ.",
  },
  "ТОЧНЫЙ РАСЧЁТ.": {
    en: "A CLEAR ESTIMATE.",
    uz: "ANIQ HISOB.",
  },
  "Укажите длину и состав работ.": {
    en: "Choose the length and scope of work.",
    uz: "Uzunlik va ishlar tarkibini belgilang.",
  },
  "Конфигурация уже учитывает выбранный дизайн.": {
    en: "Your selected design is already included.",
    uz: "Tanlangan dizayn allaqachon hisobga olingan.",
  },
  "Добавить фото пространства": {
    en: "Add a photo of your space",
    uz: "Makon suratini qo‘shish",
  },
  "Выберите JPG, PNG или WebP до 10 МБ.": {
    en: "Choose a JPG, PNG or WebP up to 10 MB.",
    uz: "10 MB gacha JPG, PNG yoki WebP tanlang.",
  },
  "Фото открыто только на вашем устройстве. Оно не отправляется и не преобразуется автоматически в 3D.":
    {
      en: "The photo stays on your device. It is not uploaded or automatically converted to 3D.",
      uz: "Surat faqat qurilmangizda ochiladi. U yuborilmaydi va avtomatik 3D ga aylantirilmaydi.",
    },
  "Ваш референс пространства": {
    en: "Your space reference",
    uz: "Makoningiz namunasi",
  },
  "Удалить выбранное фото": {
    en: "Remove selected photo",
    uz: "Tanlangan suratni olib tashlash",
  },
  "Ваш проект": {
    en: "Your project",
    uz: "Sizning loyihangiz",
  },
  "Длина ограждения": {
    en: "Railing length",
    uz: "To‘siq uzunligi",
  },
  м: {
    en: "m",
    uz: "m",
  },
  "Длина ограждения в метрах": {
    en: "Railing length in metres",
    uz: "To‘siq uzunligi metrlarda",
  },
  "1 м": {
    en: "1 m",
    uz: "1 m",
  },
  "100 м": {
    en: "100 m",
    uz: "100 m",
  },
  "Включить монтаж": {
    en: "Include installation",
    uz: "Montajni qo‘shish",
  },
  "Демонстрационный расчёт": {
    en: "Sample estimate",
    uz: "Namunaviy hisob",
  },
  сум: {
    en: "UZS",
    uz: "so‘m",
  },
  "Пример расчёта, не оферта. Точный бюджет — после замера и согласования материалов.":
    {
      en: "Illustrative estimate, not an offer. Final pricing follows measurement and material approval.",
      uz: "Namunaviy hisob, oferta emas. Yakuniy narx o‘lchov va materiallar kelishilgandan keyin belgilanadi.",
    },
  "Обсудить мой проект": {
    en: "Discuss my project",
    uz: "Loyihamni muhokama qilish",
  },
  "ВАШЕ ПРОСТРАНСТВО НАЧИНАЕТСЯ С ДИАЛОГА": {
    en: "YOUR SPACE STARTS WITH A CONVERSATION",
    uz: "MAKONINGIZ SUHBATDAN BOSHLANADI",
  },
  СОЗДАДИМ: {
    en: "LET’S CREATE",
    uz: "YARATAMIZ",
  },
  "ВАШУ ЛИНИЮ.": {
    en: "YOUR LINE.",
    uz: "SIZNING CHIZIG‘INGIZNI.",
  },
  "Заказать индивидуальный 3D-проект": {
    en: "Request a bespoke 3D project",
    uz: "Individual 3D loyiha buyurtma qilish",
  },
  "ФОРМА. МАТЕРИАЛ. ТОЧНОСТЬ.": {
    en: "FORM. MATERIAL. PRECISION.",
    uz: "SHAKL. MATERIAL. ANIQLIK.",
  },
  "Наверх ↑": {
    en: "Back to top ↑",
    uz: "Yuqoriga ↑",
  },
  "Закрыть окно проекта": {
    en: "Close project window",
    uz: "Loyiha oynasini yopish",
  },
  "Ваша идея.": {
    en: "Your idea.",
    uz: "Sizning g‘oyangiz.",
  },
  "Следующий шаг.": {
    en: "The next step.",
    uz: "Keyingi qadam.",
  },
  "Позвоните нам для замера и подготовки 3D-проекта. Сохраните выбранные параметры, чтобы обсудить детали.":
    {
      en: "Call us to arrange a measurement and 3D project. Save your choices to discuss the details.",
      uz: "O‘lchov va 3D loyiha uchun bizga qo‘ng‘iroq qiling. Tafsilotlarni muhokama qilish uchun tanlovingizni saqlang.",
    },
  Поверхность: {
    en: "Finish",
    uz: "Yuza",
  },
  Длина: {
    en: "Length",
    uz: "Uzunlik",
  },
  Монтаж: {
    en: "Installation",
    uz: "Montaj",
  },
  Включён: {
    en: "Included",
    uz: "Kiritilgan",
  },
  "Без монтажа": {
    en: "Without installation",
    uz: "Montajsiz",
  },
  "Скачать параметры проекта": {
    en: "Download project details",
    uz: "Loyiha parametrlarini yuklab olish",
  },
  "Заявка автоматически не отправляется. Позвоните нам или напишите в Telegram.":
    {
      en: "No enquiry is sent automatically. Call us or write to us on Telegram.",
      uz: "Ariza avtomatik yuborilmaydi. Qo‘ng‘iroq qiling yoki Telegram orqali yozing.",
    },
  "Повторить загрузку 3D": { en: "Retry 3D", uz: "3D ni qayta yuklash" },
  "Пример ограждения из портфолио": {
    en: "Railing from our portfolio",
    uz: "Portfoliodagi to‘siq namunasi",
  },
  "Фотография проекта · 3D недоступно на этом устройстве": {
    en: "Project photograph · 3D is unavailable on this device",
    uz: "Loyiha surati · bu qurilmada 3D mavjud emas",
  },
  "Схематическая 3D-сцена безопасности": {
    en: "Illustrative 3D safety scene",
    uz: "Sxematik 3D xavfsizlik sahnasi",
  },
  "Интерактивная 3D-модель ограждения": {
    en: "Interactive 3D railing model",
    uz: "To‘siqning interaktiv 3D modeli",
  },
  "Сталь. Стекло. Совершенство.": {
    en: "Steel. Glass. Perfection.",
    uz: "Po‘lat. Shisha. Mukammallik.",
  },
  "Выключить звуковые эффекты": {
    en: "Turn sound effects off",
    uz: "Ovoz effektlarini o‘chirish",
  },
  "Включить звуковые эффекты": {
    en: "Turn sound effects on",
    uz: "Ovoz effektlarini yoqish",
  },
  ЗВУК: {
    en: "SOUND",
    uz: "OVOZ",
  },
  ВКЛ: {
    en: "ON",
    uz: "YOQ",
  },
  ВЫКЛ: {
    en: "OFF",
    uz: "O‘CH",
  },
  "Сталь + стекло": {
    en: "Steel + glass",
    uz: "Po‘lat + shisha",
  },
  "Прозрачность. Ничего лишнего.": {
    en: "Transparency. Nothing extra.",
    uz: "Shaffoflik. Ortiqcha hech narsa.",
  },
  "Ригельные ограждения": {
    en: "Horizontal railings",
    uz: "Rigelli to‘siqlar",
  },
  "Точность в каждой линии.": {
    en: "Precision in every line.",
    uz: "Har bir chiziqda aniqlik.",
  },
  "Декоративные балясины": {
    en: "Decorative balusters",
    uz: "Bezakli balyasinalar",
  },
  "Характер в каждой детали.": {
    en: "Character in every detail.",
    uz: "Har bir detalda o‘ziga xoslik.",
  },
  "Некорректные параметры": {
    en: "Invalid parameters",
    uz: "Noto‘g‘ri parametrlar",
  },
  "Настроить {name}": {
    en: "Configure {name}",
    uz: "{name} ni sozlash",
  },
  "Этап {number}: {name}": {
    en: "Step {number}: {name}",
    uz: "{number}-bosqich: {name}",
  },
  "Проект {number}: открыть похожую модель в 3D": {
    en: "Project {number}: explore a similar model in 3D",
    uz: "{number}-loyiha: o‘xshash modelni 3D da ochish",
  },
  "Реализованный проект {number}: ограждение из нержавеющей стали": {
    en: "Completed project {number}: stainless steel railing",
    uz: "{number}-loyiha: zanglamaydigan po‘lat to‘siq",
  },
  конфигурация: {
    en: "configuration",
    uz: "konfiguratsiya",
  },
  Модель: {
    en: "Model",
    uz: "Model",
  },
  "Не является офертой. Итоговая стоимость — после замера.": {
    en: "Not an offer. Final pricing follows measurement.",
    uz: "Oferta emas. Yakuniy narx o‘lchovdan keyin belgilanadi.",
  },
  Телефон: {
    en: "Phone",
    uz: "Telefon",
  },
  "Язык сайта": {
    en: "Site language",
    uz: "Sayt tili",
  },
  "Архитектура уверенности": {
    en: "Architecture of confidence",
    uz: "Ishonch arxitekturasi",
  },
  "Производство и монтаж перил из нержавеющей стали. Выберите дизайн, изучите конструкцию в 3D и рассчитайте ваш проект.":
    {
      en: "Stainless steel railing fabrication and installation. Choose a design, explore it in 3D and estimate your project.",
      uz: "Zanglamaydigan po‘lat panjaralar ishlab chiqarish va montaj. Dizaynni tanlang, 3D da ko‘ring va loyihangiz narxini hisoblang.",
    },
};
export function translate(
  locale: Locale,
  source: string,
  params: Record<string, string | number> = {},
) {
  const text =
    locale === "ru" ? source : (messages[source]?.[locale] ?? source);
  return text.replace(/\{(\w+)\}/g, (match, key) =>
    String(params[key] ?? match),
  );
}
export const numberLocale: Record<Locale, string> = {
  ru: "ru-RU",
  uz: "uz-UZ",
  en: "en-US",
};
