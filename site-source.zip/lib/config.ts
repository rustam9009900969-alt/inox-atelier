import { assetPath } from "./asset-path.ts";
export type ModelId = "glass" | "rigel" | "classic";
export type Finish = "satin" | "polished" | "gold";
export const models = [
  {
    id: "glass" as const,
    name: "Pure Glass",
    label: "Сталь + стекло",
    detail: "Прозрачность. Ничего лишнего.",
    image: assetPath("/projects/project-19.jpg"),
    rate: 1650000,
  },
  {
    id: "rigel" as const,
    name: "Linear Steel",
    label: "Ригельные ограждения",
    detail: "Точность в каждой линии.",
    image: assetPath("/projects/project-20.jpg"),
    rate: 950000,
  },
  {
    id: "classic" as const,
    name: "Atelier Classic",
    label: "Декоративные балясины",
    detail: "Характер в каждой детали.",
    image: assetPath("/projects/project-15.jpg"),
    rate: 1250000,
  },
];
export const phone = "+998931220101";
export function estimate(
  model: ModelId,
  length: number,
  finish: Finish,
  installation: boolean,
) {
  if (
    !models.some((m) => m.id === model) ||
    !Number.isFinite(length) ||
    length < 1 ||
    length > 100 ||
    !["satin", "polished", "gold"].includes(finish)
  )
    throw new Error("Некорректные параметры");
  const rate = models.find((m) => m.id === model)!.rate;
  return (
    Math.round(
      (rate *
        length *
        (finish === "gold" ? 1.3 : finish === "polished" ? 1.08 : 1) +
        (installation ? length * 180000 : 0)) /
        1000,
    ) * 1000
  );
}
export const money = (n: number, locale = "ru-RU") =>
  new Intl.NumberFormat(locale).format(n);
