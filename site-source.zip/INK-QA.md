# Ink & Steel verification · 2026-10-03

Production build passed; TypeScript and all 9 project tests passed. Frontend Design Premium strict static audit: zero findings (/tmp/ink-audit.json).

Browser checks: desktop collection and materials with generated imagery; model and finish selection; live WebGL rigel scene; assembly forward stage 5 and reverse stage 2; price category switching; product dialog and Escape; contact dialog with selected model/finish and no automatic transmission; RU/UZ switching; UZ 390x844 with document width matching viewport. Approved hero preserved; fixed a gradient override hiding its text. Cursor data-active matches effect code; material image entry obeys reduced motion.

Generated imagery is labelled architectural visualization. Genuine portfolio photographs retained. No strength/jumping test restored. Three images total approximately 550 KB. No universal FPS guarantee claimed.

Published source commit: 666c1cc9ddaf15dfc48ab134c49d6a0f219547d2.
Successful build/deploy: https://github.com/rustam9009900969-alt/inox-atelier/actions/runs/37135495767
Public site: https://rustam9009900969-alt.github.io/inox-atelier/?lang=ru#collection
