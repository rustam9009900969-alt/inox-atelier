---
name: INOX ATELIER
colors:
  primary: "#405bcc"
  background: "#111e33"
  surface: "#1b2c45"
  text: "#f0f3f7"
  muted: "#afbdcf"
  accent: "#bccdff"
  paper: "#eaf0f5"
  paperInk: "#14233b"
typography:
  sans:
    fontFamily: "Manrope, sans-serif"
    lineHeight: "1.65"
  editorial:
    fontFamily: "Cormorant Garamond, serif"
    lineHeight: "1.08"
rounded:
  DEFAULT: "4px"
spacing:
  phoneGutter: "22px"
  sectionMin: "88px"
  sectionMax: "160px"
---

# INOX ATELIER — Ink & Steel interiors

## Scope and direction · 2026-10-03

The user subsequently requested that the warm first screen match the blue/silver interior. Hero uses the shared Ink & Steel tokens and Manrope/Cormorant typography. The existing atelier-hero.webp is rendered in monochrome with an ink-blue atmosphere; app/hero-preserved.css owns its responsive composition.

Interior art direction: architectural ink blue, cold silver paper, cobalt accents; airy staggered product studies instead of repeated boxes. Manrope handles functional typography and first display lines, Cormorant Garamond italic second display lines. Local fonts cover Cyrillic and Latin. Body line-height 1.65; responsive headlines use optical negative tracking. Controls remain readable geometric sans. Radius 4px; section spacing 88–160px, phone gutter 22px.

## Runtime ownership

app/studio.css owns shared interior runtime tokens. DESIGN.md describes those values; it does not generate a separate theme. PriceMenu.module.css consumes var(--paper), var(--paper-raised), var(--paper-ink), var(--paper-muted), var(--cobalt), var(--line), var(--body) and var(--display). app/layout.tsx registers local font variables. Globals imports structure.css, motion.css, studio.css, then hero-preserved.css and showroom.css. Old luxury/reference/typography files are historical and not imported. Earlier rationale is in DESIGN-history.md.

## Sections

Collection: three tall offset image columns on desktop; equal single-column phone cards. New glass and rigel images are labelled architectural visualizations. Classic retains genuine user photo.
Architecture interlude: dedicated generated space photograph, large italic title, scroll parallax and ribbon.
Materials: oversized image plus unboxed copy; surface switching fades and gently settles the new image. Two new illustrative photos and one genuine gold-detail project.
Configurator: warm neutral product-studio variant, with paper #f1eee8, raised #faf8f4, ink #2b2c2b, muted #62645f and bronze UI accent #72624d owned by app/showroom.css. This neutral surround avoids blue colour contamination when inspecting real steel. Selected model and finish are explicit; physical glass on desktop, inexpensive transparency on mobile. Overall/front/side/handrail-joint camera views, manual interruption, reset and PNG export preserve shared state and enquiry.
Assembly: dark ink native sticky viewport, reversible five-stage scroll progression, six labelled step controls. Reduced motion uses manual stages. Mobile preserves model space and compact navigation.
Safety: dark studio card; existing illustrative timeline remains. No jumping or strength-test demonstration.
Projects: staggered two-column real-photo gallery; these are never substituted by generated imagery.
Quote and menu: light mineral worksheets and image-led products, sticky categories, native dialogs.
FAQ: quiet light split composition. Contact: cobalt closing section, large italic invitation, direct Telegram and phone. Footer: ink grid navigation.

## Motion and accessibility

Scroll reveals use opacity/20px translation with cubic-bezier(.16,1,.3,1). Existing reversible headline glints, photographic parallax and staged assembly retained. Fine pointer cursor uses crosshair/arrow/card brackets and magnetic controls; cursor now correctly responds to data-active. Touch and reduced-motion disable cursor/magnetic effects; reduced motion disables material arrival. No extra WebGL canvas added. Offscreen scenes pause. SSR text remains accessible; native focus-restoring dialogs and visible keyboard focus retained.

RU/UZ/EN, @udhdrg, +998 93 122 01 01 and UX-CONTRACT.md remain authoritative. Prices in calculator remain explicitly illustrative. Generated images are not evidence of completed works or material tests.

## Creative provenance

Frontend Design Premium and Product Design used for hierarchy, palette, responsive composition and workflow preservation. Firecrawl read https://www.clevante.cz for architectural presentation; no reference assets or copy imported. Creative Production used for the consistent visual brief and parallel raster production. Its board tools were unavailable; built-in ImageGen produced the images. Sites was explicitly excluded.

Generated WebP files (1086 × 1448): public/media/ink-glass.webp (164KB), ink-steel.webp (207KB), ink-space.webp (184KB). Original PNGs: /outputs/ink-glass.png; /outputs/ink-steel.png; Codex generated_images/01a0c441-d076-7551-a2ae-700a1e1fe4ed/exec-b2283424-b0f0-4361-b7b5-f22456493106.png. Tools: built-in ImageGen, then local WebP encoding. Shared prompt direction: photorealistic architectural stainless steel and clear blue-grey glass, precise square posts and clamps, limestone/concrete, deep ink wall, cold north daylight, soft reflections, no people, text or logos. Variants: glass balustrade product portrait; rigel railing product portrait; staircase architectural scene. All labelled visualizations in the UI.

## Showroom geometry and evidence · 2026-10-04

The three existing procedural products retain their section proportions: glass, horizontal rigels and decorative balusters. No measured CAD, engineering rating or new assortment is claimed. Length changes the demonstration estimate only. Original components are retained in work/showroom-before/*.bak. Steel uses shared cylinder buffers, longitudinal micro-normal texture on desktop satin, smooth finish transitions and bounded studio environment capture. Existing bracket dimensions are retained with small edge radii; glass has physical transmission and edge accents. Camera poses fit viewport aspect, focus the actual upper right post joint, and stop interpolation on manual input. PNG export is enabled only after the viewer mounts.
