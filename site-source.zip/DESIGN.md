---
name: INOX ATELIER
colors:
  primary: "#ceb28c"
  background: "#171614"
  surface: "#24211e"
  text: "#f4f0e9"
  muted: "#b7b0a5"
  accent: "#ceb28c"
  paper: "#e8e4dc"
  paperInk: "#25221e"
typography:
  sans:
    fontFamily: "Onest, sans-serif"
    lineHeight: "1.65"
  editorial:
    fontFamily: "Oswald, sans-serif"
    lineHeight: "1.08"
rounded:
  DEFAULT: "10px"
spacing:
  compact: "12px"
  control: "20px"
  phoneGutter: "22px"
  sectionMin: "88px"
  sectionMax: "152px"
---

# INOX ATELIER — Sculpture Edition

## Full-page continuation · 2026-10-03

The Sculpture direction now covers every section beyond the hero. Local Oswald uppercase is the display role for collection, finishes, configurator, assembly, safety, portfolio, quote, menu, FAQ and contact; Onest remains the functional text role. Shared runtime owner remains app/studio.css; the interior composition block owns section geometry and responsive variants. No new theme import.

Finishes use a large freestanding material photograph and an unboxed description. Configurator is an illuminated taupe product workbench with dark controls, three real-photo model samples and stacked finish swatches. Assembly uses the same palette, labelled six-step desktop navigation and native sticky scroll; compact phone navigation preserves canvas space. Portfolio is a staggered two-column gallery, equal single-column on phones. Quote is a mineral worksheet with the current model photograph, finish and label tied to shared state; pricing remains demonstration data. Menu adapts the mineral palette through its CSS module, has an opaque sticky category surface and brighter image-led cards. FAQ is mineral with dark ink. Contact returns to charcoal, oversized condensed type, a direct Telegram link and phone, followed by section navigation. Existing UX-CONTRACT and reduced-motion/touch guards remain unchanged. No strength-test animation was restored.

## Active direction · 2026-10-03

This edition supersedes all earlier prose below. The previous editorial headline and flat repeated section rhythm were rejected by the user. The new thesis is a close architectural portrait of inox and glass: a sculptural staircase, clear material detail, dark plaster and warm natural light. Local Oswald 400 carries the condensed uppercase hero, local Onest carries navigation, body and functional headings. No decorative serif headline is retained.

Runtime owner: app/studio.css. Palette: charcoal #171614, surface #24211e, ivory #f4f0e9, muted stone #b7b0a5, champagne #ceb28c, mineral #e8e4dc, mineral ink #25221e. Radius 10px for shared cards, panels and buttons; utility compact controls retain established geometry. PriceMenu.module.css adapts bg/panel/text/muted/accent from the runtime owner. Historical theme files provide compatibility and sticky behavior, not normative colours.

Hero: full image background on desktop, two condensed lines with clear actions on the quiet left. A floating dark glass navigation surface protects contrast across the photograph. On mobile, type and actions precede a separate product image. UZ uses a narrower headline scale for its longer word.

Collection: one tall featured glass product plus two stacked product studies. On mobile the three designs stack with equal image ratios. Portfolios remain real user photographs. Generated hero is labelled Architectural visualization in RU/UZ/EN and must never be presented as a completed project.

Generated asset: public/media/atelier-hero.webp, 1672x941, about 233KB. Built-in ImageGen used, then WebP encoding. Prompt: photorealistic architectural inox/glass railing, square posts and clamps inspired by user project 19, dark limestone stair, quiet charcoal left, warm skylight, fine steel reflections and glass detail, no people/text/logo. Original retained in Codex generated_images. One generated asset; no Creative Production board tool was available. Firecrawl read https://www.poliform.it/en/ for architectural product presentation; no reference brand assets or text copied. Sites explicitly excluded.

Interaction contracts in UX-CONTRACT.md remain authoritative: shared model/finish/quote, reversible scroll assembly, RU/UZ/EN, native focus-restoring dialogs, Telegram draft @udhdrg, phone +998 93 122 01 01. No jumping strength demonstration.

Motion: existing GSAP reversible scroll shine and image parallax, compositor fade/translate reveals, fine-pointer magnetic interactions. Reduced motion and touch guards retained. Added imagery does not create another WebGL canvas.

## Earlier editions (historical only)

# INOX ATELIER — текущая система дизайна

## Architectural Edition · 3 октября 2026

Эта редакция заменяет прежние цветовые и композиционные решения ниже. История сохранена для контекста. Сайт — архитектурное ателье: графитовые поверхности, минеральная бумага, холодное серебро и крупная фотография реальных работ. Маркетинговые разделы выразительные; конфигуратор и расчёт подчинены ясности управления.

Канонический источник токенов — `app/studio.css`, последняя импортируемая тема. `structure.css` сохраняет базовую геометрию, `reference.css` — механику sticky-сборки; прежние цветовые темы перекрывает studio. `PriceMenu.module.css` использует ту же палитру и локальные шрифты.

| Роль                | Значение                 | Runtime         |
| ------------------- | ------------------------ | --------------- |
| Фон                 | #0e1113                  | --bg            |
| Панель              | #1b2226                  | --panel         |
| Текст               | #edf0ed                  | --text          |
| Вторичный текст     | #a9b2b6                  | --muted         |
| Стальной акцент     | #b9d0d5                  | --accent        |
| Светлая поверхность | #e6e8e5                  | --paper         |
| Текст на бумаге     | #202629                  | --paper-ink     |
| Радиус              | 2px                      | --radius        |
| Поля                | clamp(22px,5vw,96px)     | --gutter        |
| Секции              | clamp(88px,9vw,152px)    | --space-section |
| Easing              | cubic-bezier(.16,1,.3,1) | --ease          |

Onest variable для текста, навигации и крупных прямых строк; Cormorant Garamond italic только для акцентной строки hero. Оба шрифта локальные, кириллица и латиница сохранены. Заголовки имеют tracking −.045em и line-height около 1.05–1.12. Body 14–16px, line-height 1.65–1.7. Цена — табличные цифры. Контраст и focus-visible важнее декоративного блика.

Hero: проект 18 заполняет правые две трети экрана, типографика заходит на фотографию; на телефоне фото следует за CTA в естественном потоке. Коллекция и проекты — светлые разделы, фотографии крупные, без рамок карточек. Раздел поверхностей показывает три отделки; переход одновременно выбирает отделку в конфигураторе. Прайс-лист содержит 10 явно демонстрационных позиций; фотографии портфолио иллюстрируют стиль. Реальные цены 13 видео не переназначены другим изделиям.

Движение: появление 20px → 0, каскад 75ms, плавная линия ссылок, лёгкий наклон карточек и магнитные кнопки только для мыши. ScrollShine даёт обратимые серебристые блики только на hero и акценте сборки; остальные заголовки сохраняют постоянный контраст. Touch сохраняет обычную прокрутку, reduced-motion отключает эффекты. 3D demand-rendered, вне экрана приостановлено, DPR адаптивный. Гарантия FPS на всех устройствах не заявляется.

Путь клиента: коллекция → отделка → конфигурация → сборка → расчёт → окно заказа → телефон или черновик Telegram @udhdrg. Диалоги возвращают фокус и блокируют фоновую прокрутку; медиаблоки отсутствующих файлов скрыты. RU/UZ/EN сохранены. Тест прыжков исключён.

### Направление и детали

Северная звезда — архитектурный монографический сайт, где фотография изделия важнее декоративных эффектов. Изучен Boffi через Firecrawl как пример иерархии изображения и типографики; чужие ассеты не использованы. Антиреференс — одинаковые курсивные заголовки, зеленовато-бронзовые панели и мелкие технические подписи.

Onest 500 для прямых display-строк и названий, 400 для body; Cormorant Garamond italic 400 только в hero. Официальные SIL OFL лицензии находятся рядом с локальными TTF. Навигация 12px, вторичные подписи 11–12px, body 16px; большая шкала остаётся fluid. На 360px герой складывается в естественный поток с отдельной фотографией. Языковые кнопки получили высоту 44px.

Коллекция выровнена по одной линии вместо произвольного лестничного сдвига. Выбранная модель отмечается галочкой в дополнение к aria-pressed. Материалы, FAQ, конфигуратор и прайс-лист используют прямые заголовки. Активная категория прайса — спокойное подчёркивание. Темы прошлых редакций остаются только структурной совместимостью; новые значения редактируются в studio.css, адаптер прайса наследует text/muted/accent.

Проверка: production build, typecheck, domain tests, строгий audit_project.py; браузерные проверки hero, коллекции, 3D, заказа и адаптива. Точные результаты — FINAL-QA.md. Creative Production board недоступен в текущем наборе инструментов; применены собственные фотографии пользователя. Sites не использован.

## История предыдущих редакций

# INOX ATELIER — Editorial Luxury

Текущий дизайн: 22 сентября 2026. Эта версия заменяет прежнее оформление Industrial Luxury.

## Типографика

Локальная пара Playfair Display (обычное и настоящее курсивное начертания) + Manrope. Русские, английские и узбекские тексты используют одну систему; заголовки набраны в обычном регистре, курсив отделяет вторую смысловую строку. Заголовки имеют tracking −0.025…−0.04em и line-height 1.1–1.15. Основной текст — 14/16 px, line-height 1.65–1.7, ширина до 68ch. Акцентные значения используют 20/28/40/64 px и адаптивные display-размеры. Малые технические подписи — отдельный вспомогательный уровень.

Playfair Display загружен из официального репозитория Google Fonts; OFL находится в `public/fonts/PlayfairDisplay-OFL.txt`. Шрифты размещены локально и не требуют запросов к Google во время просмотра сайта.

## Палитра и пространство

Тёплый графит `#171916`, поверхности `#20231f` / `#252922`, слоновая кость `#edeae2`, вторичный текст `#b0b2a8`, один латунный акцент `#c9b48c`. Цвет металла в самой 3D-модели соответствует выбранной отделке.

Вертикальные поля разделов 100–160 px. Страница использует одну систему боковых полей, асимметричные крупные изображения и свободную площадь вокруг заголовков. Для элементов интерфейса и фотографий выбран радиус 8 px; круг сохраняется только у курсора и точечных индикаторов. Панели отделяются мягкими рассеянными тенями и едва заметными линиями.

## Главный экран

Слева — название материала, курсивная вторая строка, краткий текст и одна основная CTA. Справа — настоящая фотография проекта 18. При прокрутке на десктопе фотография плавно уступает место параметрической 3D-модели. Это два самостоятельных представления, а не обещание автоматической реконструкции снимка.

На сенсорных устройствах, узком экране и reduced-motion первый экран остаётся фотографическим. Полноценный интерактивный 3D-конфигуратор расположен ниже. Так первый экран меньше нагружает телефон и не спорит с прокруткой.

## Детали и движение

- Появление: opacity + translateY 20px, easing `cubic-bezier(.16,1,.3,1)`; stagger 70–75 ms.
- Кнопки: плавные цвет/тень за 250 ms и hover scale 1.025 для точного указателя.
- Ссылки: подчёркивание раскрывается слева направо.
- Фотография первого экрана реагирует на указатель и скролл; остальные изображения имеют единый мягкий цветовой профиль.
- Курсор уменьшен до спокойного индикатора; клавиатура и редактируемые поля сохраняют системный курсор.
- Функциональные панели, калькулятор, контактное окно и мобильное меню оформлены в одной системе.

## Код

`app/luxury.css` — цельный текущий дизайн, заменяющий прежний файл. `app/structure.css` — базовая структура. `app/motion.css` — общие интерактивные состояния. `components/HeroArtwork.tsx` — переход фотографии в 3D с очисткой ScrollTrigger. `components/ScrollReveal.tsx` — появление содержимого. `app/layout.tsx` — локальные шрифты. Языки RU / UZ / EN и конфигурация изделия сохранены.

## Signature Luxury update

The latest edition adds champagne collection and portfolio sections, a midnight-blue configurator and a warm metallic contact section. Text colours are scoped to each surface. Playfair Display and Manrope are served locally.

ArchitectureStory introduces project photograph 17 at full width and a decorative typography ribbon. SignatureMotion adds scroll-linked image parallax, ribbon movement, a reading progress line and the contact monogram. Photo entry now combines a reveal mask with translation. The hero includes soft ambient light, a slow metallic glint and a gold title sheen.

New effects run only on desktop fine-pointer devices without reduced motion. IntersectionObserver and page visibility pause ambient CSS cycles outside the viewport. Mobile keeps static photography and full functional controls. No additional 3D Canvas is created.

## Typography refinement — 2026-09-25

Manrope variable (200–800) is the primary typeface for body copy, navigation, controls, product names and first-level display lines. Playfair Display italic is reserved for contrasting second lines; the photographic architectural interlude retains its serif title. Both families include Cyrillic and Latin glyphs and are served through next/font/local. The official Manrope SIL OFL license is bundled in public/fonts.

app/typography.css isolates the final typographic rules: responsive sizes, optical tracking, readable labels, tabular price numerals, caption dividers, section index accents and a restrained selected-model marker. Existing animation transforms are unchanged. Compact laptop heights receive a shorter hero top inset so the primary action remains visible.

## Сцена безопасности — 26.09.2026

Балкон оформлен как небольшая архитектурная модель: тёплая каменная плитка со швами и микрорельефом, графитовая боковая стенка, сатинированные стойки и прозрачное слегка тонированное стекло. Светлая кромка подчёркивает толщину панелей. Взрослый носит графитовую одежду; ребёнок отличается округлым корпусом, более крупной относительно тела головой, короткими конечностями и песочно-бежевой одеждой.

Тёплый основной свет дополнен холодным контровым. Затемнение у ног, оснований и стенки выполнено лёгкими контактными текстурами; одна карта теней добавляет пространственную глубину. У открытого края появляется мягкий терракотовый акцент, у защищённого — приглушённый зелёно-золотистый.

Сценарий имеет единую пятисекундную шкалу: воспроизведение, пауза, продолжение и ручная перемотка показывают один и тот же момент. Ребёнок плавно ускоряется, двигает руками и ногами и замедляется перед стеклом. Показ остаётся условной иллюстрацией, без изображения травм.

## Обновление прокрутки — 28 сентября

Демонстрация прыжков удалена по запросу. Анимации направляют внимание от заголовка к фотографии и описанию. Для touch используются короткие fade/translate-появления, для fine pointer — маски фотографий, параллакс и лёгкое движение акцентной типографики. Все эффекты отключаются при prefers-reduced-motion, контент изначально видим в SSR.

## Current screenshot edition - 2026-09-28

app/reference.css is the final design layer. It supersedes the earlier warm editions with #070b0e, silver text and #b2d7df accents. Local Inter provides large grotesk lines, Playfair Display italic provides contrasting editorial lines. The photo-led hero uses project 19, a thin grid and two circles. Controls are rectangular; locales use a compact segmented switch.

ScrollAssembly follows the configurator. A native sticky screen shows the selected product assembling in five stages. Mobile places the model between the title and stage controls.

## Scroll light - 2026-09-29

ScrollShine adds a silver highlight travelling through major headings as they cross the viewport, plus a low-opacity diagonal reflection across portfolio images. Both reverse with scrolling. Existing typography, spacing and translations are preserved. Effects are disabled for reduced-motion and forced-colour profiles.
