import { test } from "node:test";
import assert from "node:assert/strict";
import { estimate, type ModelId, type Finish } from "../lib/config.ts";
test("quotes include length, model, finish and optional installation", () => {
  assert.equal(estimate("glass", 6, "satin", true), 10980000);
  assert.equal(estimate("rigel", 10, "gold", false), 12350000);
  assert.equal(estimate("classic", 1, "polished", true), 1530000);
});
test("invalid or malicious configuration cannot produce a quote", () => {
  for (const length of [0, -1, 101, Infinity, NaN])
    assert.throws(() => estimate("glass", length, "satin", true));
  assert.throws(() => estimate("bad" as ModelId, 2, "satin", true));
  assert.throws(() => estimate("glass", 2, "bad" as Finish, true));
});
