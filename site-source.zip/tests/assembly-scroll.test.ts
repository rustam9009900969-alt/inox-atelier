import { test } from "node:test";
import assert from "node:assert/strict";
import { assemblyStage, assemblyProgress } from "../lib/assembly-scroll.ts";

test("scroll maps to all assembly steps and reverses deterministically", () => {
  for (let stage = 0; stage <= 5; stage++) {
    assert.equal(assemblyStage(assemblyProgress(stage)), stage);
  }
  assert.deepEqual([1,.8,.6,.4,.2,0].map(assemblyStage),[5,4,3,2,1,0]);
  assert.equal(assemblyStage(-1),0);
  assert.equal(assemblyStage(2),5);
  assert.equal(assemblyStage(NaN),0);
});
