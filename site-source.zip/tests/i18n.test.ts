import { test } from "node:test";
import assert from "node:assert/strict";
import { messages, translate, isLocale } from "../lib/i18n.ts";
import { readFileSync } from "node:fs";
import ts from "typescript";

test("all dictionary entries preserve placeholders in both translations", () => {
  const tokens = (text: string) =>
    [...text.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort();
  for (const [source, entry] of Object.entries(messages)) {
    for (const lang of ["uz", "en"] as const) {
      assert.ok(entry[lang].trim(), `${source}: ${lang}`);
      assert.deepEqual(
        tokens(entry[lang]),
        tokens(source),
        `${source}: ${lang}`,
      );
      assert.doesNotMatch(
        entry[lang],
        /[А-Яа-яЁё]/,
        `${source}: untranslated ${lang}`,
      );
    }
  }
  assert.equal(
    translate("uz", "Этап {number}: {name}", { number: 2, name: "Ustunlar" }),
    "2-bosqich: Ustunlar",
  );
  assert.equal(isLocale("fr"), false);
});
test("all literal translation calls and model labels exist in the catalogue", () => {
  for (const file of [
    "app/page.tsx",
    "components/Scene.tsx",
    "components/SafetyPlayer.tsx",
    "components/ScrollAssembly.tsx",
    "components/HeroArtwork.tsx",
    "components/ArchitectureStory.tsx",
    "components/LuxuryEffects.tsx",
    "components/LocaleProvider.tsx",
    "lib/config.ts",
  ]) {
    const text = readFileSync(new URL("../" + file, import.meta.url), "utf8");
    const source = ts.createSourceFile(
      file,
      text,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TSX,
    );
    function visit(node: ts.Node) {
      if (
        ts.isCallExpression(node) &&
        ts.isIdentifier(node.expression) &&
        ["t", "displayText"].includes(node.expression.text) &&
        node.arguments[0] &&
        ts.isStringLiteral(node.arguments[0])
      ) {
        assert.ok(
          messages[node.arguments[0].text],
          `${file}: ${node.arguments[0].text}`,
        );
      }
      if (ts.isJsxText(node))
        assert.doesNotMatch(node.text, /[А-Яа-яЁё]/, `${file}: raw JSX`);
      if (
        file === "lib/config.ts" &&
        ts.isPropertyAssignment(node) &&
        ["label", "detail"].includes(node.name.getText(source)) &&
        ts.isStringLiteral(node.initializer)
      )
        assert.ok(messages[node.initializer.text]);
      ts.forEachChild(node, visit);
    }
    visit(source);
  }
});
