import { test } from "node:test";
import assert from "node:assert/strict";
import { safetyPose, GLASS_Z, CHILD_STOP_Z } from "../lib/safety-motion.ts";

test("protected child stops before the glass and never falls during scrubbing", () => {
  for (let i = 0; i <= 1000; i++) {
    const pose = safetyPose(i / 1000, true);
    assert.ok(pose.z <= CHILD_STOP_Z + 1e-10);
    assert.ok(pose.z + 0.32 < GLASS_Z, "hands must stay inside the panel");
    assert.ok(pose.y >= 0);
  }
  assert.equal(safetyPose(1, true).stride, 0);
  assert.deepEqual(safetyPose(0.9, true), safetyPose(1, true));
});
test("unprotected fall starts only after crossing the platform edge", () => {
  for (let i = 0; i <= 1000; i++) {
    const pose = safetyPose(i / 1000, false);
    if (pose.y < 0) assert.ok(pose.z > 1.65);
  }
  assert.ok(safetyPose(1, false).y < -2);
});
test("motion is reversible, bounded and decelerates continuously at the stop", () => {
  assert.deepEqual(safetyPose(-1, true), safetyPose(0, true));
  assert.deepEqual(safetyPose(3, true), safetyPose(1, true));
  assert.deepEqual(safetyPose(NaN, true), safetyPose(0, true));
  const finalStep = safetyPose(0.74, true).z - safetyPose(0.739, true).z;
  const middleStep = safetyPose(0.43, true).z - safetyPose(0.429, true).z;
  assert.ok(finalStep < middleStep * 0.02);
});
