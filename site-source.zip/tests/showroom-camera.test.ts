import { test } from "node:test";
import assert from "node:assert/strict";
import { showroomPose } from "../lib/showroom-camera.ts";
test("portrait viewport moves overview camera back without scaling product parts", () => {
  const wide = showroomPose("overall", 1.6),
    narrow = showroomPose("overall", 0.7);
  assert.ok(Math.hypot(...narrow.position) > Math.hypot(...wide.position));
  assert.deepEqual(narrow.target, wide.target);
});
test("joint view targets the existing right handrail support and remains finite", () => {
  for (const aspect of [0.3, 0.7, 1, 2.4]) {
    const pose = showroomPose("joint", aspect);
    assert.deepEqual(pose.target, [2.1, 0.69, 0]);
    assert.ok(pose.position.every(Number.isFinite));
    assert.ok(
      Math.hypot(...pose.position.map((v, i) => v - pose.target[i])) > 1,
    );
  }
});
