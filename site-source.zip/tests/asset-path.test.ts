import { test } from "node:test";
import assert from "node:assert/strict";
import { assetPath } from "../lib/asset-path.ts";
test("public media supports root and project hosting without double prefixes", () => {
  assert.equal(
    assetPath("/projects/project-19.jpg", ""),
    "/projects/project-19.jpg",
  );
  assert.equal(
    assetPath("/projects/project-19.jpg", "/inox-atelier"),
    "/inox-atelier/projects/project-19.jpg",
  );
  assert.equal(
    assetPath("/inox-atelier/media/image.webp", "/inox-atelier/"),
    "/inox-atelier/media/image.webp",
  );
  assert.equal(
    assetPath("https://example.com/video.mp4", "/inox-atelier"),
    "https://example.com/video.mp4",
  );
  assert.equal(assetPath("blob:reference", "/inox-atelier"), "blob:reference");
  assert.equal(
    assetPath("//example.com/photo.jpg", "/inox-atelier"),
    "//example.com/photo.jpg",
  );
});
