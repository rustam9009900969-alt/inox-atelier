"use client";
import { assetPath } from "@/lib/asset-path";
import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { useReducedMotion } from "framer-motion";
import {
  ArrowUpRight,
  ArrowDown,
  MoveUpRight,
  RotateCcw,
  ScanLine,
  Box,
  Layers3,
  Plus,
  Minus,
  Check,
  Phone,
  X,
  Play,
  ShieldCheck,
  Smartphone,
  Menu,
  Upload,
  Download,
  ChevronRight,
} from "lucide-react";
import {
  models,
  money,
  estimate,
  phone,
  type Finish,
  type ModelId,
} from "@/lib/config";
import {
  useLocale,
  LanguageSwitcher,
  SceneLoading,
} from "@/components/LocaleProvider";
import { numberLocale } from "@/lib/i18n";
import SafetyPlayer from "@/components/SafetyPlayer";
import ScrollShine from "@/components/ScrollShine";
import SignatureMotion from "@/components/SignatureMotion";
import PriceMenu, { PriceMenuLink } from "@/components/PriceMenu";
import { StudioDetails, StudioFAQ } from "@/components/StudioDetails";
import ArchitectureStory from "@/components/ArchitectureStory";
import HeroArtwork from "@/components/HeroArtwork";
import ScrollAssembly from "@/components/ScrollAssembly";
import ScrollReveal from "@/components/ScrollReveal";
import SmoothScroll from "@/components/SmoothScroll";
import LuxuryEffects from "@/components/LuxuryEffects";
const Scene = dynamic(() => import("@/components/Scene"), {
  ssr: false,
  loading: SceneLoading,
});
const finishes: { id: Finish; label: string }[] = [
  { id: "satin", label: "Сатин" },
  { id: "polished", label: "Зеркало" },
  { id: "gold", label: "Золото" },
];
type ModelTool = {
  name: string;
  description: string;
  inputSchema: object;
  annotations: object;
  execute: (input: unknown) => unknown;
};
export default function Home() {
  const { t, locale } = useLocale();
  const reduced = !!useReducedMotion();
  const displayText = (source: string) => {
    const value = t(source);
    return value.charAt(0) + value.slice(1).toLocaleLowerCase(locale);
  };
  const [model, setModel] = useState<ModelId>("glass"),
    [finish, setFinish] = useState<Finish>("satin"),
    [explode, setExplode] = useState(false),
    [xray, setXray] = useState(false),
    [reset, setReset] = useState(0),
    [zoom, setZoom] = useState(1),
    [gyro, setGyro] = useState(false),
    [gyroMessage, setGyroMessage] = useState(""),
    [length, setLength] = useState(6),
    [installation, setInstallation] = useState(true),
    [safe, setSafe] = useState(true),
    [showAll, setShowAll] = useState(false),
    [menu, setMenu] = useState(false),
    [modal, setModal] = useState(false),
    [reference, setReference] = useState(""),
    [uploadMessage, setUploadMessage] = useState("");
  const dialog = useRef<HTMLDialogElement>(null);
  const selected = models.find((m) => m.id === model)!;
  const total = estimate(model, length, finish, installation);
  const changeModel = useCallback((id: ModelId) => {
    setModel(id);
    setExplode(false);
  }, []);
  useEffect(
    () => () => {
      if (reference) URL.revokeObjectURL(reference);
    },
    [reference],
  );
  useEffect(() => {
    if (!modal) {
      dialog.current?.close();
      return;
    }
    const previousFocus = document.activeElement as HTMLElement | null;
    const overflow = document.documentElement.style.overflow;
    dialog.current?.showModal();
    document.documentElement.style.overflow = "hidden";
    return () => {
      dialog.current?.close();
      document.documentElement.style.overflow = overflow;
      if (previousFocus?.isConnected)
        previousFocus.focus({ preventScroll: true });
    };
  }, [modal]);
  useEffect(() => {
    if (!menu) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenu(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [menu]);
  // Feature-detect the proposed browser API. It uses exactly the same UI state.
  const modelRef = useRef({ model, finish, length, installation });
  modelRef.current = { model, finish, length, installation };
  useEffect(() => {
    const ctx = (
      document as Document & {
        modelContext?: {
          registerTool: (
            t: ModelTool,
            o: { signal: AbortSignal },
          ) => void | Promise<void>;
        };
      }
    ).modelContext;
    if (!ctx) return;
    const lifecycle = new AbortController();
    const tool: ModelTool = {
      name: "configure_railing",
      description:
        "Изменить конфигурацию ограждения и получить демонстрационную оценку. Не отправляет заявку.",
      inputSchema: {
        type: "object",
        properties: {
          model: { enum: ["glass", "rigel", "classic"] },
          finish: { enum: ["satin", "polished", "gold"] },
          length: { type: "number", minimum: 1, maximum: 100 },
          installation: { type: "boolean" },
        },
        required: ["model", "finish", "length", "installation"],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute: async (input: unknown) => {
        const v = input as Record<string, unknown>;
        if (
          !v ||
          typeof v !== "object" ||
          typeof v.installation !== "boolean" ||
          typeof v.length !== "number" ||
          !models.some((m) => m.id === v.model) ||
          !finishes.some((f) => f.id === v.finish) ||
          Object.keys(v).some(
            (k) => !["model", "finish", "length", "installation"].includes(k),
          )
        )
          throw new Error("Некорректная конфигурация");
        const cost = estimate(
          v.model as ModelId,
          v.length,
          v.finish as Finish,
          v.installation,
        );
        changeModel(v.model as ModelId);
        setFinish(v.finish as Finish);
        setLength(v.length);
        setInstallation(v.installation);
        await new Promise<void>((resolve) =>
          requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
        );
        return {
          configuration: modelRef.current,
          estimate: cost,
          currency: "UZS",
          demo: true,
          submitted: false,
        };
      },
    };
    try {
      Promise.resolve(
        ctx.registerTool(tool, { signal: lifecycle.signal }),
      ).catch(() => {});
    } catch {}
    return () => lifecycle.abort();
  }, [changeModel]);
  function selectAndOpen(id: ModelId) {
    changeModel(id);
    document
      .getElementById("configurator")
      ?.scrollIntoView({ behavior: reduced ? "instant" : "smooth" });
  }
  async function enableGyro() {
    if (gyro) {
      setGyro(false);
      return;
    }
    try {
      const sensor = DeviceOrientationEvent as typeof DeviceOrientationEvent & {
        requestPermission?: () => Promise<string>;
      };
      if (
        typeof sensor.requestPermission === "function" &&
        (await sensor.requestPermission()) !== "granted"
      ) {
        setGyroMessage(
          "Доступ к датчику не предоставлен. Можно вращать модель пальцем.",
        );
        return;
      }
      if (!("DeviceOrientationEvent" in window)) {
        setGyroMessage("Датчик не поддерживается этим устройством.");
        return;
      }
      setGyro(true);
      setGyroMessage("Наклон устройства управляет ракурсом на первом экране.");
    } catch {
      setGyroMessage("Датчик недоступен. Используйте касание.");
    }
  }
  function downloadSpec() {
    const text = [
      `INOX ATELIER — ${t("конфигурация")}`,
      `${t("Модель")}: ${selected.name}`,
      `${t("Поверхность")}: ${t(finishes.find((f) => f.id === finish)!.label)}`,
      `${t("Длина")}: ${length} ${t("м")}`,
      `${t("Монтаж")}: ${t(installation ? "Включён" : "Без монтажа")}`,
      `${t("Демонстрационный расчёт")}: ${money(total, numberLocale[locale])} ${t("сум")}`,
      t("Не является офертой. Итоговая стоимость — после замера."),
      `${t("Телефон")}: +998 93 122 01 01`,
    ].join("\n");
    const url = URL.createObjectURL(
      new Blob([text], { type: "text/plain;charset=utf-8" }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = "inox-atelier-project.txt";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  const photos = showAll
    ? Array.from({ length: 20 }, (_, i) => i + 1)
    : [18, 19, 20, 7, 15, 6];
  return (
    <>
      <SmoothScroll reduce={reduced} />
      <LuxuryEffects reduce={reduced} />
      <ScrollShine reduce={reduced} revision={`${locale}-${showAll}`} />
      <SignatureMotion reduce={reduced} revision={`${locale}-${showAll}`} />
      <ScrollReveal reduce={reduced} revision={`${locale}-${showAll}`} />
      <a className="skip-link" href="#configurator">
        {" "}
        {t("Перейти к конфигуратору")}{" "}
      </a>
      <header className="header">
        <a
          href="#top"
          className="brand"
          aria-label={t("INOX ATELIER — в начало")}
        >
          INOX<span>ATELIER</span>
        </a>
        <nav aria-label={t("Основная навигация")}>
          <a href="#collection">{t("Коллекция")}</a>
          <a href="#configurator">{t("Конфигуратор")}</a>
          <a href="#assembly">{t("Процесс")}</a>
          <PriceMenuLink />
        </nav>
        <LanguageSwitcher />
        <a className="header-phone" href={`tel:${phone}`}>
          +998 93 122 01 01 <ArrowUpRight size={16} />
        </a>
        <button
          className="mobile-menu icon-button"
          aria-label={menu ? t("Закрыть меню") : t("Открыть меню")}
          aria-expanded={menu}
          onClick={() => setMenu(!menu)}
        >
          {menu ? <X size={21} /> : <Menu size={21} />}
        </button>
      </header>
      {menu && (
        <nav className="mobile-nav" aria-label={t("Мобильная навигация")}>
          {[
            ["collection", t("Коллекция")],
            ["configurator", t("Конфигуратор")],
            ["assembly", t("Процесс")],
            [
              "price-menu",
              locale === "ru"
                ? "Прайс-лист"
                : locale === "uz"
                  ? "Narxlar"
                  : "Price list",
            ],
            ["safety", t("Безопасность")],
            ["contact", t("Контакты")],
          ].map(([id, name]) => (
            <a key={id} href={`#${id}`} onClick={() => setMenu(false)}>
              {t(name)}
              <ArrowUpRight size={18} />
            </a>
          ))}
        </nav>
      )}
      <main>
        <section id="top" className="hero">
          <div className="hero-stage">
            <div className="hero-aurora" aria-hidden="true" />
            <div className="hero-index" aria-hidden="true">
              <span>INOX / ARCHITECTURAL METAL</span>
              <span>01 — 05</span>
            </div>
            <div className="hero-coordinate" aria-hidden="true">
              {" "}
              {t("ФОРМА / МАТЕРИАЛ / ТОЧНОСТЬ")}{" "}
            </div>
            <div className="hero-copy">
              <div className="eyebrow">
                <span /> {t("НЕРЖАВЕЮЩАЯ СТАЛЬ / ТАШКЕНТ")}{" "}
              </div>
              <h1 aria-label={t("Архитектура стали.")}>
                <span className="hero-word">{t("Архитектура")}</span>
                <span className="hero-last">{t("стали.")}</span>
              </h1>
              <p className="hero-intro">
                {t("Архитектурные ограждения")}
                <br />
                {t("для пространств со вкусом.")}
              </p>
              <div className="hero-actions">
                <a className="button primary" href="#collection">
                  {" "}
                  {t("Посмотреть модели")} <ArrowUpRight size={19} />
                </a>
                <a className="text-button" href="#configurator">
                  {t("Конфигуратор")} <ArrowUpRight size={16} />
                </a>
              </div>
            </div>
            <HeroArtwork reduce={reduced} gyro={gyro} />
            <div className="hero-orbits" aria-hidden="true">
              <i />
              <i />
            </div>
            <div className="hero-caption">
              <span>{t("Архитектурная визуализация")}</span>
              <span>{t("СТАЛЬ · СТЕКЛО · СВЕТ")}</span>
            </div>
            <div className="hero-bottom">
              <a href="#collection">
                <ArrowDown size={16} />{" "}
                {t("Листайте, чтобы почувствовать детали")}{" "}
              </a>
              <span>
                {" "}
                {t("ПРОИЗВОДСТВО И МОНТАЖ")} <MoveUpRight size={14} />
              </span>
            </div>
          </div>
        </section>
        <section className="material-strip" aria-label={t("Наш подход")}>
          <div className="material-signature" aria-hidden="true">
            PRECISION
            <br />
            IS EVERYTHING.
          </div>
          <div>
            <Check size={18} aria-hidden="true" />{" "}
            {t("Выразительный дизайн")}{" "}
          </div>
          <div>
            <Check size={18} aria-hidden="true" />{" "}
            {t("Точная обработка стали")}{" "}
          </div>
          <div>
            <Check size={18} aria-hidden="true" />{" "}
            {t("Монтаж под ваш проект")}{" "}
          </div>
        </section>
        <section id="collection" className="section collection">
          <div className="section-top">
            <span className="eyebrow">{t("КОЛЛЕКЦИЯ")}</span>
            <span className="small-note">
              {t("Три характера. Ваша архитектура.")}
            </span>
          </div>
          <div className="section-heading">
            <h2>
              {" "}
              {displayText("ФОРМА.")} <br />
              <span>{displayText("БЕЗ ЛИШНЕГО.")}</span>
            </h2>
            <p>
              {" "}
              {t("От невесомого стекла до выразительной классики.")} <br />{" "}
              {t("Выберите основу для своего пространства.")}{" "}
            </p>
          </div>
          <div className="collection-grid">
            {models.map((m, i) => (
              <button
                className={`model-card ${model === m.id ? "selected" : ""}`}
                key={m.id}
                onClick={() => selectAndOpen(m.id)}
                aria-label={t("Настроить {name}", { name: m.name })}
                aria-pressed={model === m.id}
              >
                <div className="model-image tilt-surface">
                  <img
                    src={m.image}
                    alt={t(m.label)}
                    width="640"
                    height="720"
                    loading="lazy"
                  />
                  <span className="image-tag">
                    {t("КОЛЛЕКЦИЯ / 0")}
                    {i + 1}
                  </span>
                  <span className="card-arrow">
                    <ArrowUpRight size={23} />
                  </span>
                </div>
                <div className="model-title">
                  <span className="collection-number">0{i + 1}</span>
                  <h3>{m.name}</h3>
                  <span>{t(m.label)}</span>
                </div>
                <p>{t(m.detail)}</p>
              </button>
            ))}
          </div>
        </section>
        <ArchitectureStory />
        <StudioDetails onChooseFinish={setFinish} />
        <section id="configurator" className="section configurator">
          <div className="section-top">
            <span className="eyebrow">{t("ВАША КОНСТРУКЦИЯ")}</span>
            <span className="small-note">
              {t("Исследуйте каждое соединение")}
            </span>
          </div>
          <div className="section-heading">
            <h2>
              {" "}
              {displayText("ТОЧНОСТЬ.")} <br />
              <span>{displayText("В КАЖДОЙ ДЕТАЛИ.")}</span>
            </h2>
            <p>
              {" "}
              {t("Поверните. Разберите. Посмотрите внутрь.")} <br />{" "}
              {t("Продуманная конструкция — со всех сторон.")}{" "}
            </p>
          </div>
          <div className="config-shell">
            <div className="config-visual">
              <div className="viewer-label">
                <span>{selected.name}</span>
                <span>3D / LIVE</span>
              </div>
              <div className="config-canvas" data-lenis-prevent>
                <Scene
                  kind="config"
                  model={model}
                  finish={finish}
                  explode={explode ? 1 : 0}
                  xray={xray}
                  reset={reset}
                  zoom={zoom}
                  reduce={reduced}
                />
              </div>
              <div className="viewer-tools">
                <button
                  className={explode ? "active" : ""}
                  aria-pressed={explode}
                  onClick={() => {
                    setExplode(!explode);
                  }}
                >
                  <Layers3 size={17} /> {t("Разобрать")}{" "}
                </button>
                <button
                  className={xray ? "active" : ""}
                  aria-pressed={xray}
                  onClick={() => setXray(!xray)}
                >
                  <ScanLine size={17} /> {t("Рентген")}{" "}
                </button>
                <button
                  aria-label={t("Сбросить ракурс")}
                  onClick={() => {
                    setReset((r) => r + 1);
                    setZoom(1);
                  }}
                >
                  <RotateCcw size={17} />
                </button>
                <button
                  aria-label={t("Приблизить модель")}
                  onClick={() => setZoom((v) => Math.min(1.8, v + 0.15))}
                >
                  <Plus size={17} />
                </button>
                <button
                  aria-label={t("Отдалить модель")}
                  onClick={() => setZoom((v) => Math.max(0.65, v - 0.15))}
                >
                  <Minus size={17} />
                </button>
              </div>
              <span className="viewer-hint">
                {" "}
                {t("Вращайте мышью или пальцем · два пальца для масштаба")}{" "}
              </span>
            </div>
            <aside className="config-options">
              <span className="config-studio-mark" aria-hidden="true">
                ATELIER / 3D
              </span>
              <div className="option-heading">
                <span className="eyebrow">{t("ИНДИВИДУАЛЬНЫЙ ПРОЕКТ")}</span>
                <Box size={19} />
              </div>
              <h3>
                {" "}
                {t("Ваша линия.")} <br /> {t("Ваш характер.")}{" "}
              </h3>
              <fieldset>
                <legend>{t("01 / Модель")}</legend>
                <div className="model-options">
                  {models.map((m) => (
                    <button
                      key={m.id}
                      aria-label={m.name}
                      aria-pressed={model === m.id}
                      onClick={() => changeModel(m.id)}
                      className={model === m.id ? "chosen" : ""}
                    >
                      <img
                        src={m.image}
                        alt=""
                        width={72}
                        height={72}
                        loading="lazy"
                      />
                      <span className="model-option-copy">
                        <strong>{m.name}</strong>
                        <small>{t(m.label)}</small>
                      </span>
                      {model === m.id ? (
                        <Check size={16} />
                      ) : (
                        <ChevronRight size={16} />
                      )}
                    </button>
                  ))}
                </div>
              </fieldset>
              <fieldset>
                <legend>{t("02 / Поверхность стали")}</legend>
                <div className="finish-options">
                  {finishes.map((f) => (
                    <button
                      key={f.id}
                      className={finish === f.id ? "chosen" : ""}
                      onClick={() => setFinish(f.id)}
                      aria-pressed={finish === f.id}
                    >
                      <span className={`swatch ${f.id}`} />
                      {t(f.label)}
                    </button>
                  ))}
                </div>
              </fieldset>
              <div className="config-note">
                {" "}
                {t(
                  "Параметрическая визуализация по мотивам наших работ. Пропорции уточняются после замера.",
                )}{" "}
              </div>
              <button
                className="button outline full"
                onClick={enableGyro}
                aria-pressed={gyro}
              >
                <Smartphone size={17} />
                {gyro ? t("Отключить наклон") : t("Управление наклоном")}
              </button>
              {gyroMessage && (
                <p className="small-note" role="status">
                  {t(gyroMessage)}
                </p>
              )}
            </aside>
          </div>
          <a href="#assembly" className="assembly-entry button outline">
            {t("Смотреть сборку на скролле")} <ArrowDown size={16} />
          </a>
        </section>
        <ScrollAssembly model={model} finish={finish} reduce={reduced} />
        <section id="safety" className="section safety">
          <div className="safety-copy">
            <span className="eyebrow">{t("САМОЕ ВАЖНОЕ")}</span>
            <h2>
              {" "}
              {displayText("СПОКОЙСТВИЕ.")} <br />
              <span>{displayText("В КАЖДОЙ ЛИНИИ.")}</span>
            </h2>
            <p>
              {" "}
              {t("Один звонок. Одно мгновение.")} <br />{" "}
              {t("Ограждение становится границей")} <br />{" "}
              {t("между обычным днём и опасностью.")}{" "}
            </p>
            <div
              className="segmented"
              role="group"
              aria-label={t("Сценарий безопасности")}
            >
              <button
                className={!safe ? "active danger" : ""}
                aria-pressed={!safe}
                onClick={() => {
                  setSafe(false);
                }}
              >
                {" "}
                {t("Без ограждения")}{" "}
              </button>
              <button
                className={safe ? "active" : ""}
                aria-pressed={safe}
                onClick={() => {
                  setSafe(true);
                }}
              >
                <ShieldCheck size={16} /> {t("С ограждением")}{" "}
              </button>
            </div>
            <div
              className={`safety-message ${safe ? "" : "danger"}`}
              aria-live="polite"
            >
              <span>
                {safe
                  ? t("Преграда на пути к краю.")
                  : t("Открытый край — риск падения.")}
              </span>
              <p>
                {safe
                  ? t("Ребёнок останавливается перед стеклом.")
                  : t(
                      "Условная сцена показывает последствия отсутствия защиты.",
                    )}
              </p>
            </div>
            <p className="safety-fine">
              {" "}
              {t(
                "Схематическая иллюстрация, не испытание конструкции. Безопасность зависит от проекта, стекла, крепежа и монтажа. Ограждение не заменяет присмотр за ребёнком.",
              )}{" "}
            </p>
          </div>
          <SafetyPlayer safe={safe} reduce={reduced} />
        </section>
        <section id="projects" className="section projects">
          <div className="section-top">
            <span className="eyebrow">{t("РЕАЛЬНЫЕ ПРОЕКТЫ")}</span>
            <span className="small-note">
              {" "}
              {t("Детали, которые уже стали частью дома")}{" "}
            </span>
          </div>
          <div className="section-heading">
            <h2>
              {" "}
              {displayText("В АРХИТЕКТУРЕ.")} <br />
              <span>{displayText("В РЕАЛЬНОСТИ.")}</span>
            </h2>
            <button
              className="text-button"
              onClick={() => setShowAll(!showAll)}
            >
              {showAll ? t("Свернуть галерею") : t("Все 20 проектов")}
              <ArrowUpRight size={19} />
            </button>
          </div>
          <div className={`project-grid ${showAll ? "expanded" : ""}`}>
            {photos.map((n, i) => (
              <button
                className="project"
                key={n}
                onClick={() =>
                  selectAndOpen(
                    [6, 12, 19].includes(n)
                      ? "glass"
                      : [2, 11, 14, 20].includes(n)
                        ? "rigel"
                        : "classic",
                  )
                }
                aria-label={t("Проект {number}: открыть похожую модель в 3D", {
                  number: n,
                })}
              >
                <div className="project-image tilt-surface">
                  <img
                    src={assetPath(
                      `/projects/project-${String(n).padStart(2, "0")}.jpg`,
                    )}
                    width="600"
                    height="700"
                    loading="lazy"
                    alt={t(
                      "Реализованный проект {number}: ограждение из нержавеющей стали",
                      { number: n },
                    )}
                  />
                  <span className="card-arrow">
                    <ArrowUpRight size={22} />
                  </span>
                </div>
                <span>
                  {t("ПРОЕКТ /")} {String(n).padStart(2, "0")}
                </span>
                <p>
                  {[6, 12, 19].includes(n)
                    ? t("Прозрачность в деталях")
                    : [2, 11, 14, 20].includes(n)
                      ? t("Геометрия пространства")
                      : n === 7
                        ? t("Плавность линий")
                        : t("Характер стали")}
                </p>
              </button>
            ))}
          </div>
        </section>
        <section id="estimate" className="section estimate">
          <div>
            <span className="eyebrow">{t("НАЧНЁМ С ВАШЕЙ ИДЕИ")}</span>
            <h2>
              {" "}
              {displayText("ВАША ИДЕЯ.")} <br />
              <span>{displayText("ТОЧНЫЙ РАСЧЁТ.")}</span>
            </h2>
            <p>
              {" "}
              {t("Укажите длину и состав работ.")} <br />{" "}
              {t("Конфигурация уже учитывает выбранный дизайн.")}{" "}
            </p>
            <div className="reference-upload">
              <label className="text-button">
                <Upload size={18} /> {t("Добавить фото пространства")}{" "}
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="sr-only"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (
                      !["image/jpeg", "image/png", "image/webp"].includes(
                        file.type,
                      ) ||
                      file.size > 10 * 1024 * 1024
                    ) {
                      setUploadMessage("Выберите JPG, PNG или WebP до 10 МБ.");
                      return;
                    }
                    setReference(URL.createObjectURL(file));
                    setUploadMessage(
                      "Фото открыто только на вашем устройстве. Оно не отправляется и не преобразуется автоматически в 3D.",
                    );
                  }}
                />
              </label>
              {reference && (
                <div className="reference-preview">
                  <img src={reference} alt={t("Ваш референс пространства")} />
                  <button
                    className="icon-button"
                    aria-label={t("Удалить выбранное фото")}
                    onClick={() => {
                      setReference("");
                      setUploadMessage("");
                    }}
                  >
                    <X size={16} />
                  </button>
                </div>
              )}
              {uploadMessage && (
                <p role="status" className="small-note">
                  {t(uploadMessage)}
                </p>
              )}
            </div>
          </div>
          <div className="calculator">
            <div className="quote-preview">
              <img
                src={selected.image}
                alt={t(selected.label)}
                width={480}
                height={280}
                loading="lazy"
              />
              <div>
                <span className="eyebrow">{t("ВЫБРАННАЯ КОМПЛЕКТАЦИЯ")}</span>
                <strong>{selected.name}</strong>
                <span>
                  {t(finishes.find((f) => f.id === finish)!.label)} ·{" "}
                  {t(selected.label)}
                </span>
              </div>
            </div>
            <div className="calc-title">
              <h3>{t("Ваш проект")}</h3>
              <span>{selected.name}</span>
            </div>
            <label className="length-label" htmlFor="length">
              {" "}
              {t("Длина ограждения")}{" "}
              <span>
                <input
                  id="length"
                  type="number"
                  min="1"
                  max="100"
                  step=".5"
                  value={length}
                  onChange={(e) => {
                    const n = Number(e.target.value);
                    if (Number.isFinite(n))
                      setLength(Math.min(100, Math.max(1, n)));
                  }}
                />{" "}
                {t("м")}{" "}
              </span>
            </label>
            <input
              type="range"
              aria-label={t("Длина ограждения в метрах")}
              min="1"
              max="100"
              step=".5"
              value={length}
              onChange={(e) => setLength(Number(e.target.value))}
            />
            <div className="range-labels">
              <span>{t("1 м")}</span>
              <span>{t("100 м")}</span>
            </div>
            <label className="check-row">
              <span>{t("Включить монтаж")}</span>
              <input
                type="checkbox"
                checked={installation}
                onChange={(e) => setInstallation(e.target.checked)}
              />
            </label>
            <div className="cost">
              <span>{t("Демонстрационный расчёт")}</span>
              <strong aria-live="polite">
                {money(total, numberLocale[locale])} <small>{t("сум")}</small>
              </strong>
              <p>
                {" "}
                {t(
                  "Пример расчёта, не оферта. Точный бюджет — после замера и согласования материалов.",
                )}{" "}
              </p>
            </div>
            <button
              className="button primary full"
              onClick={() => setModal(true)}
            >
              {" "}
              {t("Обсудить мой проект")} <ArrowUpRight size={19} />
            </button>
          </div>
        </section>
        <PriceMenu />
        <StudioFAQ />
        <section id="contact" className="section contact">
          <div className="contact-monogram" aria-hidden="true">
            INOX
          </div>
          <span className="eyebrow">
            {" "}
            {t("ВАШЕ ПРОСТРАНСТВО НАЧИНАЕТСЯ С ДИАЛОГА")}{" "}
          </span>
          <h2>
            {" "}
            {displayText("СОЗДАДИМ")} <br />
            <em>{t("ВАШУ ЛИНИЮ.").toLocaleLowerCase(locale)}</em>
          </h2>
          <div className="contact-details">
            <span>{t("Проектирование. Производство. Монтаж.")}</span>
            <a
              href="https://t.me/udhdrg"
              target="_blank"
              rel="noopener noreferrer"
            >
              Telegram / @udhdrg <ArrowUpRight size={16} />
            </a>
          </div>
          <div className="contact-row">
            <button className="button primary" onClick={() => setModal(true)}>
              {" "}
              {t("Заказать индивидуальный 3D-проект")}{" "}
              <ArrowUpRight size={19} />
            </button>
            <a className="contact-phone" href={`tel:${phone}`}>
              +998 93 122 01 01
              <ArrowUpRight size={27} />
            </a>
          </div>
        </section>
      </main>
      <footer>
        <a href="#top" className="brand">
          INOX<span>ATELIER</span>
        </a>
        <span>
          ARCHITECTURAL METALWORK
          <br /> {t("ФОРМА. МАТЕРИАЛ. ТОЧНОСТЬ.")}{" "}
        </span>
        <nav className="footer-nav" aria-label={t("Разделы сайта")}>
          <a href="#collection">{t("Коллекция")}</a>
          <a href="#configurator">{t("Конфигуратор")}</a>
          <a href="#projects">{t("РЕАЛЬНЫЕ ПРОЕКТЫ")}</a>
          <a href="#price-menu">{t("Прайс-лист")}</a>
        </nav>
        <span>© {new Date().getFullYear()} INOX ATELIER</span>
        <a href="#top">{t("Наверх ↑")}</a>
      </footer>
      <dialog
        ref={dialog}
        className="project-dialog"
        aria-labelledby="project-dialog-title"
        data-lenis-prevent
        onCancel={() => setModal(false)}
        onClick={(e) => {
          if (e.target === e.currentTarget) setModal(false);
        }}
      >
        <div className="dialog-top">
          <span className="eyebrow">{t("ИНДИВИДУАЛЬНЫЙ ПРОЕКТ")}</span>
          <button
            className="icon-button"
            aria-label={t("Закрыть окно проекта")}
            onClick={() => setModal(false)}
          >
            <X size={21} />
          </button>
        </div>
        <h2 id="project-dialog-title">
          {" "}
          {t("Ваша идея.")} <br />
          <span>{t("Следующий шаг.")}</span>
        </h2>
        <p>
          {" "}
          {t(
            "Позвоните нам для замера и подготовки 3D-проекта. Сохраните выбранные параметры, чтобы обсудить детали.",
          )}{" "}
        </p>
        <dl>
          <div>
            <dt>{t("Коллекция")}</dt>
            <dd>{selected.name}</dd>
          </div>
          <div>
            <dt>{t("Поверхность")}</dt>
            <dd>{t(finishes.find((f) => f.id === finish)!.label)}</dd>
          </div>
          <div>
            <dt>{t("Длина")}</dt>
            <dd>
              {length} {t("м")}
            </dd>
          </div>
          <div>
            <dt>{t("Монтаж")}</dt>
            <dd>{installation ? t("Включён") : t("Без монтажа")}</dd>
          </div>
        </dl>
        <a className="button primary full" href={`tel:${phone}`}>
          <Phone size={17} />
          +998 93 122 01 01
          <ArrowUpRight size={18} />
        </a>
        <a
          className="button outline full"
          href={`https://t.me/udhdrg?text=${encodeURIComponent(`Здравствуйте, интересует ${selected.name}. Длина: ${length} м. Отделка: ${t(finishes.find((f) => f.id === finish)!.label)}.`)}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          {t("Написать в Telegram")} <ArrowUpRight size={18} />
        </a>
        <button className="text-button" onClick={downloadSpec}>
          <Download size={17} /> {t("Скачать параметры проекта")}{" "}
        </button>
        <p className="small-note">
          {" "}
          {t(
            "Заявка автоматически не отправляется. Позвоните нам или напишите в Telegram.",
          )}{" "}
        </p>
      </dialog>
    </>
  );
}
