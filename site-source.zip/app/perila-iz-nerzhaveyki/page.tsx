export { default } from "../page";
