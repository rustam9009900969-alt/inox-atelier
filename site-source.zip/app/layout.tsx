import { assetPath } from "@/lib/asset-path";
import type { Metadata } from "next";
import "./globals.css";
import { LocaleProvider } from "@/components/LocaleProvider";
import localFont from "next/font/local";
const display = localFont({
  src: "../public/fonts/CormorantGaramond-Italic.ttf",
  variable: "--font-display",
  weight: "300 700",
  style: "italic",
  display: "swap",
});
const body = localFont({
  src: "../public/fonts/Manrope.ttf",
  variable: "--font-body",
  weight: "200 800",
  display: "swap",
});
const heroDisplay = localFont({
  src: "../public/fonts/Oswald.ttf",
  variable: "--font-hero",
  weight: "200 700",
  display: "swap",
});
export const metadata: Metadata = {
  icons: { icon: assetPath("/favicon.svg") },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="ru"
      className={`${display.variable} ${body.variable} ${heroDisplay.variable}`}
    >
      <body>
        <LocaleProvider>{children}</LocaleProvider>
      </body>
    </html>
  );
}
