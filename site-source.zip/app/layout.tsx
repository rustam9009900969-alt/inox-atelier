import { assetPath } from "@/lib/asset-path";
import type { Metadata } from "next";
import "./globals.css";
import { LocaleProvider } from "@/components/LocaleProvider";
import localFont from "next/font/local";
const display = localFont({
  src: "../public/fonts/Oswald.ttf",
  variable: "--font-display",
  weight: "200 700",
  display: "swap",
});
const body = localFont({
  src: "../public/fonts/Onest.ttf",
  variable: "--font-body",
  weight: "100 900",
  display: "swap",
});
export const metadata: Metadata = {
  icons: { icon: assetPath("/favicon.svg") },
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru" className={`${display.variable} ${body.variable}`}>
      <body>
        <LocaleProvider>{children}</LocaleProvider>
      </body>
    </html>
  );
}
