#!/bin/zsh
set -e
cd -- "$(dirname -- "$0")"
if command -v node >/dev/null 2>&1; then
  inox_node="$(command -v node)"
elif [[ -x /Users/a666/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node ]]; then
  inox_node=/Users/a666/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node
else
  print 'Не найден Node.js.'
  read 'inox_reply?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
if ! "$inox_node" scripts/local-site.mjs stop; then
  read 'inox_reply?Нажмите Enter, чтобы закрыть окно.'
  exit 1
fi
